#pragma once

// JSM-side per-frame recording. Deliberately separate from faal.h: the filter
// stays a dependency-free algorithm, while this only exists to debug JSM.
//
// The file keeps its original name because the build system already lists it;
// the filter itself now lives in faal.h.
#include "faal.h"

struct FaalTraceInput
{
	float dt;
	float gyroX, gyroY, gyroZ;   // calibrated gyro that entered the filter
	float rawX, rawY, rawZ;      // calibrated gyro before the space transform
	float gravX, gravY, gravZ;
	float quatW, quatX, quatY, quatZ;
	float outX, outY, outZ;      // what actually left the filter
};

void FaalTraceStart();
bool FaalTraceIsRecording();
unsigned long long FaalTraceRecordedFrames();
void FaalTraceRecord(const FaalTraceInput& in, const FaalParams& applied);
unsigned long long FaalTraceStopAndWrite(const char* path);
