#pragma once
#include "JSMVariable.hpp"

// The 12 FAAL settings used to live here as global JSMSetting objects, registered
// by a static initialiser. They are now created in initJsmSettings() (main.cpp)
// like every other setting of the program: heap-allocated, handed to
// SettingsManager, which owns them, with the command registered next to them.
//
// That removes two problems at once:
//   * no settings are registered during static initialisation, so nothing runs
//     before main() and there is no static-initialisation-order dependency;
//   * the settings are heap objects, so the shared_ptr map deletes them normally
//     instead of calling operator delete on static storage at exit
//     (which corrupted the heap: STATUS_HEAP_CORRUPTION on shutdown).
//
// This file is kept only because CMakeLists.txt still lists it; nothing includes
// it. Read initJsmSettings() in main.cpp for the current definitions.
