// FAALAssignments.h
#pragma once
#include "JSMAssignment.hpp"
#include "FAALSettings.h"

class FaalFloatAssignment : public JSMAssignment<float>
{
public:
	FaalFloatAssignment(SettingID id, JSMSetting<float>& setting)
	  : JSMAssignment(magic_enum::enum_name(id).data(),
	      string(magic_enum::enum_name(setting._id)),
	      setting)
	{
	}
};

class FaalIntAssignment : public JSMAssignment<int>
{
public:
	FaalIntAssignment(SettingID id, JSMSetting<int>& setting)
	  : JSMAssignment(magic_enum::enum_name(id).data(),
	      string(magic_enum::enum_name(setting._id)),
	      setting)
	{
	}
};