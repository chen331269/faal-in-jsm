#pragma once
#include <windows.h>
#include <cstdint>

inline uint8_t vkToButtonBit(int vkKey)
{
	switch (vkKey)
	{
	case VK_LBUTTON:
		return 0x01;
	case VK_RBUTTON:
		return 0x02;
	case VK_MBUTTON:
		return 0x04;
	case VK_XBUTTON1:
		return 0x08;
	case VK_XBUTTON2:
		return 0x10;
	default:
		return 0x00;
	}
}

// Report IDs (from driver.h - confirmed by descriptor order)
#define REPORTID_KEYBOARD 1
#define REPORTID_ENHANCED_KEY 2
#define REPORTID_RELATIVE_MOUSE 3
#define REPORTID_ABSOLUTE_MOUSE 4
#define REPORTID_CONTROL 64
#define REPORTID_CHECK_API_VERSION 65
#define REPORTID_API_VERSION_FEATURE 66

#pragma pack(push, 1)
struct RelativeMouseReport
{
	uint8_t ReportId; // = REPORTID_RELATIVE_MOUSE (3)
	uint8_t Buttons;  // bit0=L, bit1=R, bit2=M, bit3=X1, bit4=X2, bit5-7=padding
	int16_t MouseX;   // relative X, -32767 to 32767
	int16_t MouseY;   // relative Y, -32767 to 32767
	int8_t Wheel;     // scroll wheel, -127 to 127
	int8_t AC_Pan;    // horizontal wheel, -127 to 127
};
#pragma pack(pop)

static_assert(sizeof(RelativeMouseReport) == 8, "Report size mismatch!");

// Windows virtual-key code to HID usage. Returns 0 when there is no mapping,
// which lets callers fall back to SendInput instead of dropping the key.
unsigned char vkToHidUsage(int vk);

class FakerInputBackend
{
public:
	FakerInputBackend();
	~FakerInputBackend();
	bool init();
	void shutdown();
	void moveRelative(int x, int y);
	void pressButton(int vkKey, bool pressed);
	void scroll(int amount);
	void setButtons(uint8_t buttons);
	// Keyboard goes through the same virtual HID device, so it never touches
	// SendInput. The report is only written when something actually changed.
	void pressKey(int vkKey, bool pressed);
	bool isKeyboardAvailable() const
	{
		return keyboardReady_;
	}
	bool isAvailable() const
	{
		return hDevice_ != INVALID_HANDLE_VALUE;
	}

private:
	HANDLE hDevice_;
	uint8_t currentButtons_;
	void sendReport(int x, int y);

	// Keyboard rollover state: modifier bits plus up to six concurrent keys.
	bool keyboardReady_ = false;
	uint8_t keyboardModifiers_ = 0;
	uint8_t keyboardKeys_[6] = { 0, 0, 0, 0, 0, 0 };
	uint8_t keyboardSentModifiers_ = 0xFF;
	uint8_t keyboardSentKeys_[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
	void sendKeyboardReport();
};