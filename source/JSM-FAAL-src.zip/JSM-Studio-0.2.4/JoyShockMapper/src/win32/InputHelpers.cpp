#include "InputHelpers.h"
#include <thread>
#include <unordered_map>

// ↓ FakerInput support
#include "FakerInputBackend.h"

class FakerInputBackend;
FakerInputBackend& getFakerBackend();

static float accumulatedX = 0;
static float accumulatedY = 0;

// Windows' mouse speed settings translate non-linearly to speed.
// Thankfully, the mappings are available here: https://liquipedia.net/counterstrike/Mouse_settings#Windows_Sensitivity
static float windowsSensitivityMappings[] = {
	0.0, // mouse sensitivity range is 1-20, so just put nothing in the 0th element
	1.0 / 32.0,
	1.0 / 16.0,
	1.0 / 8.0,
	2.0 / 8.0,
	3.0 / 8.0,
	4.0 / 8.0,
	5.0 / 8.0,
	6.0 / 8.0,
	7.0 / 8.0,
	1.0,
	1.25,
	1.5,
	1.75,
	2.0,
	2.25,
	2.5,
	2.75,
	3.0,
	3.25,
	3.5
};

// get the user's mouse sensitivity multiplier from the user. In Windows it's an int, but who cares? it's well within range for float to represent it exactly
// also, if this is ported to other platforms, we might want non-integer sensitivities
float getMouseSpeed()
{
	int result;
	if (SystemParametersInfo(SPI_GETMOUSESPEED, 0, &result, 0) && result >= 1 && result <= 20)
	{
		return windowsSensitivityMappings[result];
	}
	return 1.0;
}

// Map a VK id to mouse event id press (0) or release (1) and mouseData (2) complementary info
unordered_map<WORD, tuple<DWORD, DWORD, DWORD>> mouseMaps = {
	{ VK_LBUTTON, { MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP, 0 } },
	{ VK_RBUTTON, { MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, 0 } },
	{ VK_MBUTTON, { MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP, 0 } },
	{ VK_XBUTTON1, { MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, XBUTTON1 } },
	{ VK_XBUTTON2, { MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, XBUTTON2 } },
	{ V_WHEEL_UP, { MOUSEEVENTF_WHEEL, 0, WHEEL_DELTA } },
	{ V_WHEEL_DOWN, { MOUSEEVENTF_WHEEL, 0, -WHEEL_DELTA } },
};

// send mouse button
int pressMouse(KeyCode vkKey, bool isPressed)
{
	// ↓ FakerInput path: try virtual HID first
	static FakerInputBackend& faker = getFakerBackend();
	if (faker.isAvailable())
	{
		// Wheel handling
		if (vkKey.code == V_WHEEL_UP)
		{
			if (isPressed)
				faker.scroll(WHEEL_DELTA);
			return 1;
		}
		if (vkKey.code == V_WHEEL_DOWN)
		{
			if (isPressed)
				faker.scroll(-WHEEL_DELTA);
			return 1;
		}
		// Button handling
		int bit = vkToButtonBit(vkKey.code);
		if (bit >= 0)
		{
			faker.pressButton(bit, isPressed);
			return 1;
		}
		// Unrecognized VK falls through to SendInput
	}

	// ↓ Original SendInput path (unchanged)
	auto val = mouseMaps[vkKey.code];

	INPUT input;
	input.type = INPUT_MOUSE;
	input.mi.time = 0;
	input.mi.dx = 0;
	input.mi.dy = 0;
	input.mi.dwFlags = isPressed ? get<0>(val) : get<1>(val);
	input.mi.mouseData = get<2>(val);
	if (input.mi.dwFlags)
	{ // Ignore if there's no event ID (ex: "wheel release")
		auto result = SendInput(1, &input, sizeof(input));
		return result;
	}
	return 0;
}

bool isNumLockKey(KeyCode key)
{
	static array<uint8_t, 7> keys{ VK_DECIMAL, VK_HOME, VK_END, VK_INSERT, VK_DELETE, VK_PRIOR, VK_NEXT };
	return (key.code >= VK_NUMPAD0 && key.code <= VK_NUMPAD9) || find(keys.begin(), keys.end(), key.code) != keys.end();
}

bool isExtendedKey(KeyCode key)
{
	return ((key.code >= VK_PRIOR && key.code <= VK_HELP) && key.code != VK_SNAPSHOT) ||
	  (key.code >= VK_LWIN && key.code <= VK_DIVIDE) ||
	  (key.code >= VK_BROWSER_BACK && key.code <= VK_LAUNCH_APP2);
}

// send key press
int pressKey(KeyCode vkKey, bool pressed)
{
	if (vkKey.code == 0)
		return 0;
	if (vkKey.code <= V_WHEEL_DOWN) // Highest mouse ID
		return pressMouse(vkKey, pressed);

	INPUT input;
	memset(&input, 0, sizeof(INPUT));
	input.type = INPUT_KEYBOARD;
	input.ki.time = 0;
	input.ki.dwFlags = pressed ? 0 : KEYEVENTF_KEYUP;
	if (isExtendedKey(vkKey))
	{
		input.ki.dwFlags |= KEYEVENTF_EXTENDEDKEY;
	}

	if (isNumLockKey(vkKey))
	{
		input.ki.wVk = vkKey.code;
		input.ki.wScan = 0;
	}
	else
	{
		input.ki.wVk = 0;
		input.ki.wScan = MapVirtualKey(vkKey.code, MAPVK_VK_TO_VSC);
		input.ki.dwFlags |= KEYEVENTF_SCANCODE;
	}

	return SendInput(1, &input, sizeof(input));
}

void moveMouse(float x, float y)
{
	// ↓ FakerInput path: try virtual HID first
	static FakerInputBackend& faker = getFakerBackend();
	if (faker.isAvailable())
	{
		accumulatedX += x;
		accumulatedY += y;
		int applicableX = (int)accumulatedX;
		int applicableY = (int)accumulatedY;
		accumulatedX -= applicableX;
		accumulatedY -= applicableY;
		faker.moveRelative((short)applicableX, (short)applicableY);
		return;
	}

	// ↓ Original SendInput path (unchanged)
	accumulatedX += x;
	accumulatedY += y;

	int applicableX = (int)accumulatedX;
	int applicableY = (int)accumulatedY;

	accumulatedX -= applicableX;
	accumulatedY -= applicableY;

	INPUT input;
	input.type = INPUT_MOUSE;
	input.mi.mouseData = 0;
	input.mi.time = 0;
	input.mi.dx = applicableX;
	input.mi.dy = applicableY;
	input.mi.dwFlags = MOUSEEVENTF_MOVE;
	SendInput(1, &input, sizeof(input));
}

void setMouseNorm(float x, float y)
{
	INPUT input;
	input.type = INPUT_MOUSE;
	input.mi.mouseData = 0;
	input.mi.time = 0;
	input.mi.dx = LONG(roundf(65535.0f * x));
	input.mi.dy = LONG(roundf(65535.0f * y));
	input.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE;
	SendInput(1, &input, sizeof(input));
}

BOOL WriteToConsole(string_view command)
{
	static const INPUT_RECORD ESC_DOWN = { KEY_EVENT, { TRUE, 1, VK_ESCAPE, WORD(MapVirtualKey(VK_ESCAPE, MAPVK_VK_TO_VSC)), VK_ESCAPE, 0 } };
	static const INPUT_RECORD ESC_UP = { KEY_EVENT, { FALSE, 1, VK_ESCAPE, WORD(MapVirtualKey(VK_ESCAPE, MAPVK_VK_TO_VSC)), VK_ESCAPE, 0 } };
	static const INPUT_RECORD RET_DOWN = { KEY_EVENT, { TRUE, 1, VK_RETURN, WORD(MapVirtualKey(VK_RETURN, MAPVK_VK_TO_VSC)), VK_RETURN, 0 } };
	static const INPUT_RECORD RET_UP = { KEY_EVENT, { FALSE, 1, VK_RETURN, WORD(MapVirtualKey(VK_RETURN, MAPVK_VK_TO_VSC)), VK_RETURN, 0 } };

	vector<INPUT_RECORD> inputs(0);
	inputs.reserve(command.size() + 4);
	inputs.push_back(ESC_DOWN);
	inputs.push_back(ESC_UP);

	for (auto c : command)
	{
		INPUT_RECORD ir;
		ir.EventType = KEY_EVENT;
		ir.Event.KeyEvent.bKeyDown = TRUE;
		ir.Event.KeyEvent.wRepeatCount = 1;
		string name(1, toupper(c));
		auto vkc = nameToKey(name);
		ir.Event.KeyEvent.wVirtualKeyCode = vkc;
		ir.Event.KeyEvent.wVirtualScanCode = MapVirtualKey(vkc, MAPVK_VK_TO_VSC);
		ir.Event.KeyEvent.uChar.UnicodeChar = c;
		ir.Event.KeyEvent.dwControlKeyState = 0;

		inputs.push_back(ir);
	}
	inputs.push_back(RET_DOWN);
	inputs.push_back(RET_UP);

	// Open the console input buffer directly so this works even when stdin has been
	// redirected to a pipe (e.g. when launched as a child process by the GUI).
	HANDLE hConIn = CreateFileA("CONIN$", GENERIC_READ | GENERIC_WRITE,
	  FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
	if (hConIn == INVALID_HANDLE_VALUE)
	{
		hConIn = GetStdHandle(STD_INPUT_HANDLE); // fallback for consoleless environments
	}

	DWORD written = 0;
	if (WriteConsoleInput(hConIn, inputs.data(), inputs.size(), &written) == FALSE)
	{
		auto err = GetLastError();
		CERR << "Error writing to console input: " << err << '\n';
	}
	FlushConsoleInputBuffer(hConIn);
	if (hConIn != GetStdHandle(STD_INPUT_HANDLE))
	{
		CloseHandle(hConIn);
	}
	return written == inputs.size();
}

BOOL WINAPI ConsoleCtrlHandler(DWORD dwCtrlType)
{
	// https://docs.microsoft.com/en-us/windows/console/handlerroutine
	switch (dwCtrlType)
	{
	case CTRL_C_EVENT:
	case CTRL_BREAK_EVENT:
	case CTRL_CLOSE_EVENT:
		WriteToConsole("QUIT");
		return TRUE;
	}
	return FALSE;
};

// just setting up the console with standard stuff
void initConsole()
{
	AllocConsole();
	SetConsoleTitle(L"JoyShockMapper");
	// https://stackoverflow.com/a/15547699/1130520
	freopen_s((FILE**)stdin, "conin$", "r", stdin);
	freopen_s((FILE**)stdout, "conout$", "w", stdout);
	freopen_s((FILE**)stderr, "conout$", "w", stderr);
	SetConsoleCtrlHandler(&ConsoleCtrlHandler, TRUE);

	// ↓ FakerInput initialization
	getFakerBackend().init();
	if (getFakerBackend().isAvailable())
	{
		COUT << "FakerInput backend initialized successfully!\n";
	}
	else
	{
		COUT << "FakerInput init FAILED - falling back to SendInput\n";
	}
}

tuple<string, string> GetActiveWindowName()
{
	HWND activeWindow = GetForegroundWindow();
	if (activeWindow)
	{
		string module(256, '\0');
		string title(256, '\0');
		GetWindowTextA(activeWindow, &title[0], title.size()); // note: C++11 only
		title.resize(strlen(title.c_str()));
		DWORD pid;
		// https://stackoverflow.com/questions/14745320/get-active-processname-in-vc
		if (GetWindowThreadProcessId(activeWindow, &pid))
		{
			HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
			if (hProcess)
			{
				DWORD len = DWORD(module.size());
				if (QueryFullProcessImageNameA(hProcess, 0, &module[0], &len))
				{
					auto pos = module.find_last_of("\\");
					module = module.substr(pos + 1, module.size() - pos);
					module.resize(strlen(module.c_str()));
					if (title.empty())
					{
						title = module;
					}
				}
				CloseHandle(hProcess);
				return { module, title };
			}
		}
	}
	return { "", "" };
}

vector<string> ListDirectory(string directory)
{
	vector<string> fileListing;

	if (directory[directory.size() - 1] != '\\')
		directory.append("\\");
	directory.append("*");

	WIN32_FIND_DATAA ffd;
	auto hFind = FindFirstFileA(directory.c_str(), &ffd);

	if (hFind == INVALID_HANDLE_VALUE)
	{
		return {};
	}

	do
	{
		if ((ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0)
		{
			fileListing.push_back(ffd.cFileName);
		}
	} while (FindNextFileA(hFind, &ffd) != 0);

	auto dwError = GetLastError();
	if (dwError != ERROR_NO_MORE_FILES)
	{
		CERR << "Error code " << dwError << " raised with FindNextFile()\n";
	}

	FindClose(hFind);
	return fileListing;
}

string GetCWD()
{
	string cwd(MAX_PATH, '\0');
	GetCurrentDirectoryA(cwd.size(), &cwd[0]);
	cwd.resize(strlen(cwd.c_str()));
	return cwd;
}

bool SetCWD(string_view newCWD)
{
	return SetCurrentDirectoryA(newCWD.data()) == TRUE;
}

DWORD ShowOnlineHelp()
{
	COUT << "See the latest user manual at the web page below:\n"
	        "https://github.com/Electronicks/JoyShockMapper/blob/master/README.md\n";
	return 0;
}

void HideConsole()
{
	ShowWindow(GetConsoleWindow(), SW_HIDE);
}

void UnhideConsole()
{
	ShowWindow(GetConsoleWindow(), SW_SHOWMINIMIZED);
}

void ShowConsole()
{
	ShowWindow(GetConsoleWindow(), SW_SHOWDEFAULT);
	SetForegroundWindow(GetConsoleWindow());
}

void ReleaseConsole()
{
	::FreeConsole();
}

bool IsVisible()
{
	return IsWindowVisible(GetConsoleWindow());
}

bool isConsoleMinimized()
{
	return IsVisible() != FALSE && IsIconic(GetConsoleWindow()) != FALSE;
}

bool ClearConsole()
{
	HANDLE hStdout;

	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	DWORD mode = 0;
	if (!GetConsoleMode(hStdout, &mode))
	{
		return false;
	}

	const DWORD originalMode = mode;
	mode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;

	if (!SetConsoleMode(hStdout, mode))
	{
		return false;
	}

	DWORD written = 0;
	constexpr PCWSTR sequence = L"\x1b[2J\x1b[0;0H";
	if (!WriteConsoleW(hStdout, sequence, lstrlen(sequence), &written, NULL))
	{
		SetConsoleMode(hStdout, originalMode);
		return false;
	}

	SetConsoleMode(hStdout, originalMode);

	return true;
}

// ↓ FakerInput backend accessor (definition at end of file, declared at top)
FakerInputBackend& getFakerBackend()
{
	static FakerInputBackend instance;
	return instance;
}