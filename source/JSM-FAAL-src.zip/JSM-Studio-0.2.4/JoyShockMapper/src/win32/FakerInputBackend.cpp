#include "FakerInputBackend.h"
#include <windows.h>
#include <cstdio>

typedef void* FIC;
typedef FIC (*PFN_alloc)(void);
typedef int (*PFN_connect)(FIC);
typedef void (*PFN_disconnect)(FIC);
typedef void (*PFN_free)(FIC);
typedef void (*PFN_rel)(FIC, unsigned char, short, short, char, char);

static HMODULE g_dll = NULL;
static FIC g_cli = NULL;
static PFN_rel g_rel = NULL;
static PFN_disconnect g_disc = NULL;
static PFN_free g_fre = NULL;

FakerInputBackend::FakerInputBackend()
  : hDevice_(INVALID_HANDLE_VALUE)
  , currentButtons_(0)
{
}

FakerInputBackend::~FakerInputBackend()
{
	shutdown();
}

bool FakerInputBackend::init()
{
	if (g_cli)
	{
		hDevice_ = (HANDLE)1;
		return true;
	}

	g_dll = LoadLibraryW(L"FakerInputDll.dll");
	if (!g_dll)
	{
		fprintf(stderr, "FakerInput: LoadLibrary failed, error=%lu\n", GetLastError());
		return false;
	}

	auto alloc = (PFN_alloc)GetProcAddress(g_dll, "fakerinput_alloc");
	auto conn = (PFN_connect)GetProcAddress(g_dll, "fakerinput_connect");
	g_disc = (PFN_disconnect)GetProcAddress(g_dll, "fakerinput_disconnect");
	g_fre = (PFN_free)GetProcAddress(g_dll, "fakerinput_free");
	g_rel = (PFN_rel)GetProcAddress(g_dll, "fakerinput_update_relative_mouse");

	if (!alloc || !conn || !g_disc || !g_fre || !g_rel)
	{
		fprintf(stderr, "FakerInput: Failed to resolve DLL functions\n");
		FreeLibrary(g_dll);
		g_dll = NULL;
		return false;
	}

	g_cli = alloc();
	if (!g_cli)
	{
		fprintf(stderr, "FakerInput: alloc failed\n");
		FreeLibrary(g_dll);
		g_dll = NULL;
		return false;
	}

	int result = conn(g_cli);
	if (result == 0)
	{
		fprintf(stderr, "FakerInput: connect failed (returned 0)\n");
		g_fre(g_cli);
		g_cli = NULL;
		FreeLibrary(g_dll);
		g_dll = NULL;
		return false;
	}

	hDevice_ = (HANDLE)1;
	fprintf(stderr, "FakerInput: DLL backend initialized successfully!\n");
	return true;
}

void FakerInputBackend::shutdown()
{
	if (g_cli)
	{
		if (g_disc)
			g_disc(g_cli);
		if (g_fre)
			g_fre(g_cli);
		g_cli = NULL;
	}
	if (g_dll)
	{
		FreeLibrary(g_dll);
		g_dll = NULL;
	}
	g_rel = NULL;
	g_disc = NULL;
	g_fre = NULL;
	hDevice_ = INVALID_HANDLE_VALUE;
	currentButtons_ = 0;
}

void FakerInputBackend::sendReport(int x, int y)
{
	if (g_cli && g_rel)
	{
		g_rel(g_cli, (unsigned char)(currentButtons_ & 0x1F),
		  (short)x, (short)y, 0, 0);
	}
}

void FakerInputBackend::moveRelative(int x, int y)
{
	sendReport(x, y);
}

void FakerInputBackend::pressButton(int vkKey, bool pressed)
{
	uint8_t bit = vkToButtonBit(vkKey);
	if (bit == 0)
		return;
	if (pressed)
		currentButtons_ |= bit;
	else
		currentButtons_ &= ~bit;
	sendReport(0, 0);
}

void FakerInputBackend::scroll(int amount)
{
	if (!g_cli || !g_rel)
		return;
	char w = (char)(amount > 127 ? 127 : (amount < -127 ? -127 : amount));
	g_rel(g_cli, (unsigned char)(currentButtons_ & 0x1F), 0, 0, w, 0);
}

void FakerInputBackend::setButtons(uint8_t buttons)
{
	currentButtons_ = buttons & 0x1F;
	sendReport(0, 0);
}