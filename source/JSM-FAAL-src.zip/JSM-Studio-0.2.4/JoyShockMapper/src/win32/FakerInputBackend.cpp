#include "FakerInputBackend.h"
#include <windows.h>
#include <cstdio>

typedef void* FIC;
typedef FIC (*PFN_alloc)(void);
typedef bool (*PFN_connect)(FIC);
typedef void (*PFN_disconnect)(FIC);
typedef void (*PFN_free)(FIC);
typedef void (*PFN_rel)(FIC, unsigned char, short, short, char, char);
// Signature confirmed from the shipped DLL: rcx = client, dl = modifier byte,
// r8 = pointer to six HID usage bytes.
typedef bool (*PFN_kbd)(FIC, unsigned char, unsigned char*);

static HMODULE g_dll = NULL;
static FIC g_cli = NULL;
static PFN_rel g_rel = NULL;
static PFN_kbd g_kbd = NULL;
static PFN_disconnect g_disc = NULL;
static PFN_free g_fre = NULL;

// Windows virtual-key code -> HID usage. Returns 0 when unmapped, in which case
// the caller falls back to SendInput rather than silently dropping the key.
unsigned char vkToHidUsage(int vk)
{
	if (vk >= 'A' && vk <= 'Z')
		return (unsigned char)(0x04 + (vk - 'A'));
	if (vk >= '1' && vk <= '9')
		return (unsigned char)(0x1E + (vk - '1'));
	if (vk >= VK_F1 && vk <= VK_F12)
		return (unsigned char)(0x3A + (vk - VK_F1));
	if (vk >= VK_F13 && vk <= VK_F24)
		return (unsigned char)(0x68 + (vk - VK_F13));
	if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9)
	{
		if (vk == VK_NUMPAD0)
			return 0x62;
		return (unsigned char)(0x59 + (vk - VK_NUMPAD1));
	}
	switch (vk)
	{
	case '0': return 0x27;
	case VK_RETURN: return 0x28;
	case VK_ESCAPE: return 0x29;
	case VK_BACK: return 0x2A;
	case VK_TAB: return 0x2B;
	case VK_SPACE: return 0x2C;
	case VK_OEM_MINUS: return 0x2D;
	case VK_OEM_PLUS: return 0x2E;
	case VK_OEM_4: return 0x2F;
	case VK_OEM_6: return 0x30;
	case VK_OEM_5: return 0x31;
	case VK_OEM_1: return 0x33;
	case VK_OEM_7: return 0x34;
	case VK_OEM_3: return 0x35;
	case VK_OEM_COMMA: return 0x36;
	case VK_OEM_PERIOD: return 0x37;
	case VK_OEM_2: return 0x38;
	case VK_CAPITAL: return 0x39;
	case VK_SNAPSHOT: return 0x46;
	case VK_SCROLL: return 0x47;
	case VK_PAUSE: return 0x48;
	case VK_INSERT: return 0x49;
	case VK_HOME: return 0x4A;
	case VK_PRIOR: return 0x4B;
	case VK_DELETE: return 0x4C;
	case VK_END: return 0x4D;
	case VK_NEXT: return 0x4E;
	case VK_RIGHT: return 0x4F;
	case VK_LEFT: return 0x50;
	case VK_DOWN: return 0x51;
	case VK_UP: return 0x52;
	case VK_NUMLOCK: return 0x53;
	case VK_DIVIDE: return 0x54;
	case VK_MULTIPLY: return 0x55;
	case VK_SUBTRACT: return 0x56;
	case VK_ADD: return 0x57;
	case VK_DECIMAL: return 0x63;
	case VK_LSHIFT: return 0xE1;
	case VK_RSHIFT: return 0xE5;
	case VK_SHIFT: return 0xE1;
	case VK_LCONTROL: return 0xE0;
	case VK_RCONTROL: return 0xE4;
	case VK_CONTROL: return 0xE0;
	case VK_LMENU: return 0xE2;
	case VK_RMENU: return 0xE6;
	case VK_MENU: return 0xE2;
	case VK_LWIN: return 0xE3;
	case VK_RWIN: return 0xE7;
	default: return 0;
	}
}

FakerInputBackend::FakerInputBackend()
  : hDevice_(INVALID_HANDLE_VALUE)
  , currentButtons_(0)
{
}

FakerInputBackend::~FakerInputBackend()
{
	shutdown();
}

bool FakerInputBackend::init()
{
	if (g_cli)
	{
		hDevice_ = (HANDLE)1;
		return true;
	}

	g_dll = LoadLibraryW(L"FakerInputDll.dll");
	if (!g_dll)
	{
		fprintf(stderr, "FakerInput: LoadLibrary failed, error=%lu\n", GetLastError());
		return false;
	}

	auto alloc = (PFN_alloc)GetProcAddress(g_dll, "fakerinput_alloc");
	auto conn = (PFN_connect)GetProcAddress(g_dll, "fakerinput_connect");
	g_disc = (PFN_disconnect)GetProcAddress(g_dll, "fakerinput_disconnect");
	g_fre = (PFN_free)GetProcAddress(g_dll, "fakerinput_free");
	g_rel = (PFN_rel)GetProcAddress(g_dll, "fakerinput_update_relative_mouse");
	g_kbd = (PFN_kbd)GetProcAddress(g_dll, "fakerinput_update_keyboard");

	if (!alloc || !conn || !g_disc || !g_fre || !g_rel)
	{
		fprintf(stderr, "FakerInput: Failed to resolve DLL functions\n");
		FreeLibrary(g_dll);
		g_dll = NULL;
		return false;
	}

	g_cli = alloc();
	if (!g_cli)
	{
		fprintf(stderr, "FakerInput: alloc failed\n");
		FreeLibrary(g_dll);
		g_dll = NULL;
		return false;
	}

	int result = conn(g_cli);
	if (result == 0)
	{
		fprintf(stderr, "FakerInput: connect failed (returned 0)\n");
		g_fre(g_cli);
		g_cli = NULL;
		FreeLibrary(g_dll);
		g_dll = NULL;
		return false;
	}

	hDevice_ = (HANDLE)1;
	keyboardReady_ = (g_kbd != NULL);
	fprintf(stderr, "FakerInput: DLL backend initialized successfully! keyboard=%s\n",
	  keyboardReady_ ? "yes" : "no");
	return true;
}

void FakerInputBackend::shutdown()
{
	if (g_cli)
	{
		if (g_disc)
			g_disc(g_cli);
		if (g_fre)
			g_fre(g_cli);
		g_cli = NULL;
	}
	if (g_dll)
	{
		FreeLibrary(g_dll);
		g_dll = NULL;
	}
	g_rel = NULL;
	g_kbd = NULL;
	g_disc = NULL;
	g_fre = NULL;
	hDevice_ = INVALID_HANDLE_VALUE;
	currentButtons_ = 0;
	keyboardReady_ = false;
	keyboardSentModifiers_ = 0xFF;
	for (int i = 0; i < 6; i++)
		keyboardSentKeys_[i] = 0xFF;
}

void FakerInputBackend::sendReport(int x, int y)
{
	if (g_cli && g_rel)
	{
		g_rel(g_cli, (unsigned char)(currentButtons_ & 0x1F),
		  (short)x, (short)y, 0, 0);
	}
}

void FakerInputBackend::moveRelative(int x, int y)
{
	sendReport(x, y);
}

void FakerInputBackend::pressButton(int vkKey, bool pressed)
{
	uint8_t bit = vkToButtonBit(vkKey);
	if (bit == 0)
		return;
	if (pressed)
		currentButtons_ |= bit;
	else
		currentButtons_ &= ~bit;
	sendReport(0, 0);
}

void FakerInputBackend::scroll(int amount)
{
	if (!g_cli || !g_rel)
		return;
	char w = (char)(amount > 127 ? 127 : (amount < -127 ? -127 : amount));
	g_rel(g_cli, (unsigned char)(currentButtons_ & 0x1F), 0, 0, w, 0);
}

void FakerInputBackend::setButtons(uint8_t buttons)
{
	currentButtons_ = buttons & 0x1F;
	sendReport(0, 0);
}

// ---------------------------------------------------------------------------
//  Keyboard
// ---------------------------------------------------------------------------
void FakerInputBackend::sendKeyboardReport()
{
	if (!keyboardReady_)
		return;

	bool changed = (keyboardModifiers_ != keyboardSentModifiers_);
	for (int i = 0; i < 6 && !changed; i++)
	{
		if (keyboardKeys_[i] != keyboardSentKeys_[i])
			changed = true;
	}
	if (!changed)
		return; // the whole point: never write the same state twice

	g_kbd(g_cli, keyboardModifiers_, keyboardKeys_);
	keyboardSentModifiers_ = keyboardModifiers_;
	for (int i = 0; i < 6; i++)
		keyboardSentKeys_[i] = keyboardKeys_[i];
}

void FakerInputBackend::pressKey(int vkKey, bool pressed)
{
	if (!keyboardReady_ || g_cli == NULL)
		return;

	unsigned char usage = vkToHidUsage(vkKey);
	if (usage == 0)
		return;

	if (usage >= 0xE0 && usage <= 0xE7)
	{
		unsigned char bit = (unsigned char)(1u << (usage - 0xE0));
		if (pressed)
			keyboardModifiers_ |= bit;
		else
			keyboardModifiers_ &= (unsigned char)~bit;
	}
	else
	{
		if (pressed)
		{
			for (int i = 0; i < 6; i++)
			{
				if (keyboardKeys_[i] == usage)
					return; // already held
			}
			for (int i = 0; i < 6; i++)
			{
				if (keyboardKeys_[i] == 0)
				{
					keyboardKeys_[i] = usage;
					break;
				}
			}
		}
		else
		{
			for (int i = 0; i < 6; i++)
			{
				if (keyboardKeys_[i] == usage)
					keyboardKeys_[i] = 0;
			}
		}
	}

	sendKeyboardReport();
}