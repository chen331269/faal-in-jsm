#include "faal_filter.h"

#include <atomic>
#include <cstdio>

namespace
{
	struct FaalTraceSample
	{
		float dt, gx, gy, gz;
		float signChangeThr, freezeDurationSec, enableVectorReversal, smoothTimeSec;
		// v2: everything needed to re-derive the 2D values in any gyro space offline.
		float rawX, rawY, rawZ;       // calibrated gyro before the space transform
		float gravX, gravY, gravZ;    // gravity estimate that frame
		float quatW, quatX, quatY, quatZ;
		float outX, outY, outZ;       // what actually left the filter
	};

	const size_t kFaalTraceCapacity = 150000; // ≈150 s at 1000 Hz, ≈10.2 MB
	FaalTraceSample* s_traceSamples = nullptr;
	// Written on the polling thread, read/replaced on the command thread.
	std::atomic<size_t> s_traceCount{ 0 };
	std::atomic<bool> s_traceRecording{ false };
	FaalParams s_lastParams{};
}

void FaalTraceStart()
{
	if (s_traceRecording.load(std::memory_order_acquire))
		return; // already recording: keep what we have
	if (s_traceSamples == nullptr)
		s_traceSamples = new FaalTraceSample[kFaalTraceCapacity];
	s_traceCount.store(0, std::memory_order_relaxed);
	s_traceRecording.store(true, std::memory_order_release);
}

bool FaalTraceIsRecording()
{
	return s_traceRecording.load(std::memory_order_acquire);
}

unsigned long long FaalTraceRecordedFrames()
{
	return (unsigned long long)s_traceCount.load(std::memory_order_acquire);
}

void FaalTraceRecord(const FaalTraceInput& in, const FaalParams& applied)
{
	s_lastParams = applied;
	if (!s_traceRecording.load(std::memory_order_relaxed))
		return;
	const size_t index = s_traceCount.load(std::memory_order_relaxed);
	if (index >= kFaalTraceCapacity)
		return;
	FaalTraceSample& s = s_traceSamples[index];
	s.dt = in.dt;
	s.gx = in.gyroX;
	s.gy = in.gyroY;
	s.gz = in.gyroZ;
	s.signChangeThr = applied.signChangeThr;
	s.freezeDurationSec = applied.freezeDurationSec;
	s.enableVectorReversal = applied.enableVectorReversal;
	s.smoothTimeSec = applied.smoothTimeSec;
	s.rawX = in.rawX;
	s.rawY = in.rawY;
	s.rawZ = in.rawZ;
	s.gravX = in.gravX;
	s.gravY = in.gravY;
	s.gravZ = in.gravZ;
	s.quatW = in.quatW;
	s.quatX = in.quatX;
	s.quatY = in.quatY;
	s.quatZ = in.quatZ;
	s.outX = in.outX;
	s.outY = in.outY;
	s.outZ = in.outZ;
	s_traceCount.store(index + 1, std::memory_order_release);
}

unsigned long long FaalTraceStopAndWrite(const char* path)
{
	// Stop first: the polling thread checks this flag before every write, so no
	// new samples land after this point (the buffer itself is never freed, so a
	// sample racing with us is at worst not included).
	s_traceRecording.store(false, std::memory_order_release);
	if (s_traceSamples == nullptr)
		return 0;
	const size_t count = s_traceCount.load(std::memory_order_acquire);
	if (count == 0)
		return 0;

	FILE* f = fopen(path, "wb");
	if (f == nullptr)
		return 0;

	const FaalParams& p = s_lastParams;
	fprintf(f, "# faal-trace v2\n");
	fprintf(f, "# rise=%g fall=%g peakdecay=%g drift=%g fcemin=%g beta=%g magratio=%g angle=%g "
	           "drop=%g curve=%g peakmin=%g suppressThr=%g freezeMul=%g driftthr=%g drift_on=%d\n",
	  p.hystRiseTime, p.hystFallTime, p.peakDecayTime, p.driftHoldTimeSec,
	  p.oneEuroFcMin, p.oneEuroBeta, p.dirChangeMagRatio, p.dirChangeAngleRad,
	  p.dropSensitivity, p.dropCurve, p.peakMinTrigger, p.suppressThr,
	  p.freezeOutMul, p.driftThreshold, p.enableDriftHold ? 1 : 0);
	fprintf(f, "dt,gx,gy,gz,sign_thr,freeze_dur,rev_on,smooth_time,"
	           "raw_x,raw_y,raw_z,grav_x,grav_y,grav_z,quat_w,quat_x,quat_y,quat_z,out_x,out_y,out_z\n");

	const size_t n = count;
	for (size_t i = 0; i < n; ++i)
	{
		const FaalTraceSample& s = s_traceSamples[i];
		fprintf(f, "%.6f,%.4f,%.4f,%.4f,%.4f,%.4f,%.1f,%.6f,"
		           "%.4f,%.4f,%.4f,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f,%.4f,%.4f,%.4f\n",
		  s.dt, s.gx, s.gy, s.gz, s.signChangeThr, s.freezeDurationSec,
		  s.enableVectorReversal, s.smoothTimeSec,
		  s.rawX, s.rawY, s.rawZ, s.gravX, s.gravY, s.gravZ,
		  s.quatW, s.quatX, s.quatY, s.quatZ, s.outX, s.outY, s.outZ);
	}
	fclose(f);

	s_traceCount.store(0, std::memory_order_relaxed);
	return (unsigned long long)n;
}
