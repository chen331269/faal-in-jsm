#include "JoyShockMapper.h"
#include "JSMVersion.h"
#include "DigitalButton.h"
#include "InputHelpers.h"
#include "Whitelister.h"
#include "TrayIcon.h"
#include "JSMAssignment.hpp"
#include "Gamepad.h"
#include "AutoLoad.h"
#include "AutoConnect.h"
#include "SettingsManager.h"
#include "JoyShock.h"
#include "Telemetry.h"
#include "NaturalCurve.h"
#include "PowerCurve.h"
#include "QuadraticCurve.h"
#include "SigmoidCurve.h"
#include "JumpCurve.h"
#include <filesystem>
#include <algorithm>
#include <atomic>
#include <deque>
#include <unordered_map>
#include <sstream>
#define _USE_MATH_DEFINES
#include <math.h> // M_PI
#include "faal_filter.h"
#include "PlatformDefinitions.h"

#ifdef _WIN32
#include <shellapi.h>
#else
#define UCHAR unsigned char
#include <algorithm>
#include <unistd.h>
#endif

#pragma warning(disable : 4996) // Disable deprecated API warnings

std::string NONAME;
shared_ptr<JslWrapper> jsl;
unique_ptr<TrayIcon> tray;
unique_ptr<Whitelister> whitelister;

vector<JSMButton> grid_mappings; // array of virtual _buttons on the touchpad grid
vector<JSMButton> mappings;      // array enables use of for each loop and other i/f

float os_mouse_speed = 1.0;
float last_flick_and_rotation = 0.0;
bool gyroOneEuroEnabled = false;
unique_ptr<PollingThread> autoLoadThread;
unique_ptr<JSM::AutoConnect> autoConnectThread;
std::atomic<int> g_gyroGlobalOffCount(0);
std::atomic<int> g_gyroGlobalOnCount(0);
std::atomic_bool g_hasGyroOnAllBinding(false);
vector<pair<int, int>> g_ignoreGyroVidPid;
unique_ptr<PollingThread> minimizeThread;
bool devicesCalibrating = false;
bool g_manualConnectMode = false;
unordered_map<int, shared_ptr<JoyShock>> handle_to_joyshock;

int input_pipe_fd[2];
int triggerCalibrationStep = 0;

static void UpdateIgnoredGyroDevices()
{
	g_ignoreGyroVidPid.clear();
	try
	{
		auto ignoreStr = SettingsManager::get<string>(SettingID::IGNORE_GYRO_DEVICES)->value();
		stringstream ss(ignoreStr);
		string token;
		while (ss >> token)
		{
			auto colon = token.find(':');
			if (colon == string::npos)
			{
				continue;
			}
			string vidStr = token.substr(0, colon);
			string pidStr = token.substr(colon + 1);
			try
			{
				int vid = stoi(vidStr, nullptr, 0);
				int pid = stoi(pidStr, nullptr, 0);
				if (vid > 0 && pid > 0)
				{
					g_ignoreGyroVidPid.emplace_back(vid, pid);
				}
			}
			catch (...)
			{
				continue;
			}
		}
	}
	catch (...)
	{
	}

	for (auto &entry : handle_to_joyshock)
	{
		auto &dev = entry.second;
		dev->_ignoreGyro = false;
		for (auto &pair : g_ignoreGyroVidPid)
		{
			if (dev->_vendorId == pair.first && dev->_productId == pair.second)
			{
				dev->_ignoreGyro = true;
				break;
			}
		}
	}
}

static void RefreshTelemetrySettings()
{
	auto telemetryEnabled = SettingsManager::get<Switch>(SettingID::TELEMETRY_ENABLED);
	auto telemetryPort = SettingsManager::get<int>(SettingID::TELEMETRY_PORT);
	if (!telemetryEnabled || !telemetryPort)
	{
		return;
	}

	int portValue = std::clamp(telemetryPort->value(), 1, 65535);
	const bool enabled = telemetryEnabled->value() == Switch::ON;
	Telemetry::Configure(enabled, static_cast<uint16_t>(portValue));
}

static string sanitizeControllerInfoName(string name)
{
	for (char &character : name)
	{
		if (character == '\t' || character == '\r' || character == '\n')
		{
			character = ' ';
		}
	}
	return name;
}

struct TOUCH_POINT
{
	TOUCH_POINT() = default;
	TOUCH_POINT(optional<FloatXY> newState, optional<FloatXY> prevState, FloatXY tpSize)
	{
		if (newState)
		{
			posX = newState->x(); // Absolute position in percentage
			posY = newState->y();
			if (prevState)
			{
				movX = int16_t((newState->x() - prevState->x()) * tpSize.x()); // Relative movement in unit
				movY = int16_t((newState->y() - prevState->y()) * tpSize.y());
			}
		}
	}
	float posX = -1.f;
	float posY = -1.f;
	short movX = 0;
	short movY = 0;
	inline bool isDown()
	{
		return posX >= 0.f && posX <= 1.f && posY >= 0.f && posY <= 1.f;
	}
};
// void DisplayTouchInfo(int id, optional<FloatXY> xy, optional<FloatXY> prevXY = nullopt)
//{
//	if (xy)
//	{
//		if (!prevXY)
//		{
//			cout << "New touch " << id << " at " << *xy << '\n';
//		}
//		else if (fabsf(xy->x() - prevXY->x()) > FLT_EPSILON || fabsf(xy->y() - prevXY->y()) > FLT_EPSILON)
//		{
//			cout << "Touch " << id << " moved to " << *xy << '\n';
//		}
//	}
//	else if (prevXY)
//	{
//		cout << "Touch " << id << " has been released\n";
//	}
// }

void touchCallback(int jcHandle, TOUCH_STATE newState, TOUCH_STATE prevState, float delta_time)
{

	// if (current.t0Down || previous.t0Down)
	//{
	//	DisplayTouchInfo(newState.t0Down ? newState.t0Id : prevState.t0Id,
	//	  newState.t0Down ? optional<FloatXY>({ newState.t0X, newState.t0Y }) : nullopt,
	//	  prevState.t0Down ? optional<FloatXY>({ prevState.t0X, prevState.t0Y }) : nullopt);
	//}

	//if (newState.t1Down || prevState.t1Down)
	//{
	//	DisplayTouchInfo(newState.t1Down ? newState.t1Id : prevState.t1Id,
	//	  newState.t1Down ? optional<FloatXY>({ newState.t1X, newState.t1Y }) : nullopt,
	//	  prevState.t1Down ? optional<FloatXY>({ prevState.t1X, prevState.t1Y }) : nullopt);
	//}

	shared_ptr<JoyShock> js = handle_to_joyshock[jcHandle];
	int tpSizeX, tpSizeY;
	if (!js || jsl->GetTouchpadDimension(jcHandle, tpSizeX, tpSizeY) == false)
		return;
	FloatXY tpSize{ float(tpSizeX), float(tpSizeY) };

	lock_guard guard(js->_context->callback_lock);

	TOUCH_POINT point0(newState.t0Down ? make_optional<FloatXY>(newState.t0X, newState.t0Y) : nullopt,
	  prevState.t0Down ? make_optional<FloatXY>(prevState.t0X, prevState.t0Y) : nullopt, tpSize);

	TOUCH_POINT point1(newState.t1Down ? make_optional<FloatXY>(newState.t1X, newState.t1Y) : nullopt,
	  prevState.t1Down ? make_optional<FloatXY>(prevState.t1X, prevState.t1Y) : nullopt, tpSize);

	auto mode = js->getSetting<TouchpadMode>(SettingID::TOUCHPAD_MODE);
	// js->handleButtonChange(ButtonID::TOUCH, point0.isDown() || point1.isDown()); // This is handled by dual stage "trigger" step
	if (!point0.isDown() && !point1.isDown())
	{

		static const function<bool(ButtonID)> IS_TOUCH_BUTTON = [](ButtonID id)
		{
			return id >= ButtonID::T1;
		};

		for (auto currentlyActive = find_if(js->_context->chordStack.begin(), js->_context->chordStack.end(), IS_TOUCH_BUTTON);
		     currentlyActive != js->_context->chordStack.end();
		     currentlyActive = find_if(js->_context->chordStack.begin(), js->_context->chordStack.end(), IS_TOUCH_BUTTON))
		{
			js->_context->chordStack.erase(currentlyActive);
		}
	}
	if (mode == TouchpadMode::GRID_AND_STICK)
	{
		auto &grid_size = *SettingsManager::getV<FloatXY>(SettingID::GRID_SIZE);
		// Handle grid
		int index0 = -1, index1 = -1;
		if (point0.isDown())
		{
			point0.posY += 1e-6f;
			float row = ceilf(point0.posY * grid_size.value().y()) - 1.f;
			float col = ceilf(point0.posX * grid_size.value().x()) - 1.f;
			// COUT << "I should be in button " << row << " " << col << '\n';
			index0 = int(row * grid_size.value().x() + col);
		}

		if (point1.isDown())
		{
			float row = ceilf(point1.posY * grid_size.value().y()) - 1.f;
			float col = ceilf(point1.posX * grid_size.value().x()) - 1.f;
			// COUT << "I should be in button " << row << " " << col << '\n';
			index1 = int(row * grid_size.value().x() + col);
		}

		for (size_t i = 0; i < grid_mappings.size(); ++i)
		{
			auto optId = magic_enum::enum_cast<ButtonID>(int(FIRST_TOUCH_BUTTON + i));

			// JSM can get touch button callbacks before the grid _buttons are setup at startup. Just skip then.
			if (optId && js->_gridButtons.size() == grid_mappings.size())
				js->handleButtonChange(*optId, i == index0 || i == index1);
		}

		// Handle stick
		js->handleTouchStickChange(js->_touchpads[0], point0.isDown(), point0.movX, point0.movY, delta_time);
		js->handleTouchStickChange(js->_touchpads[1], point1.isDown(), point1.movX, point1.movY, delta_time);
	}
	else if (mode == TouchpadMode::MOUSE)
	{
		// Disable gestures
		// if (point0.isDown() && point1.isDown())
		//{
		// if (prevState.t0Down && prevState.t1Down)
		//{
		//	float x = fabsf(newState.t0X - newState.t1X);
		//	float y = fabsf(newState.t0Y - newState.t1Y);
		//	float angle = atan2f(y, x) / PI * 360;
		//	float dist = sqrt(x * x + y * y);
		//	x = fabsf(prevState.t0X - prevState.t1X);
		//	y = fabsf(prevState.t0Y - prevState.t1Y);
		//	float oldAngle = atan2f(y, x) / PI * 360;
		//	float oldDist = sqrt(x * x + y * y);
		//	if (angle != oldAngle)
		//		DEBUG_LOG << "Angle went from " << oldAngle << " degrees to " << angle << " degress. Diff is " << angle - oldAngle << " degrees. ";
		//	js->_touchScrollX.processScroll(angle - oldAngle, js->getSetting<FloatXY>(SettingID::SCROLL_SENS).x(), js->_timeNow);
		//	if (dist != oldDist)
		//		DEBUG_LOG << "Dist went from " << oldDist << " points to " << dist << " points. Diff is " << dist - oldDist << " points. ";
		//	js->_touchScrollY.processScroll(dist - oldDist, js->getSetting<FloatXY>(SettingID::SCROLL_SENS).y(), js->_timeNow);
		//}
		// else
		//{
		//	js->_touchScrollX.reset(js->_timeNow);
		//	js->_touchScrollY.reset(js->_timeNow);
		//}
		//}
		// else
		//{
		//	js->_touchScrollX.reset(js->_timeNow);
		//	js->_touchScrollY.reset(js->_timeNow);
		//  if (point0.isDown() ^ point1.isDown()) // XOR
		if (point0.isDown() || point1.isDown())
		{
			TOUCH_POINT *downPoint = point0.isDown() ? &point0 : &point1;
			FloatXY sens = js->getSetting<FloatXY>(SettingID::TOUCHPAD_SENS);
			// if(downPoint->movX || downPoint->movY) cout << "Moving the cursor by " << dec << int(downPoint->movX) << " h and " << int(downPoint->movY) << " v\n";
			moveMouse(downPoint->movX * sens.x(), downPoint->movY * sens.y());
			// Ignore second touch point in this mode for now until gestures gets handled here
		}
		//}
	}
	else if (mode == TouchpadMode::PS_TOUCHPAD)
	{
		if (js->hasVirtualController())
		{
			optional<FloatXY> p0 = newState.t0Down ? make_optional<FloatXY>(newState.t0X, newState.t0Y) : nullopt;
			optional<FloatXY> p1 = newState.t1Down ? make_optional<FloatXY>(newState.t1X, newState.t1Y) : nullopt;
			js->_context->_vigemController->setTouchState(p0, p1);
		}
	}
}

void calibrateTriggers(shared_ptr<JoyShock> jc)
{
	if (jsl->GetButtons(jc->_handle) & (1ULL << JSOFFSET_HOME))
	{
		COUT << "Abandonning calibration\n";
		triggerCalibrationStep = 0;
		return;
	}

	auto rpos = jsl->GetRightTrigger(jc->_handle);
	auto lpos = jsl->GetLeftTrigger(jc->_handle);
	auto tick_time = *SettingsManager::get<float>(SettingID::TICK_TIME);
	static auto &right_trigger_offset = *SettingsManager::getV<int>(SettingID::RIGHT_TRIGGER_OFFSET);
	static auto &right_trigger_range = *SettingsManager::getV<int>(SettingID::RIGHT_TRIGGER_RANGE);
	static auto &left_trigger_offset = *SettingsManager::getV<int>(SettingID::LEFT_TRIGGER_OFFSET);
	static auto &left_trigger_range = *SettingsManager::getV<int>(SettingID::LEFT_TRIGGER_RANGE);
	switch (triggerCalibrationStep)
	{
	case 1:
		COUT << "Softly press on the right trigger until you just feel the resistance.\n";
		COUT << "Then press the dpad down button to proceed, or press HOME to abandon.\n";
		tick_time.set(100.f);
		jc->_rightEffect.mode = AdaptiveTriggerMode::SEGMENT;
		jc->_rightEffect.start = 0;
		jc->_rightEffect.end = 255;
		jc->_rightEffect.force = 255;
		triggerCalibrationStep++;
		break;
	case 2:
		if (jsl->GetButtons(jc->_handle) & (1ULL << JSOFFSET_DOWN))
		{
			triggerCalibrationStep++;
		}
		break;
	case 3:
		DEBUG_LOG << "trigger pos is at " << int(rpos * 255.f) << " (" << int(rpos * 100.f) << "%) and effect pos is at " << int(jc->_rightEffect.start) << '\n';
		if (int(rpos * 255.f) > 0)
		{
			right_trigger_offset.set(jc->_rightEffect.start);
			tick_time.set(40);
			triggerCalibrationStep++;
		}
		++jc->_rightEffect.start;
		break;
	case 4:
		DEBUG_LOG << "trigger pos is at " << int(rpos * 255.f) << " (" << int(rpos * 100.f) << "%) and effect pos is at " << int(jc->_rightEffect.start) << '\n';
		if (int(rpos * 255.f) > 240)
		{
			tick_time.set(100);
			triggerCalibrationStep++;
		}
		++jc->_rightEffect.start;
		break;
	case 5:
		DEBUG_LOG << "trigger pos is at " << int(rpos * 255.f) << " (" << int(rpos * 100.f) << "%) and effect pos is at " << int(jc->_rightEffect.start) << '\n';
		if (int(rpos * 255.f) == 255)
		{
			triggerCalibrationStep++;
			right_trigger_range.set(int(jc->_rightEffect.start - right_trigger_offset));
		}
		++jc->_rightEffect.start;
		break;
	case 6:
		COUT << "Softly press on the left trigger until you just feel the resistance.\n";
		COUT << "Then press the cross button to proceed, or press HOME to abandon.\n";
		tick_time.set(100);
		jc->_leftEffect.mode = AdaptiveTriggerMode::SEGMENT;
		jc->_leftEffect.start = 0;
		jc->_leftEffect.end = 255;
		jc->_leftEffect.force = 255;
		triggerCalibrationStep++;
		break;
	case 7:
		if (jsl->GetButtons(jc->_handle) & (1ULL << JSOFFSET_S))
		{
			triggerCalibrationStep++;
		}
		break;
	case 8:
		DEBUG_LOG << "trigger pos is at " << int(lpos * 255.f) << " (" << int(lpos * 100.f) << "%) and effect pos is at " << int(jc->_leftEffect.start) << '\n';
		if (int(lpos * 255.f) > 0)
		{
			left_trigger_offset.set(jc->_leftEffect.start);
			tick_time.set(40);
			triggerCalibrationStep++;
		}
		++jc->_leftEffect.start;
		break;
	case 9:
		DEBUG_LOG << "trigger pos is at " << int(lpos * 255.f) << " (" << int(lpos * 100.f) << "%) and effect pos is at " << int(jc->_leftEffect.start) << '\n';
		if (int(lpos * 255.f) > 240)
		{
			tick_time.set(100);
			triggerCalibrationStep++;
		}
		++jc->_leftEffect.start;
		break;
	case 10:
		DEBUG_LOG << "trigger pos is at " << int(lpos * 255.f) << " (" << int(lpos * 100.f) << "%) and effect pos is at " << int(jc->_leftEffect.start) << '\n';
		if (int(lpos * 255.f) == 255)
		{
			triggerCalibrationStep++;
			left_trigger_range.set(int(jc->_leftEffect.start - left_trigger_offset));
		}
		++jc->_leftEffect.start;
		break;
	case 11:
		COUT << "Your triggers have been successfully calibrated. Add the trigger offset and range values in your OnReset.txt file to have those values set by default.\n";
		COUT_INFO << SettingID::RIGHT_TRIGGER_OFFSET << " = " << right_trigger_offset << '\n';
		COUT_INFO << SettingID::RIGHT_TRIGGER_RANGE << " = " << right_trigger_range << '\n';
		COUT_INFO << SettingID::LEFT_TRIGGER_OFFSET << " = " << left_trigger_offset << '\n';
		COUT_INFO << SettingID::LEFT_TRIGGER_RANGE << " = " << left_trigger_range << '\n';
		triggerCalibrationStep = 0;
		tick_time.reset();
		break;
	}
	jsl->SetTriggerEffect(jc->_handle, jc->_leftEffect, jc->_rightEffect);
}

// Pre-filtering for PS_MOTION: the game receives the raw gyro and applies its own
// space transform, so FAAL has to run *before* that transform. We evaluate JSM's
// PLAYER_TURN mapping here instead, filter those two scalars, and fold the result
// back into the 3D vector.
//
// Both directions are homogeneous: the delivered yaw is linear in (Y,Z) and the
// delivered pitch is linear in X, so multiplying (Y,Z) by s scales the game's yaw
// by exactly s, and multiplying X by s_p scales its pitch by exactly s_p — without
// having to replicate the game's math.
// Three modes (FAAL_PSMOTION_MODE):
//   0 OFF    — pass the calibrated gyro through untouched
//   1 PLAYER — the game does its own player-space transform, so we only scale its input
//   2 LOCAL  — the game reads local axes with no transform, so we run it for them

static int faalSettingAsInt(SettingID id, int fallback)
{
	auto s = SettingsManager::get<float>(id);
	return s ? (int)(s->value() + 0.5f) : fallback;
}

static void faalPlayerSpace2D(float rx, float ry, float rz, float gx, float gy, float gz,
  float &outYaw, float &outPitch)
{
	float len = sqrtf(gx * gx + gy * gy + gz * gz);
	float ny = 0.f, nz = 0.f;
	if (len > 0.f)
	{
		ny = gy / len;
		nz = gz / len;
	}
	float w = ny * ry + nz * rz;
	float s = (w < 0.f) ? -1.f : 1.f;
	float yz = sqrtf(ry * ry + rz * rz);
	const float yawRelaxFactor = 2.f; // same 60 degree buffer as the PLAYER_TURN block
	outYaw = s * fminf(fabsf(w) * yawRelaxFactor, yz);
	outPitch = -rx;
}

bool do_FAAL_PSMOTION()
{
	int mode = (faalSettingAsInt(SettingID::FAAL_PSMOTION_MODE, 1) + 1) % 3;
	if (auto s = SettingsManager::get<float>(SettingID::FAAL_PSMOTION_MODE)) s->set((float)mode);
	static const char *names[] = {
		"OFF (calibrated gyro passed through)",
		"PLAYER (game does the transform; we scale its input)",
		"LOCAL (we transform + filter, the game reads local axes)"
	};
	COUT << "FAAL PS_MOTION: " << names[mode] << '\n';
	return true;
}

extern bool g_smoothNativeFlickStick;

bool do_FAAL_STICKSMOOTH()
{
	g_smoothNativeFlickStick = !g_smoothNativeFlickStick;
	COUT << "FAAL native flick-stick smoothing: " << (g_smoothNativeFlickStick ? "ON" : "OFF") << '\n';
	return true;
}

bool do_FAAL_LOCALAXIS()
{
	int axis = 1 - faalSettingAsInt(SettingID::FAAL_LOCAL_TURN_AXIS, 0);
	if (auto s = SettingsManager::get<float>(SettingID::FAAL_LOCAL_TURN_AXIS)) s->set((float)axis);
	COUT << "FAAL local turn axis: " << (axis ? "Z (roll)" : "Y (yaw)") << '\n';
	return true;
}

void joyShockPollCallback(int jcHandle, JOY_SHOCK_STATE state, JOY_SHOCK_STATE lastState, IMU_STATE imuState, IMU_STATE lastImuState, float deltaTime)
{

	shared_ptr<JoyShock> jc = handle_to_joyshock[jcHandle];
	if (jc == nullptr)
		return;
	jc->_context->callback_lock.lock();

	auto timeNow = chrono::steady_clock::now();
	deltaTime = ((float)chrono::duration_cast<chrono::microseconds>(timeNow - jc->_timeNow).count()) / 1000000.0f;
	jc->_timeNow = timeNow;

	if (triggerCalibrationStep)
	{
		calibrateTriggers(jc);
		jc->_context->callback_lock.unlock();
		return;
	}

	MotionIf &motion = *jc->_motion;

	IMU_STATE imu = jsl->GetIMUState(jc->_handle);

	if (SettingsManager::getV<Switch>(SettingID::AUTO_CALIBRATE_GYRO)->value() == Switch::ON)
	{
		motion.SetAutoCalibration(true, 1.2f, 0.015f);
	}
	else
	{
		motion.SetAutoCalibration(false, 0.f, 0.f);
	}
	motion.ProcessMotion(imu.gyroX, imu.gyroY, imu.gyroZ, imu.accelX, imu.accelY, imu.accelZ, deltaTime);

	FaalParams p;

	// JoyShock::getSetting throws out_of_range when a setting is not registered.
	// That used to escape this callback while callback_lock was still held, which
	// terminates the process and leaves the lock taken. Keep the last good values
	// instead: a missing setting then degrades to "parameters stop updating".
	try
	{
		// 抑制系统（3 个用户参数）
		p.hystRiseTime = jc->getSetting(SettingID::FAAL_HYST_RISE_TIME);
		p.hystFallTime = jc->getSetting(SettingID::FAAL_HYST_FALL_TIME);
		p.peakDecayTime = jc->getSetting(SettingID::FAAL_PEAK_DECAY_TIME);

		// 独立参数
		p.freezeDurationSec = jc->getSetting(SettingID::FAAL_FREEZE_DURATION_SEC);
		p.driftHoldTimeSec = jc->getSetting(SettingID::FAAL_DRIFT_HOLD_TIME_SEC);
		p.signChangeThr = jc->getSetting(SettingID::FAAL_SIGN_CHANGE_THR);
		p.oneEuroFcMin = jc->getSetting(SettingID::FAAL_ONE_EURO_FC_MIN);
		p.oneEuroBeta = jc->getSetting(SettingID::FAAL_ONE_EURO_BETA);
		p.smoothThreshold = jc->getSetting(SettingID::FAAL_SMOOTH_THRESHOLD);
		p.enableVectorReversal = jc->getSetting(SettingID::FAAL_ENABLE_VECTOR_REVERSAL);
		p.dirChangeMagRatio = jc->getSetting(SettingID::FAAL_DIR_CHANGE_MAG_RATIO);
		p.dirChangeAngleRad = jc->getSetting(SettingID::FAAL_DIR_CHANGE_ANGLE_RAD);
		p.smoothTimeSec = jc->getSetting(SettingID::FAAL_SMOOTH_TIME_SEC);
	}
	catch (...)
	{
		p = GetFaalParams();
	}

	// 内部固定
	p.freezeOutMul = 0.18f;
	p.suppressThr = 0.45f;
	p.peakMinTrigger = 2.2f;
	p.dropSensitivity = 2.4f;
	p.dropCurve = 2.0f;

	SetFaalParams(p);

	float inGyroX, inGyroY, inGyroZ;
	motion.GetCalibratedGyro(inGyroX, inGyroY, inGyroZ);

	float rawGyroX = inGyroX, rawGyroY = inGyroY, rawGyroZ = inGyroZ;

	GyroOutput gyroOutput = jc->getSetting<GyroOutput>(SettingID::GYRO_OUTPUT);
	bool isDirectOutput = (gyroOutput == GyroOutput::PS_MOTION);

	float inGravX, inGravY, inGravZ;
	motion.GetGravity(inGravX, inGravY, inGravZ);

	float inQuatW, inQuatX, inQuatY, inQuatZ;
	motion.GetOrientation(inQuatW, inQuatX, inQuatY, inQuatZ);

	// What PS_MOTION will forward to the virtual controller (calibrated gyro,
	// optionally pre-filtered below). Acceleration is passed through untouched so
	// the game's own gravity estimate stays honest.
	float directGyroX = inGyroX, directGyroY = inGyroY, directGyroZ = inGyroZ;

	// Records everything the filter saw, plus the raw 3D signal and the gravity /
	// orientation it was derived from, so a session can be re-projected into any
	// gyro space offline.
	auto traceInput = [&](float gx, float gy, float gz, float ox, float oy, float oz)
	{
		FaalTraceInput in;
		in.dt = deltaTime;
		in.gyroX = gx;
		in.gyroY = gy;
		in.gyroZ = gz;
		in.outX = ox;
		in.outY = oy;
		in.outZ = oz;
		in.rawX = rawGyroX;
		in.rawY = rawGyroY;
		in.rawZ = rawGyroZ;
		in.gravX = inGravX;
		in.gravY = inGravY;
		in.gravZ = inGravZ;
		in.quatW = inQuatW;
		in.quatX = inQuatX;
		in.quatY = inQuatY;
		in.quatZ = inQuatZ;
		FaalTraceRecord(in, p);
	};

	if (isDirectOutput)
	{
		const int psMode = (int)(jc->getSetting(SettingID::FAAL_PSMOTION_MODE) + 0.5f);
		const int turnAxis = (int)(jc->getSetting(SettingID::FAAL_LOCAL_TURN_AXIS) + 0.5f);

		// Both modes start from the gravity-referenced pair: we want the player-space
		// quantity no matter what the game does later. PLAYER lets the game apply its own
		// transform on top; LOCAL writes our transformed result into the fixed axes it reads.
		float psYaw, psPitch;
		faalPlayerSpace2D(inGyroX, inGyroY, inGyroZ, inGravX, inGravY, inGravZ, psYaw, psPitch);
		const float origYaw = psYaw;
		const float origPitch = psPitch;

		faal_filter(psYaw, psPitch, deltaTime);

		if (psMode == 1)
		{
			// Player-space game: it will transform our input itself, so scale the axes it
			// reads. Multiplying (Y,Z) by s scales its yaw by s, X by s_p scales its pitch.
			float sYaw = (fabsf(origYaw) > 1e-3f) ? psYaw / origYaw : 1.f;
			float sPitch = (fabsf(origPitch) > 1e-3f) ? psPitch / origPitch : 1.f;
			sYaw = std::clamp(sYaw, 0.f, 1.f);
			sPitch = std::clamp(sPitch, 0.f, 1.f);
			directGyroX = inGyroX * sPitch;
			directGyroY = inGyroY * sYaw;
			directGyroZ = inGyroZ * sYaw;
		}
		else if (psMode == 2)
		{
			// Local-space game: it reads fixed axes with no transform of its own, so we hand
			// it a fully rewritten vector — pitch on X, the gravity-referenced turn on the
			// chosen axis, and nothing on the remaining one. Leaving the third axis at its
			// raw local value would leak untransformed roll straight into the game.
			directGyroX = -psPitch;
			// JSM's own yaw convention is mirrored relative to what a game expects
			// (the flick path negates its angle change for the same reason), so flip it.
			if (turnAxis == 0)
			{
				directGyroY = -psYaw;
				directGyroZ = 0.f;
			}
			else
			{
				directGyroZ = -psYaw;
				directGyroY = 0.f;
			}
		}

		// Recorded after the fact so out_* is literally what the game receives.
		traceInput(origYaw, origPitch, 0.f, directGyroX, directGyroY, directGyroZ);
	}

	//// These are for sanity checking sensor fusion against a simple complementary filter:
	// float angle = sqrtf(inGyroX * inGyroX + inGyroY * inGyroY + inGyroZ * inGyroZ) * PI / 180.f * deltaTime;
	Vec normAxis = Vec(-rawGyroX, -rawGyroY, -rawGyroZ).Normalized();
	// Quat reverseRotation = Quat(cosf(angle * 0.5f), normAxis.x, normAxis.y, normAxis.z);
	// reverseRotation.Normalize();
	// jc->_lastGrav *= reverseRotation;
	// Vec newGrav = Vec(-imu.accelX, -imu.accelY, -imu.accelZ);
	// jc->_lastGrav += (newGrav - jc->_lastGrav) * 0.01f;
	//
	// Vec normFancyGrav = Vec(inGravX, inGravY, inGravZ).Normalized();
	// Vec normSimpleGrav = jc->_lastGrav.Normalized();
	//
	// float gravAngleDiff = acosf(normFancyGrav.Dot(normSimpleGrav)) * 180.f / PI;

	// COUT << "Angle diff: " << gravAngleDiff << "\n\tFancy gravity: " << normFancyGrav.x << ", " << normFancyGrav.y << ", " << normFancyGrav.z << "\n\tSimple gravity: " << normSimpleGrav.x << ", " << normSimpleGrav.y << ", " << normSimpleGrav.z << "\n";
	// COUT << "Quat: " << inQuatW << ", " << inQuatX << ", " << inQuatY << ", " << inQuatZ << "\n";

	// inGravX = normSimpleGrav.x;
	// inGravY = normSimpleGrav.y;
	// inGravZ = normSimpleGrav.z;

	// COUT << "DS4 accel: %.4f, %.4f, %.4f\n", imuState.accelX, imuState.accelY, imuState.accelZ);
	// COUT << "\tDS4 gyro: %.4f, %.4f, %.4f\n", imuState.gyroX, imuState.gyroY, imuState.gyroZ);
	// COUT << "\tDS4 quat: %.4f, %.4f, %.4f, %.4f | accel: %.4f, %.4f, %.4f | grav: %.4f, %.4f, %.4f\n",
	//	inQuatW, inQuatX, inQuatY, inQuatZ,
	//	_motion.accelX, _motion.accelY, _motion.accelZ,
	//	inGravvX, inGravY, inGravZ);

	bool blockGyro = false;
	bool lockMouse = false;
	bool leftAny = false;
	bool rightAny = false;
	bool motionAny = false;

	if (jc->set_neutral_quat)
	{
		// _motion stick neutral should be calculated from the gravity vector
		Vec gravDirection = Vec(inGravX, inGravY, inGravZ);
		Vec normalizedGravDirection = gravDirection.Normalized();
		float diffAngle = acosf(clamp(-gravDirection.y, -1.f, 1.f));
		Vec neutralGravAxis = Vec(0.0f, -1.0f, 0.0f).Cross(normalizedGravDirection);
		Quat neutralQuat = Quat(cosf(diffAngle * 0.5f), neutralGravAxis.x, neutralGravAxis.y, neutralGravAxis.z);
		neutralQuat.Normalize();

		jc->neutralQuatW = neutralQuat.w;
		jc->neutralQuatX = neutralQuat.x;
		jc->neutralQuatY = neutralQuat.y;
		jc->neutralQuatZ = neutralQuat.z;
		jc->set_neutral_quat = false;
		COUT << "Neutral orientation for device " << jc->_handle << " set...\n";
	}

	float gyroX = 0.0;
	float gyroY = 0.0;
	GyroSpace gyroSpace = jc->getSetting<GyroSpace>(SettingID::GYRO_SPACE);
	if (gyroSpace == GyroSpace::LOCAL)
	{
		int mouse_x_flag = (int)jc->getSetting<GyroAxisMask>(SettingID::MOUSE_X_FROM_GYRO_AXIS);
		if ((mouse_x_flag & (int)GyroAxisMask::X) > 0)
		{
			gyroX += rawGyroX;
		}
		if ((mouse_x_flag & (int)GyroAxisMask::Y) > 0)
		{
			gyroX -= rawGyroY;
		}
		if ((mouse_x_flag & (int)GyroAxisMask::Z) > 0)
		{
			gyroX -= rawGyroZ;
		}
		int mouse_y_flag = (int)jc->getSetting<GyroAxisMask>(SettingID::MOUSE_Y_FROM_GYRO_AXIS);
		if ((mouse_y_flag & (int)GyroAxisMask::X) > 0)
		{
			gyroY -= rawGyroX;
		}
		if ((mouse_y_flag & (int)GyroAxisMask::Y) > 0)
		{
			gyroY += rawGyroY;
		}
		if ((mouse_y_flag & (int)GyroAxisMask::Z) > 0)
		{
			gyroY += rawGyroZ;
		}
	}
	else if (gyroSpace == GyroSpace::YAW_PLUS_ROLL)
	{
		const float rollContribution = jc->getSetting(SettingID::ROLL_CONTRIBUTION) / 100.0f;
		gyroX -= rawGyroY;                    
		gyroX -= rawGyroZ * rollContribution; 
		gyroY -= rawGyroX;                    
	}
	else
	{
		float gravLength = sqrtf(inGravX * inGravX + inGravY * inGravY + inGravZ * inGravZ);
		float normGravX = 0.f;
		float normGravY = 0.f;
		float normGravZ = 0.f;
		if (gravLength > 0.f)
		{
			float gravNormalizer = 1.f / gravLength;
			normGravX = inGravX * gravNormalizer;
			normGravY = inGravY * gravNormalizer;
			normGravZ = inGravZ * gravNormalizer;
		}

		float flatness = abs(normGravY);
		float upness = abs(normGravZ);
		float sideReduction = clamp((max(flatness, upness) - 0.125f) / 0.125f, 0.f, 1.f);

		if (gyroSpace == GyroSpace::PLAYER_TURN || gyroSpace == GyroSpace::PLAYER_LEAN)
		{
			if (gyroSpace == GyroSpace::PLAYER_TURN)
			{
				// grav dot gyro axis (but only Y (yaw) and Z (roll))
				float worldYaw = normGravY * rawGyroY + normGravZ * rawGyroZ;
				float worldYawSign = worldYaw < 0.f ? -1.f : 1.f;
				const float yawRelaxFactor = 2.f; // 60 degree buffer
				// const float yawRelaxFactor = 1.41f; // 45 degree buffer
				// const float yawRelaxFactor = 1.15f; // 30 degree buffer
				gyroX += worldYawSign * min(abs(worldYaw) * yawRelaxFactor, sqrtf(rawGyroY * rawGyroY + rawGyroZ * rawGyroZ)); 
			}
			else // PLAYER_LEAN
			{
				// project local pitch axis (X) onto gravity plane
				// super simple since our point is only non-zero in one axis
				float gravDotPitchAxis = normGravX;
				float pitchAxisX = 1.f - normGravX * gravDotPitchAxis;
				float pitchAxisY = -normGravY * gravDotPitchAxis;
				float pitchAxisZ = -normGravZ * gravDotPitchAxis;
				// normalize
				float pitchAxisLengthSquared = pitchAxisX * pitchAxisX + pitchAxisY * pitchAxisY + pitchAxisZ * pitchAxisZ;
				if (pitchAxisLengthSquared > 0.f)
				{
					// world roll axis is cross (yaw, pitch)
					float rollAxisX = pitchAxisY * normGravZ - pitchAxisZ * normGravY;
					float rollAxisY = pitchAxisZ * normGravX - pitchAxisX * normGravZ;
					float rollAxisZ = pitchAxisX * normGravY - pitchAxisY * normGravX;

					// normalize
					float rollAxisLengthSquared = rollAxisX * rollAxisX + rollAxisY * rollAxisY + rollAxisZ * rollAxisZ;
					if (rollAxisLengthSquared > 0.f)
					{
						float rollAxisLength = sqrtf(rollAxisLengthSquared);
						float lengthReciprocal = 1.f / rollAxisLength;
						rollAxisX *= lengthReciprocal;
						rollAxisY *= lengthReciprocal;
						rollAxisZ *= lengthReciprocal;

						float worldRoll = rollAxisY * rawGyroY + rollAxisZ * rawGyroZ;
						float worldRollSign = worldRoll < 0.f ? -1.f : 1.f;
						// const float rollRelaxFactor = 2.f; // 60 degree buffer
						const float rollRelaxFactor = 1.41f; // 45 degree buffer
						// const float rollRelaxFactor = 1.15f; // 30 degree buffer
						gyroX += worldRollSign * min(abs(worldRoll) * rollRelaxFactor, sqrtf(rawGyroY * rawGyroY + rawGyroZ * rawGyroZ));
						gyroX *= sideReduction;
					}
				}
			}

			gyroY -= rawGyroX;
		}
		else // WORLD_TURN or WORLD_LEAN
		{
			// grav dot gyro axis
			float worldYaw = normGravX * rawGyroX + normGravY * rawGyroY + normGravZ * rawGyroZ;
			// project local pitch axis (X) onto gravity plane
			// super simple since our point is only non-zero in one axis
			float gravDotPitchAxis = normGravX;
			float pitchAxisX = 1.f - normGravX * gravDotPitchAxis;
			float pitchAxisY = -normGravY * gravDotPitchAxis;
			float pitchAxisZ = -normGravZ * gravDotPitchAxis;
			// normalize
			float pitchAxisLengthSquared = pitchAxisX * pitchAxisX + pitchAxisY * pitchAxisY + pitchAxisZ * pitchAxisZ;
			if (pitchAxisLengthSquared > 0.f)
			{
				float pitchAxisLength = sqrtf(pitchAxisLengthSquared);
				float lengthReciprocal = 1.f / pitchAxisLength;
				pitchAxisX *= lengthReciprocal;
				pitchAxisY *= lengthReciprocal;
				pitchAxisZ *= lengthReciprocal;

				// get global pitch factor (dot)
				gyroY = -(pitchAxisX * rawGyroX + pitchAxisY * rawGyroY + pitchAxisZ * rawGyroZ);
				// by the way, pinch it towards the nonsense limit
				gyroY *= sideReduction;

				if (gyroSpace == GyroSpace::WORLD_LEAN)
				{
					// world roll axis is cross (yaw, pitch)
					float rollAxisX = pitchAxisY * normGravZ - pitchAxisZ * normGravY;
					float rollAxisY = pitchAxisZ * normGravX - pitchAxisX * normGravZ;
					float rollAxisZ = pitchAxisX * normGravY - pitchAxisY * normGravX;

					// normalize
					float rollAxisLengthSquared = rollAxisX * rollAxisX + rollAxisY * rollAxisY + rollAxisZ * rollAxisZ;
					if (rollAxisLengthSquared > 0.f)
					{
						float rollAxisLength = sqrtf(rollAxisLengthSquared);
						lengthReciprocal = 1.f / rollAxisLength;
						rollAxisX *= lengthReciprocal;
						rollAxisY *= lengthReciprocal;
						rollAxisZ *= lengthReciprocal;

						// get global roll factor (dot)
						gyroX = rollAxisX * rawGyroX + rollAxisY * rawGyroY + rollAxisZ * rawGyroZ;
						// by the way, pinch because we rely on a good pitch vector here
						gyroX *= sideReduction;
					}
				}
			}

			if (gyroSpace == GyroSpace::WORLD_TURN)
			{
				gyroX += worldYaw;
			}
		}
	}
	float gyroLength = sqrt(gyroX * gyroX + gyroY * gyroY);

	if (!isDirectOutput)
	{
		const float inX = gyroX, inY = gyroY;
		faal_filter(gyroX, gyroY, deltaTime);
		// out_* is what the sensitivity / accel curve actually consumes.
		traceInput(inX, inY, 0.f, gyroX, gyroY, 0.f);
	}

	// do gyro smoothing
	const bool useDecaySmoothing = jc->getSetting<Switch>(SettingID::GYRO_SMOOTHING_DECAY) == Switch::ON;
	if (useDecaySmoothing)
	{
		auto smoothingTime = jc->getSetting(SettingID::GYRO_SMOOTH_TIME);
		auto threshold = jc->getSetting(SettingID::GYRO_SMOOTH_THRESHOLD);
		jc->applyGyroDecaySmoothing(gyroX, gyroY, deltaTime, smoothingTime, threshold, gyroX, gyroY);
	}
	else
	{
		jc->disableGyroDecaySmoothing();
		// convert gyro smooth time to number of samples
		auto tick_time = SettingsManager::get<float>(SettingID::TICK_TIME)->value();
		auto numGyroSamples = jc->getSetting(SettingID::GYRO_SMOOTH_TIME) * 1000.f / tick_time;
		if (numGyroSamples < 1)
			numGyroSamples = 1; // need at least 1 sample
		auto threshold = jc->getSetting(SettingID::GYRO_SMOOTH_THRESHOLD);
		jc->getSmoothedGyro(gyroX, gyroY, gyroLength, threshold / 2.0f, threshold, int(numGyroSamples), gyroX, gyroY);
		// COUT << "%d Samples for threshold: %0.4f\n", numGyroSamples, gyro_smooth_threshold * maxSmoothingSamples);
	}

	// One Euro Filter — adaptive low-pass, smooth at low speed and responsive at high speed
	if (gyroOneEuroEnabled)
	{
		jc->applyOneEuroFilter(gyroX, gyroY, deltaTime, gyroX, gyroY);
	}

	// Decel brake detection should use IMU-based, post-smoothing gyro before cutoff/recovery and before synthetic additions
	jc->decelBrakeOmegaRaw = sqrt(gyroX * gyroX + gyroY * gyroY);

	// now, honour gyro_cutoff_speed
	gyroLength = sqrt(gyroX * gyroX + gyroY * gyroY);
	auto speed = jc->getSetting(SettingID::GYRO_CUTOFF_SPEED);
	auto recovery = jc->getSetting(SettingID::GYRO_CUTOFF_RECOVERY);
	if (recovery > speed)
	{
		// we can use gyro_cutoff_speed
		float gyroIgnoreFactor = (gyroLength - speed) / (recovery - speed);
		if (gyroIgnoreFactor < 1.0f)
		{
			if (gyroIgnoreFactor <= 0.0f)
			{
				gyroX = gyroY = gyroLength = 0.0f;
			}
			else
			{
				gyroX *= gyroIgnoreFactor;
				gyroY *= gyroIgnoreFactor;
				gyroLength *= gyroIgnoreFactor;
			}
		}
	}
	else if (speed > 0.0f && gyroLength < speed)
	{
		// gyro_cutoff_recovery is something weird, so we just do a hard threshold
		gyroX = gyroY = gyroLength = 0.0f;
	}

	// Handle _buttons before GYRO because some of them may affect the value of blockGyro
	auto gyro = jc->getSetting<GyroSettings>(SettingID::GYRO_ON); // same result as getting GYRO_OFF
	switch (gyro.ignore_mode)
	{
	case GyroIgnoreMode::BUTTON:
		blockGyro = gyro.always_off ^ jc->isPressed(gyro.button);
		break;
	case GyroIgnoreMode::LEFT_STICK:
	{
		float leftX = jsl->GetLeftX(jc->_handle);
		float leftY = jsl->GetLeftY(jc->_handle);
		float leftLength = sqrtf(leftX * leftX + leftY * leftY);
		float deadzoneInner = jc->getSetting(SettingID::LEFT_STICK_DEADZONE_INNER);
		float deadzoneOuter = jc->getSetting(SettingID::LEFT_STICK_DEADZONE_OUTER);
		leftAny = false;
		switch (jc->getSetting<StickMode>(SettingID::LEFT_STICK_MODE))
		{
		case StickMode::AIM:
			leftAny = leftLength > deadzoneInner;
			break;
		case StickMode::FLICK:
			leftAny = leftLength > (1.f - deadzoneOuter);
			break;
		case StickMode::LEFT_STICK:
		case StickMode::RIGHT_STICK:
			leftAny = leftLength > deadzoneInner;
			break;
		case StickMode::NO_MOUSE:
		case StickMode::INNER_RING:
		case StickMode::OUTER_RING:
		{
			jc->processDeadZones(leftX, leftY, deadzoneInner, deadzoneOuter);
			float absX = abs(leftX);
			float absY = abs(leftY);
			bool left = leftX < -0.5f * absY;
			bool right = leftX > 0.5f * absY;
			bool down = leftY < -0.5f * absX;
			bool up = leftY > 0.5f * absX;
			leftAny = left || right || up || down;
		}
		break;
		default:
			break;
		}
		blockGyro = (gyro.always_off ^ leftAny);
	}
	break;
	case GyroIgnoreMode::RIGHT_STICK:
	{
		float rightX = jsl->GetRightX(jc->_handle);
		float rightY = jsl->GetRightY(jc->_handle);
		float rightLength = sqrtf(rightX * rightX + rightY * rightY);
		float deadzoneInner = jc->getSetting(SettingID::RIGHT_STICK_DEADZONE_INNER);
		float deadzoneOuter = jc->getSetting(SettingID::RIGHT_STICK_DEADZONE_OUTER);
		rightAny = false;
		switch (jc->getSetting<StickMode>(SettingID::RIGHT_STICK_MODE))
		{
		case StickMode::AIM:
			rightAny = rightLength > deadzoneInner;
			break;
		case StickMode::FLICK:
			rightAny = rightLength > (1.f - deadzoneOuter);
			break;
		case StickMode::LEFT_STICK:
		case StickMode::RIGHT_STICK:
			rightAny = rightLength > deadzoneInner;
			break;
		case StickMode::NO_MOUSE:
		case StickMode::INNER_RING:
		case StickMode::OUTER_RING:
		{
			jc->processDeadZones(rightX, rightY, deadzoneInner, deadzoneOuter);
			float absX = abs(rightX);
			float absY = abs(rightY);
			bool left = rightX < -0.5f * absY;
			bool right = rightX > 0.5f * absY;
			bool down = rightY < -0.5f * absX;
			bool up = rightY > 0.5f * absX;
			rightAny = left || right || up || down;
		}
		break;
		default:
			break;
		}
		blockGyro = (gyro.always_off ^ rightAny);
	}
	break;
	}
	float gyro_x_sign_to_use = jc->getSetting(SettingID::GYRO_AXIS_X);
	float gyro_y_sign_to_use = jc->getSetting(SettingID::GYRO_AXIS_Y);

	bool trackball_x_pressed = false;
	bool trackball_y_pressed = false;
	if (jc->_ignoreGyro)
	{
		blockGyro = true;
	}

	// Apply gyro modifiers in the queue from oldest to newest (thus giving priority to most recent)
	for (auto pair : jc->_context->gyroActionQueue)
	{
		if (pair.second.code == GYRO_ON_BIND)
			blockGyro = false;
		else if (pair.second.code == GYRO_OFF_BIND)
			blockGyro = true;
		else if (pair.second.code == GYRO_INV_X)
			gyro_x_sign_to_use = jc->getSetting(SettingID::GYRO_AXIS_X) * -1; // Intentionally don't support multiple inversions
		else if (pair.second.code == GYRO_INV_Y)
			gyro_y_sign_to_use = jc->getSetting(SettingID::GYRO_AXIS_Y) * -1; // Intentionally don't support multiple inversions
		else if (pair.second.code == GYRO_INVERT)
		{
			// Intentionally don't support multiple inversions
			gyro_x_sign_to_use = jc->getSetting(SettingID::GYRO_AXIS_X) * -1;
			gyro_y_sign_to_use = jc->getSetting(SettingID::GYRO_AXIS_Y) * -1;
		}
		else if (pair.second.code == GYRO_TRACK_X)
			trackball_x_pressed = true;
		else if (pair.second.code == GYRO_TRACK_Y)
			trackball_y_pressed = true;
	else if (pair.second.code == GYRO_TRACKBALL)
	{
		trackball_x_pressed = true;
		trackball_y_pressed = true;
	}
}
	const int globalOnCount = g_gyroGlobalOnCount.load();
	const int globalOffCount = g_gyroGlobalOffCount.load();
	if (globalOnCount > 0)
	{
		if (!jc->_ignoreGyro)
			blockGyro = false;
	}
	else if (globalOffCount > 0)
	{
		blockGyro = true;
	}
	else if (g_hasGyroOnAllBinding.load())
	{
		// No global ON presses active but a global ON binding exists: default to off-until-held.
		blockGyro = true;
	}

	float decay = exp2f(-deltaTime * jc->getSetting(SettingID::TRACKBALL_DECAY));
	int maxTrackballSamples = max(1, min(jc->NUM_LAST_GYRO_SAMPLES, (int)(1.f / deltaTime * 0.125f)));

	if (!trackball_x_pressed && !trackball_y_pressed)
	{
		jc->lastGyroAbsX = abs(gyroX);
		jc->lastGyroAbsY = abs(gyroY);
	}

	if (!trackball_x_pressed)
	{
		int gyroSampleIndex = jc->lastGyroIndexX = (jc->lastGyroIndexX + 1) % maxTrackballSamples;
		jc->lastGyroX[gyroSampleIndex] = gyroX;
	}
	else
	{
		float lastGyroX = 0.f;
		for (int gyroAverageIdx = 0; gyroAverageIdx < maxTrackballSamples; gyroAverageIdx++)
		{
			lastGyroX += jc->lastGyroX[gyroAverageIdx];
			jc->lastGyroX[gyroAverageIdx] *= decay;
		}
		lastGyroX /= maxTrackballSamples;
		float lastGyroAbsX = abs(lastGyroX);
		if (lastGyroAbsX > jc->lastGyroAbsX)
		{
			lastGyroX *= jc->lastGyroAbsX / lastGyroAbsX;
		}
		gyroX = lastGyroX;
	}
	if (!trackball_y_pressed)
	{
		int gyroSampleIndex = jc->lastGyroIndexY = (jc->lastGyroIndexY + 1) % maxTrackballSamples;
		jc->lastGyroY[gyroSampleIndex] = gyroY;
	}
	else
	{
		float lastGyroY = 0.f;
		for (int gyroAverageIdx = 0; gyroAverageIdx < maxTrackballSamples; gyroAverageIdx++)
		{
			lastGyroY += jc->lastGyroY[gyroAverageIdx];
			jc->lastGyroY[gyroAverageIdx] *= decay;
		}
		lastGyroY /= maxTrackballSamples;
		float lastGyroAbsY = abs(lastGyroY);
		if (lastGyroAbsY > jc->lastGyroAbsY)
		{
			lastGyroY *= jc->lastGyroAbsY / lastGyroAbsY;
		}
		gyroY = lastGyroY;
	}

	if (blockGyro)
	{
		gyroX = 0;
		gyroY = 0;
		jc->resetOneEuroFilter();
	}

	float camSpeedX = 0.0f;
	float camSpeedY = 0.0f;

	float gyroXVelocity = gyroX * gyro_x_sign_to_use;
	float gyroYVelocity = gyroY * gyro_y_sign_to_use;

	pair<float, float> lowSensXY = jc->getSetting<FloatXY>(SettingID::MIN_GYRO_SENS);
	pair<float, float> hiSensXY = jc->getSetting<FloatXY>(SettingID::MAX_GYRO_SENS);
	const AccelCurve accelCurve = jc->getSetting<AccelCurve>(SettingID::ACCEL_CURVE);

	// Curve-specific parameters
	const float naturalVHalf = jc->getSetting(SettingID::ACCEL_NATURAL_VHALF);
	const float powervRef = jc->getSetting(SettingID::ACCEL_POWER_VREF);
	const float powerExponent = jc->getSetting(SettingID::ACCEL_POWER_EXPONENT);
	const float sigmoidMid = jc->getSetting(SettingID::ACCEL_SIGMOID_MID);
	const float sigmoidWidth = jc->getSetting(SettingID::ACCEL_SIGMOID_WIDTH);
	const float jumpTau = jc->getSetting(SettingID::ACCEL_JUMP_TAU);

	// apply calibration factor
	// get input velocity (post snap; may include synthetic gyro later)
	float omega = sqrt(gyroXVelocity * gyroXVelocity + gyroYVelocity * gyroYVelocity);

	// Gyro deceleration brake detection uses pre-curve, post-smoothing (IMU-only) gyro vector
	const float decelBrakeStrength = std::clamp(jc->getSetting(SettingID::DECEL_BRAKE_STRENGTH), 0.0f, 1.0f);
	const float decelBrakeThreshold = std::max(0.0f, jc->getSetting(SettingID::DECEL_BRAKE_THRESHOLD));
	float decelBrakeMultiplier = 1.0f;
	if (decelBrakeStrength <= 0.0f)
	{
		jc->decelBrakeEngagement = 0.0f;
	}
	else
	{
		constexpr float kWindowSeconds = 0.010f;              // Tw
		constexpr float kSpeedMin = 2.0f;                     // S_MIN
		constexpr float kSpeedMax = 60.0f;                    // S_MAX
		constexpr float kEngageTime = 0.010f;                 // T_ENGAGE
		constexpr float kReleaseTime = 0.006f;                // T_RELEASE
		constexpr float kFullBrakeFactor = 3.5f;              // k
		constexpr auto kHistoryWindow = std::chrono::milliseconds(50);

		const auto nowTs = std::chrono::steady_clock::now();
		jc->decelBrakeHistory.push_back({ nowTs, jc->decelBrakeOmegaRaw });
		while (!jc->decelBrakeHistory.empty() && nowTs - jc->decelBrakeHistory.front().first > kHistoryWindow)
		{
			jc->decelBrakeHistory.pop_front();
		}

		float sOld = jc->decelBrakeOmegaRaw;
		const auto targetTs = nowTs - std::chrono::milliseconds(10);
		for (auto it = jc->decelBrakeHistory.rbegin(); it != jc->decelBrakeHistory.rend(); ++it)
		{
			if (it->first <= targetTs)
			{
				sOld = it->second;
				break;
			}
		}

		const float slope = (jc->decelBrakeOmegaRaw - sOld) / kWindowSeconds; // deg/s^2
		const float dNeg = std::max(0.0f, -slope);
		const float d0 = kWindowSeconds > 0.0f ? decelBrakeThreshold / kWindowSeconds : 0.0f;
		const float d1 = d0 * kFullBrakeFactor;
		const float denom = (d1 > d0) ? (d1 - d0) : 1e-6f;

		float bInst = 0.0f;
		const bool speedGate = omega >= kSpeedMin && omega <= kSpeedMax;
		if (speedGate)
		{
			bInst = std::clamp((dNeg - d0) / denom, 0.0f, 1.0f);
		}

		float &engagement = jc->decelBrakeEngagement;
		if (speedGate && bInst > 0.0f)
		{
			engagement += (deltaTime / kEngageTime) * bInst;
		}
		else
		{
			engagement -= (deltaTime / kReleaseTime);
		}
		engagement = std::clamp(engagement, 0.0f, 1.0f);

		if (decelBrakeStrength > 0.0f && engagement > 0.0f)
		{
			decelBrakeMultiplier = 1.0f - decelBrakeStrength * engagement;
		}
	}

	// Apply angle snap after decel brake detection so braking is not triggered by snap-induced slowdown
	const float gyroAngleSnapDeg = jc->getSetting(SettingID::GYRO_ANGLE_SNAP);
	if (gyroAngleSnapDeg > 0.0f && (gyroXVelocity != 0.0f || gyroYVelocity != 0.0f))
	{
		const bool smoothSnap = jc->getSetting<Switch>(SettingID::GYRO_ANGLE_SNAP_EASE) == Switch::ON;
		const float snapRad = gyroAngleSnapDeg * float(M_PI) / 180.0f;
		const float referenceAngle = gyroXVelocity == 0.0f ? float(M_PI_2) : atan(fabsf(gyroYVelocity / gyroXVelocity));
		const float mag = sqrtf(gyroXVelocity * gyroXVelocity + gyroYVelocity * gyroYVelocity);

		if (mag > 0.0f)
		{
			if (smoothSnap)
			{
				auto smoothstep01 = [](float x) -> float {
					x = fminf(fmaxf(x, 0.0f), 1.0f);
					return x * x * (3.0f - 2.0f * x);
				};

				if (referenceAngle > float(M_PI_2) - snapRad)
				{
					float x = 1.0f - ((float(M_PI_2) - referenceAngle) / snapRad);
					const float snap = smoothstep01(x);
					gyroXVelocity *= (1.0f - snap);
					gyroYVelocity = copysignf(mag, gyroYVelocity);
				}
				else if (referenceAngle < snapRad)
				{
					float x = 1.0f - (referenceAngle / snapRad);
					const float snap = smoothstep01(x);
					gyroYVelocity *= (1.0f - snap);
					gyroXVelocity = copysignf(mag, gyroXVelocity);
				}
			}
			else
			{
				if (referenceAngle > float(M_PI_2) - snapRad)
				{
					gyroXVelocity = 0.0f;
					gyroYVelocity = copysign(mag, gyroYVelocity);
				}
				else if (referenceAngle < snapRad)
				{
					gyroXVelocity = copysign(mag, gyroXVelocity);
					gyroYVelocity = 0.0f;
				}
			}
		}
	}

	// Recompute omega after snapping to feed accel curves/telemetry
	omega = sqrt(gyroXVelocity * gyroXVelocity + gyroYVelocity * gyroYVelocity);

	// calculate position on minThreshold to maxThreshold scale
	float minThreshold = jc->getSetting(SettingID::MIN_GYRO_THRESHOLD);
	float maxThreshold = jc->getSetting(SettingID::MAX_GYRO_THRESHOLD);
	const float omegaAdjusted = std::max(0.0f, omega - minThreshold);
	const float denom = maxThreshold - minThreshold;
	float normalizedPreCurve = (denom > 0.0f) ? std::clamp(omegaAdjusted / denom, 0.0f, 1.0f)
	                                          : (omegaAdjusted > 0.0f ? 1.0f : 0.0f);

	float appliedSensX = 0.0f;
	float appliedSensY = 0.0f;
	float normalizedPostCurve = normalizedPreCurve;

	switch (accelCurve)
	{
	case AccelCurve::NATURAL:
		appliedSensX = NaturalSensitivity(omegaAdjusted, lowSensXY.first, hiSensXY.first, naturalVHalf);
		appliedSensY = NaturalSensitivity(omegaAdjusted, lowSensXY.second, hiSensXY.second, naturalVHalf);
		break;
	case AccelCurve::POWER:
		appliedSensX = PowerSensitivity(omegaAdjusted, lowSensXY.first, hiSensXY.first, powervRef, powerExponent);
		appliedSensY = PowerSensitivity(omegaAdjusted, lowSensXY.second, hiSensXY.second, powervRef, powerExponent);
		break;
	case AccelCurve::QUADRATIC:
		appliedSensX = QuadraticSensitivity(omegaAdjusted, lowSensXY.first, hiSensXY.first, maxThreshold);
		appliedSensY = QuadraticSensitivity(omegaAdjusted, lowSensXY.second, hiSensXY.second, maxThreshold);
		break;
	case AccelCurve::SIGMOID:
		appliedSensX = SigmoidSensitivity(omegaAdjusted, lowSensXY.first, hiSensXY.first, sigmoidMid, sigmoidWidth);
		appliedSensY = SigmoidSensitivity(omegaAdjusted, lowSensXY.second, hiSensXY.second, sigmoidMid, sigmoidWidth);
		break;
	case AccelCurve::JUMP:
		appliedSensX = JumpSensitivity(omegaAdjusted, lowSensXY.first, hiSensXY.first, maxThreshold, jumpTau);
		appliedSensY = JumpSensitivity(omegaAdjusted, lowSensXY.second, hiSensXY.second, maxThreshold, jumpTau);
		break;
	case AccelCurve::LINEAR:
	case AccelCurve::INVALID:
	default: {
		const float t = normalizedPreCurve;
		appliedSensX = lowSensXY.first * (1.0f - t) + hiSensXY.first * t;
		appliedSensY = lowSensXY.second * (1.0f - t) + hiSensXY.second * t;
		normalizedPostCurve = t;
		break;
	}
	}

	// Map post-curve sensitivities back to 0..1 for telemetry
	const auto normalizeSens = [](float sens, float sMin, float sMax) -> float {
		const float denom = sMax - sMin;
		if (denom <= 0.0f)
			return 0.0f;
		return std::clamp((sens - sMin) / denom, 0.0f, 1.0f);
	};
	normalizedPostCurve = std::max(normalizeSens(appliedSensX, lowSensXY.first, hiSensXY.first),
	  normalizeSens(appliedSensY, lowSensXY.second, hiSensXY.second));

	gyroXVelocity *= appliedSensX;
	gyroYVelocity *= appliedSensY;

	if (decelBrakeMultiplier < 1.0f)
	{
		gyroXVelocity *= decelBrakeMultiplier;
		gyroYVelocity *= decelBrakeMultiplier;
	}

	TelemetrySample telemetrySample;
	telemetrySample.omega = omega;
	// Report post-curve normalized value so the live dot follows the selected curve
	telemetrySample.normalized = normalizedPostCurve;
	telemetrySample.sensX = appliedSensX;
	telemetrySample.sensY = appliedSensY;
	telemetrySample.minThreshold = minThreshold;
	telemetrySample.maxThreshold = maxThreshold;
	telemetrySample.sMinX = lowSensXY.first;
	telemetrySample.sMaxX = hiSensXY.first;
	telemetrySample.sMinY = lowSensXY.second;
	telemetrySample.sMaxY = hiSensXY.second;
	// Derive sample rate from backend report timestamps (JSL): count reports over a short window.
	{
		struct ReportWindow
		{
			std::deque<double> timestampsMs;
			double lastReportMs = -1.0;
		};
		static std::unordered_map<int, ReportWindow> s_reportWindows;
		constexpr double kWindowMs = 2000.0; // 2 seconds
		constexpr double kMinStepMs = 0.1;   // ignore duplicate timestamps within 0.1ms

		const auto nowUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
		const double nowMs = nowUs / 1000.0;
		const float deltaSinceUpdate = jsl->GetTimeSinceLastUpdate(jc->_handle);
		if (deltaSinceUpdate > 0.0f)
		{
			const double reportTsMs = nowMs - (static_cast<double>(deltaSinceUpdate) * 1000.0);
			auto &window = s_reportWindows[jc->_handle];
			if (window.lastReportMs < 0.0 || (reportTsMs - window.lastReportMs) >= kMinStepMs)
			{
				window.timestampsMs.push_back(reportTsMs);
				window.lastReportMs = reportTsMs;
			}
			// Drop old entries outside the window
			while (!window.timestampsMs.empty() && (nowMs - window.timestampsMs.front()) > kWindowMs)
			{
				window.timestampsMs.pop_front();
			}
			const double windowSeconds = kWindowMs / 1000.0;
			const double rate = window.timestampsMs.size() / windowSeconds;
			telemetrySample.sampleRateHz = static_cast<float>(rate);
		}
	}
#ifdef SDL
	// SDL path: fall back to applied update rate (loop iterations over a short window).
	{
		static size_t s_loopCount = 0;
		static auto s_windowStart = std::chrono::steady_clock::now();
		static double s_lastAppliedRate = 0.0;
		constexpr double kWindowSeconds = 2.0;

		s_loopCount++;
		const auto now = std::chrono::steady_clock::now();
		const double elapsedSeconds =
		  std::chrono::duration_cast<std::chrono::milliseconds>(now - s_windowStart).count() / 1000.0;
		if (elapsedSeconds >= kWindowSeconds)
		{
			const double rate = s_loopCount / elapsedSeconds;
			if (rate > 0.0)
			{
				s_lastAppliedRate = rate;
			}
			s_loopCount = 0;
			s_windowStart = now;
		}
		if (telemetrySample.sampleRateHz <= 0.0f && s_lastAppliedRate > 0.0)
		{
			telemetrySample.sampleRateHz = static_cast<float>(s_lastAppliedRate);
		}
	}
#else
	// SDL path: measured sample rate provided by wrapper (legacy returns 0 here).
	if (telemetrySample.sampleRateHz <= 0.0f)
	{
		const float backendRate = jsl->GetSampleRateHz(jc->_handle);
		if (backendRate > 0.0f)
		{
			telemetrySample.sampleRateHz = backendRate;
		}
	}
#endif
	for (const auto &entry : handle_to_joyshock)
	{
		const auto &device = entry.second;
		TelemetryDevice dev;
		dev.handle = device->_handle;
		dev.controllerType = device->_controllerType;
		dev.splitType = device->_splitType;
		dev.vendorId = jsl->GetControllerVendor(device->_handle);
		dev.productId = jsl->GetControllerProduct(device->_handle);
#ifdef SDL
		TelemetryDeviceStatus status;
		status.buttons = jsl->GetButtons(device->_handle);
		if (device->_splitType != JS_SPLIT_TYPE_RIGHT)
		{
			status.leftStick.x = jsl->GetLeftX(device->_handle);
			status.leftStick.y = jsl->GetLeftY(device->_handle);
			status.triggers.left = jsl->GetLeftTrigger(device->_handle);
		}
		if (device->_splitType != JS_SPLIT_TYPE_LEFT)
		{
			status.rightStick.x = jsl->GetRightX(device->_handle);
			status.rightStick.y = jsl->GetRightY(device->_handle);
			status.triggers.right = jsl->GetRightTrigger(device->_handle);
		}
		const auto imu = jsl->GetIMUState(device->_handle);
		status.gyro.x = imu.gyroX;
		status.gyro.y = imu.gyroY;
		status.gyro.z = imu.gyroZ;
		dev.status = status;
#endif
		telemetrySample.devices.push_back(dev);
	}
	Telemetry::MaybeSend(telemetrySample);

	jc->gyroXVelocity = gyroXVelocity;
	jc->gyroYVelocity = gyroYVelocity;

	jc->_timeNow = chrono::steady_clock::now();

	// sticks!
	jc->processed_gyro_stick = false;
	ControllerOrientation controllerOrientation = jc->getSetting<ControllerOrientation>(SettingID::CONTROLLER_ORIENTATION);
	// account for os mouse speed and convert from radians to degrees because gyro reports in degrees per second
	float mouseCalibrationFactor = 180.0f / M_PI / os_mouse_speed;
	if (jc->_splitType != JS_SPLIT_TYPE_RIGHT)
	{
		// let's do these sticks... don't want to constantly send input, so we need to compare them to last time
		auto axisSign = jc->getSetting<AxisSignPair>(SettingID::LEFT_STICK_AXIS);
		float calX = jsl->GetLeftX(jc->_handle) * float(axisSign.first);
		float calY = jsl->GetLeftY(jc->_handle) * float(axisSign.second);

		jc->processStick(calX, calY, jc->_leftStick, mouseCalibrationFactor, deltaTime, leftAny, lockMouse, camSpeedX, camSpeedY);
		jc->_leftStick.lastX = calX;
		jc->_leftStick.lastY = calY;
	}

	if (jc->_splitType != JS_SPLIT_TYPE_LEFT)
	{
		auto axisSign = jc->getSetting<AxisSignPair>(SettingID::RIGHT_STICK_AXIS);
		float calX = jsl->GetRightX(jc->_handle) * float(axisSign.first);
		float calY = jsl->GetRightY(jc->_handle) * float(axisSign.second);

		jc->processStick(calX, calY, jc->_rightStick, mouseCalibrationFactor, deltaTime, rightAny, lockMouse, camSpeedX, camSpeedY);
		jc->_rightStick.lastX = calX;
		jc->_rightStick.lastY = calY;
	}

	if (jc->_splitType == JS_SPLIT_TYPE_FULL ||
	  (jc->_splitType & (int)jc->getSetting<JoyconMask>(SettingID::JOYCON_MOTION_MASK)) == 0)
	{
		Quat neutralQuat = Quat(jc->neutralQuatW, jc->neutralQuatX, jc->neutralQuatY, jc->neutralQuatZ);
		Vec grav = Vec(inGravX, inGravY, inGravZ) * neutralQuat.Inverse();

		float lastCalX = jc->_motionStick.lastX;
		float lastCalY = jc->_motionStick.lastY;
		// float lastCalX = jc->_motionStick.lastX;
		// float lastCalY = jc->_motionStick.lastY;
		//  use gravity vector deflection
		auto axisSign = jc->getSetting<AxisSignPair>(SettingID::MOTION_STICK_AXIS);
		float calX = grav.x * float(axisSign.first);
		float calY = -grav.z * float(axisSign.second);
		float gravLength2D = sqrtf(grav.x * grav.x + grav.z * grav.z);
		float gravStickDeflection = atan2f(gravLength2D, -grav.y) / M_PI;
		if (gravLength2D > 0)
		{
			calX *= gravStickDeflection / gravLength2D;
			calY *= gravStickDeflection / gravLength2D;
		}

		jc->processStick(calX, calY, jc->_motionStick, mouseCalibrationFactor, deltaTime, motionAny, lockMouse, camSpeedX, camSpeedY);
		jc->_motionStick.lastX = calX;
		jc->_motionStick.lastY = calY;

		float gravLength3D = grav.Length();
		if (gravLength3D > 0)
		{
			float gravSideDir;
			switch (controllerOrientation)
			{
			case ControllerOrientation::FORWARD:
				gravSideDir = grav.x;
				break;
			case ControllerOrientation::LEFT:
				gravSideDir = grav.z;
				break;
			case ControllerOrientation::RIGHT:
				gravSideDir = -grav.z;
				break;
			case ControllerOrientation::BACKWARD:
				gravSideDir = -grav.x;
				break;
			}
			float gravDirX = gravSideDir / gravLength3D;
			float sinLeanThreshold = sin(jc->getSetting(SettingID::LEAN_THRESHOLD) * M_PI / 180.f);
			jc->handleButtonChange(ButtonID::LEAN_LEFT, gravDirX < -sinLeanThreshold);
			jc->handleButtonChange(ButtonID::LEAN_RIGHT, gravDirX > sinLeanThreshold);

			// _motion stick can be set to control steering by leaning
			StickMode motionStickMode = jc->getSetting<StickMode>(SettingID::MOTION_STICK_MODE);
			if (jc->_context->_vigemController && (motionStickMode == StickMode::LEFT_STEER_X || motionStickMode == StickMode::RIGHT_STEER_X))
			{
				bool isLeft = motionStickMode == StickMode::LEFT_STEER_X;
				float leanAngle = asinf(clamp(gravDirX, -1.f, 1.f)) * 180.f / M_PI;
				float leanSign = leanAngle < 0.f ? -1.f : 1.f;
				float absLeanAngle = abs(leanAngle);
				if (grav.y > 0.f)
				{
					absLeanAngle = 180.f - absLeanAngle;
				}
				float motionDZInner = jc->getSetting(SettingID::MOTION_DEADZONE_INNER);
				float motionDZOuter = jc->getSetting(SettingID::MOTION_DEADZONE_OUTER);
				float remappedLeanAngle = pow(clamp((absLeanAngle - motionDZInner) / (180.f - motionDZOuter - motionDZInner), 0.f, 1.f), jc->getSetting(SettingID::STICK_POWER));

				// now actually convert to output stick value, taking deadzones and power curve into account
				float undeadzoneInner, undeadzoneOuter, unpower;
				if (isLeft)
				{
					undeadzoneInner = jc->getSetting(SettingID::LEFT_STICK_UNDEADZONE_INNER);
					undeadzoneOuter = jc->getSetting(SettingID::LEFT_STICK_UNDEADZONE_OUTER);
					unpower = jc->getSetting(SettingID::LEFT_STICK_UNPOWER);
				}
				else
				{
					undeadzoneInner = jc->getSetting(SettingID::RIGHT_STICK_UNDEADZONE_INNER);
					undeadzoneOuter = jc->getSetting(SettingID::RIGHT_STICK_UNDEADZONE_OUTER);
					unpower = jc->getSetting(SettingID::RIGHT_STICK_UNPOWER);
				}

				float livezoneSize = 1.f - undeadzoneOuter - undeadzoneInner;
				if (livezoneSize > 0.f)
				{
					// unpower curve
					if (unpower != 0.f)
					{
						remappedLeanAngle = pow(remappedLeanAngle, 1.f / unpower);
					}

					if (remappedLeanAngle < 1.f)
					{
						remappedLeanAngle = undeadzoneInner + remappedLeanAngle * livezoneSize;
					}

					float signedStickValue = leanSign * remappedLeanAngle;
					// COUT << "LEAN ANGLE: " << (leanSign * absLeanAngle) << "    REMAPPED: " << (leanSign * remappedLeanAngle) << "     STICK OUT: " << signedStickValue << '\n';
					jc->_context->_vigemController->setStick(signedStickValue, 0.f, isLeft);
				}
			}
		}
	}

	uint64_t buttons = jsl->GetButtons(jc->_handle);
	// button mappings
	if (jc->_splitType != JS_SPLIT_TYPE_RIGHT)
	{
		jc->handleButtonChange(ButtonID::UP, buttons & (1ULL << JSOFFSET_UP));
		jc->handleButtonChange(ButtonID::DOWN, buttons & (1ULL << JSOFFSET_DOWN));
		jc->handleButtonChange(ButtonID::LEFT, buttons & (1ULL << JSOFFSET_LEFT));
		jc->handleButtonChange(ButtonID::RIGHT, buttons & (1ULL << JSOFFSET_RIGHT));
		jc->handleButtonChange(ButtonID::L, buttons & (1ULL << JSOFFSET_L));
		jc->handleButtonChange(ButtonID::MINUS, buttons & (1ULL << JSOFFSET_MINUS));
		jc->handleButtonChange(ButtonID::L3, buttons & (1ULL << JSOFFSET_LCLICK));

		float lTrigger = jsl->GetLeftTrigger(jc->_handle);
		jc->handleTriggerChange(ButtonID::ZL, ButtonID::ZLF, jc->getSetting<TriggerMode>(SettingID::ZL_MODE), lTrigger, jc->_leftEffect);

		bool touch = jsl->GetTouchDown(jc->_handle, false) || jsl->GetTouchDown(jc->_handle, true);
		switch (jc->_controllerType)
		{
		case JS_TYPE_DS:
			// JSL mapps mic button on the SL index
			// Edge grips
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));
			// Edge FN
			jc->handleButtonChange(ButtonID::LSR, buttons & (1ULL << JSOFFSET_FNL));
			jc->handleButtonChange(ButtonID::RSL, buttons & (1ULL << JSOFFSET_FNR));

			jc->handleButtonChange(ButtonID::MIC, buttons & (1ULL << JSOFFSET_MIC));
			// Don't break but continue onto DS4 stuff too
		case JS_TYPE_DS4:
		{
			float triggerpos = buttons & (1ULL << JSOFFSET_CAPTURE) ? 1.f :
			  touch                                              ? 0.99f :
			                                                       0.f;
			jc->handleTriggerChange(ButtonID::TOUCH, ButtonID::CAPTURE, jc->getSetting<TriggerMode>(SettingID::TOUCHPAD_DUAL_STAGE_MODE), triggerpos, jc->_unusedEffect);
		}
		break;
		case JS_TYPE_XBOXONE_ELITE:
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL)); // Xbox Elite back paddles
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));
			jc->handleButtonChange(ButtonID::LSR, buttons & (1ULL << JSOFFSET_FNL));
			jc->handleButtonChange(ButtonID::RSL, buttons & (1ULL << JSOFFSET_FNR));
			break;
		case JS_TYPE_XBOX_SERIES:
			jc->handleButtonChange(ButtonID::CAPTURE, buttons & (1ULL << JSOFFSET_CAPTURE));
			break;
		case JS_TYPE_JOYCON_LEFT:
			jc->handleButtonChange(ButtonID::CAPTURE, buttons & (1ULL << JSOFFSET_CAPTURE));
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));
			jc->handleButtonChange(ButtonID::LSR, buttons & (1ULL << JSOFFSET_SR));
			break;
		case JS_TYPE_PRO_CONTROLLER:
			jc->handleButtonChange(ButtonID::CAPTURE, buttons & (1ULL << JSOFFSET_CAPTURE));
			break;
		case JS_TYPE_SWITCH2_PRO_CONTROLLER:
			jc->handleButtonChange(ButtonID::CAPTURE, buttons & (1ULL << JSOFFSET_CAPTURE)); // Capture button
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));          // GL back button
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));          // GR back button
			jc->handleButtonChange(ButtonID::MISC1, buttons & (1ULL << JSOFFSET_MISC1));     // C button
			break;
		case JS_TYPE_HORI_STEAM:
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));        // L4 back button
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));        // R4 back button
			jc->handleButtonChange(ButtonID::LSR, buttons & (1ULL << JSOFFSET_FNL));       // M1 button below left stick
			jc->handleButtonChange(ButtonID::RSL, buttons & (1ULL << JSOFFSET_FNR));       // M2 button below right stick
			jc->handleButtonChange(ButtonID::LTOUCH, buttons & (1ULL << JSOFFSET_LTOUCH)); // Left stick capacitive touch
			jc->handleButtonChange(ButtonID::RTOUCH, buttons & (1ULL << JSOFFSET_RTOUCH)); // Right stick capacitive touch
			jc->handleButtonChange(ButtonID::MISC1, buttons & (1ULL << JSOFFSET_MISC1));   // QAM button ("..." button)
			break;
		case JS_TYPE_G7_PRO_8K:
			jc->handleButtonChange(ButtonID::LMINI, buttons & (1ULL << JSOFFSET_LMINI));     // L5 mini shoulder button
			jc->handleButtonChange(ButtonID::RMINI, buttons & (1ULL << JSOFFSET_RMINI));     // R5 mini shoulder button
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));          // L4 back button
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));          // R4 back button
			jc->handleButtonChange(ButtonID::CAPTURE, buttons & (1ULL << JSOFFSET_CAPTURE)); // Share button
			break;
		// 8BitDo controllers with gyro and no additional buttons.
		case JS_TYPE_8BITDO_SF30_PRO:
		case JS_TYPE_8BITDO_SF30_PRO_BT:
		case JS_TYPE_8BITDO_SN30_PRO:
		case JS_TYPE_8BITDO_SN30_PRO_BT:
			break;
		// 8BitDo controllers with gyro and two additional buttons.
		case JS_TYPE_8BITDO_PRO_2:
		case JS_TYPE_8BITDO_PRO_2_BT:
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL)); // P2 back button (left)
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR)); // P1 back button (right)
			break;
		// 8BitDo controllers with gyro and four additional buttons.
		case JS_TYPE_8BITDO_PRO_3:
		case JS_TYPE_8BITDO_ULTIMATE2_WIRELESS:
			jc->handleButtonChange(ButtonID::LMINI, buttons & (1ULL << JSOFFSET_LMINI)); // L4 mini shoulder button
			jc->handleButtonChange(ButtonID::RMINI, buttons & (1ULL << JSOFFSET_RMINI)); // R4 mini shoulder button
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));      // PL back button
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));      // PR back button
			break;
		case JS_TYPE_FLYDIGI_APEX5:
			jc->handleButtonChange(ButtonID::LMINI, buttons & (1ULL << JSOFFSET_LMINI)); // LM mini shoulder button
			jc->handleButtonChange(ButtonID::RMINI, buttons & (1ULL << JSOFFSET_RMINI)); // RM mini shoulder button
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));  // M2 back button (top left)
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));  // M1 back button (top right)
			jc->handleButtonChange(ButtonID::LSR, buttons & (1ULL << JSOFFSET_FNL)); // M4 back button (bottom left)
			jc->handleButtonChange(ButtonID::RSL, buttons & (1ULL << JSOFFSET_FNR)); // M3 back button (bottom right)
			break;
		case JS_TYPE_FLYDIGI_VADER5_PRO:
			jc->handleButtonChange(ButtonID::LMINI, buttons & (1ULL << JSOFFSET_LMINI)); // LM mini shoulder button
			jc->handleButtonChange(ButtonID::RMINI, buttons & (1ULL << JSOFFSET_RMINI)); // RM mini shoulder button
			jc->handleButtonChange(ButtonID::MISC3, buttons & (1ULL << JSOFFSET_MISC3)); // Circle button below right stick
			// Fall through.
		case JS_TYPE_FLYDIGI_VADER4_PRO:
		case JS_TYPE_FLYDIGI_VADER3_PRO:
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));  // M2 back button (top left)
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));  // M1 back button (top right)
			jc->handleButtonChange(ButtonID::LSR, buttons & (1ULL << JSOFFSET_FNL)); // M4 back button (bottom left)
			jc->handleButtonChange(ButtonID::RSL, buttons & (1ULL << JSOFFSET_FNR)); // M3 back button (bottom right)
			jc->handleButtonChange(ButtonID::MISC1, buttons & (1ULL << JSOFFSET_MISC1)); // C face button
			jc->handleButtonChange(ButtonID::MISC2, buttons & (1ULL << JSOFFSET_MISC2)); // Z face button
			break;
		default:
			jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));
			jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));
			jc->handleButtonChange(ButtonID::LSR, buttons & (1ULL << JSOFFSET_FNL));
			jc->handleButtonChange(ButtonID::RSL, buttons & (1ULL << JSOFFSET_FNR));
			jc->handleButtonChange(ButtonID::MISC1, buttons & (1ULL << JSOFFSET_MISC1));
			jc->handleButtonChange(ButtonID::MISC2, buttons & (1ULL << JSOFFSET_MISC2));
			jc->handleButtonChange(ButtonID::MISC3, buttons & (1ULL << JSOFFSET_MISC3));
			jc->handleButtonChange(ButtonID::MISC4, buttons & (1ULL << JSOFFSET_MISC4));
			jc->handleButtonChange(ButtonID::MISC5, buttons & (1ULL << JSOFFSET_MISC5));
			jc->handleButtonChange(ButtonID::MISC6, buttons & (1ULL << JSOFFSET_MISC6));
			break;
		}
	}
	else // split type IS right
	{
		// Right joycon bumpers
		jc->handleButtonChange(ButtonID::RSL, buttons & (1ULL << JSOFFSET_SL));
		jc->handleButtonChange(ButtonID::RSR, buttons & (1ULL << JSOFFSET_SR));
	}

	if (jc->_splitType != JS_SPLIT_TYPE_LEFT)
	{
		jc->handleButtonChange(ButtonID::E, buttons & (1ULL << JSOFFSET_E));
		jc->handleButtonChange(ButtonID::S, buttons & (1ULL << JSOFFSET_S));
		jc->handleButtonChange(ButtonID::N, buttons & (1ULL << JSOFFSET_N));
		jc->handleButtonChange(ButtonID::W, buttons & (1ULL << JSOFFSET_W));
		jc->handleButtonChange(ButtonID::R, buttons & (1ULL << JSOFFSET_R));
		jc->handleButtonChange(ButtonID::PLUS, buttons & (1ULL << JSOFFSET_PLUS));
		jc->handleButtonChange(ButtonID::HOME, buttons & (1ULL << JSOFFSET_HOME));
		jc->handleButtonChange(ButtonID::R3, buttons & (1ULL << JSOFFSET_RCLICK));

		float rTrigger = jsl->GetRightTrigger(jc->_handle);
		jc->handleTriggerChange(ButtonID::ZR, ButtonID::ZRF, jc->getSetting<TriggerMode>(SettingID::ZR_MODE), rTrigger, jc->_rightEffect);
	}
	else
	{
		// Left joycon bumpers
		jc->handleButtonChange(ButtonID::LSL, buttons & (1ULL << JSOFFSET_SL));
		jc->handleButtonChange(ButtonID::LSR, buttons & (1ULL << JSOFFSET_SR));
	}

	auto at = jc->getSetting<Switch>(SettingID::ADAPTIVE_TRIGGER);
	if (at == Switch::OFF)
	{
		AdaptiveTriggerSetting none;
		jsl->SetTriggerEffect(jc->_handle, none, none);
	}
	else
	{
		auto leftEffect = jc->getSetting<AdaptiveTriggerSetting>(SettingID::LEFT_TRIGGER_EFFECT);
		auto rightEffect = jc->getSetting<AdaptiveTriggerSetting>(SettingID::RIGHT_TRIGGER_EFFECT);
		jsl->SetTriggerEffect(jc->_handle, leftEffect.mode == AdaptiveTriggerMode::ON ? jc->_leftEffect : leftEffect,
		  rightEffect.mode == AdaptiveTriggerMode::ON ? jc->_rightEffect : rightEffect);
	}

	bool currentMicToggleState = find_if(jc->_context->activeTogglesQueue.cbegin(), jc->_context->activeTogglesQueue.cend(),
	                               [](const auto &pair)
	                               {
		                               return pair.first == ButtonID::MIC;
	                               }) != jc->_context->activeTogglesQueue.cend();
	for (auto controller : handle_to_joyshock)
	{
		jsl->SetMicLight(controller.first, currentMicToggleState ? 1 : 0);
	}


	if (!jc->processed_gyro_stick)
	{
		if (gyroOutput == GyroOutput::LEFT_STICK)
		{
			jc->processGyroStick(0.f, 0.f, 0.f, StickMode::LEFT_STICK, false);
		}
		else if (gyroOutput == GyroOutput::RIGHT_STICK)
		{
			jc->processGyroStick(0.f, 0.f, 0.f, StickMode::RIGHT_STICK, false);
		}
		else if (gyroOutput == GyroOutput::PS_MOTION)
		{
			if (jc->hasVirtualController())
			{
				jc->_context->_vigemController->setGyro(jc->_timeNow, imu.accelX, imu.accelY, imu.accelZ, directGyroX, directGyroY, directGyroZ);
			}
		}
	}

	// optionally ignore the gyro of one of the joycons
	if (!lockMouse && gyroOutput == GyroOutput::MOUSE &&
	  (jc->_splitType == JS_SPLIT_TYPE_FULL ||
	    (jc->_splitType & (int)jc->getSetting<JoyconMask>(SettingID::JOYCON_GYRO_MASK)) == 0))
	{
		// COUT << "GX: %0.4f GY: %0.4f GZ: %0.4f\n", imuState.gyroX, imuState.gyroY, imuState.gyroZ);
		float mouseCalibration = jc->getSetting(SettingID::REAL_WORLD_CALIBRATION) / os_mouse_speed / jc->getSetting(SettingID::IN_GAME_SENS);
		shapedSensitivityMoveMouse(gyroXVelocity * mouseCalibration, gyroYVelocity * mouseCalibration, deltaTime, camSpeedX, -camSpeedY);
	}

	if (jc->_context->_vigemController)
	{
		jc->_context->_vigemController->update(); // Check for initialized built-in
	}
	auto newColor = jc->getSetting<Color>(SettingID::LIGHT_BAR);
	if (jc->_light_bar != newColor)
	{
		jsl->SetLightColour(jc->_handle, newColor.raw);
		jc->_light_bar = newColor;
	}
	if (jc->_context->nn)
	{
		jc->_context->nn = (jc->_context->nn + 1) % 22;
	}
	jc->_context->callback_lock.unlock();
}

void connectDevices(bool mergeJoycons = true, const vector<int>& selectedDeviceIds = {})
{
	ResetFaalFilter();
	handle_to_joyshock.clear();
	this_thread::sleep_for(100ms);
	int numConnected = selectedDeviceIds.empty() ? jsl->ConnectDevices() : jsl->ConnectDevices(selectedDeviceIds);
	vector<int> deviceHandles(numConnected, 0);
	if (numConnected > 0)
	{
		numConnected = jsl->GetConnectedDeviceHandles(&deviceHandles[0], numConnected);

		if (numConnected < deviceHandles.size())
		{
			deviceHandles.erase(remove(deviceHandles.begin(), deviceHandles.end(), -1), deviceHandles.end());
			// deviceHandles.resize(numConnected);
		}

		for (auto handle : deviceHandles) // Don't use foreach!
		{
			auto type = jsl->GetControllerSplitType(handle);
			auto otherJoyCon = find_if(handle_to_joyshock.begin(), handle_to_joyshock.end(),
			  [type](auto &pair)
			  {
				  return type == JS_SPLIT_TYPE_LEFT && pair.second->_splitType == JS_SPLIT_TYPE_RIGHT ||
				    type == JS_SPLIT_TYPE_RIGHT && pair.second->_splitType == JS_SPLIT_TYPE_LEFT;
			  });
			if (mergeJoycons && otherJoyCon != handle_to_joyshock.end())
			{
				// The second JC points to the same common _buttons as the other one.
				COUT << "Found a joycon pair!\n";
				handle_to_joyshock[handle] = make_shared<JoyShock>(handle, type, otherJoyCon->second->_context);
			}
			else
			{
				handle_to_joyshock[handle] = make_shared<JoyShock>(handle, type);
			}
		}

		UpdateIgnoredGyroDevices();
	}

	if (numConnected == 1)
	{
		COUT << "1 device connected\n";
	}
	else if (numConnected == 0)
	{
		CERR << numConnected << " devices connected\n";
	}
	else
	{
		COUT << numConnected << " devices connected\n";
	}
	// if (!IsVisible())
	//{
	//	tray->SendNotification(wstring(msg.begin(), msg.end()));
	// }

	// if (numConnected != 0) {
	//	COUT << "All devices have started continuous gyro calibration\n";
	// }
}

void updateSimPressPartner(ButtonID sim, ButtonID origin, const Mapping &newVal)
{
	JSMButton *button = int(sim) < mappings.size() ? &mappings[int(sim)] :
	  int(sim) - FIRST_TOUCH_BUTTON < grid_mappings.size() ? &grid_mappings[int(sim) - FIRST_TOUCH_BUTTON] :
	                                                      nullptr;
	if (button)
		button->atSimPress(origin)->set(newVal);
	else
		CERR << "Cannot find the button " << sim << '\n';
}

void updateDiagPressPartner(ButtonID diag, ButtonID origin, const Mapping &newVal)
{
	JSMButton *button = int(diag) < mappings.size()         ? &mappings[int(diag)] :
	  int(diag) - FIRST_TOUCH_BUTTON < grid_mappings.size() ? &grid_mappings[int(diag) - FIRST_TOUCH_BUTTON] :
	                                                         nullptr;
	if (button)
		button->atDiagPress(origin)->set(newVal);
	else
		CERR << "Cannot find the button " << diag << '\n';
}

void updateThread(PollingThread *thread, const Switch &newValue)
{
	if (thread)
	{
		if (newValue == Switch::ON)
		{
			thread->Start();
		}
		else if (newValue == Switch::OFF)
		{
			thread->Stop();
		}
	}
	else
	{
		CERR << "The thread does not exist\n";
	}
}

bool do_NO_GYRO_BUTTON()
{
	// TODO: _handle chords
	SettingsManager::get<GyroSettings>(SettingID::GYRO_ON)->reset();
	return true;
}

bool do_RESET_MAPPINGS(CmdRegistry *registry)
{
	COUT << "Resetting all mappings to defaults\n";
	static constexpr auto callReset = [](JSMButton &map)
	{
		map.reset();
	};
	ranges::for_each(mappings, callReset);
	// It is possible some settings were intentionally omitted (JSM_DIRECTORY?, Whitelister?)
	// TODO: make sure omitted settings don't get reset
	SettingsManager::resetAllSettings();
	ranges::for_each(grid_mappings, callReset);

	os_mouse_speed = 1.0f;
	last_flick_and_rotation = 0.0f;
	gyroOneEuroEnabled = false;
	for (auto &[id, jc] : handle_to_joyshock)
	{
		jc->resetOneEuroFilter();
	}
	ResetFaalFilter();
	g_gyroGlobalOffCount.store(0);
	g_gyroGlobalOnCount.store(0);
	g_hasGyroOnAllBinding.store(false);
	UpdateIgnoredGyroDevices();
	if (registry)
	{
		if (!registry->loadConfigFile("OnReset.txt"))
		{
			COUT << "There is no ";
			COUT_INFO << "OnReset.txt";
			COUT << " file to load.\n";
		}
	}
	return true;
}

bool do_RECONNECT_CONTROLLERS(string_view arguments, std::function<void()> loadOnReconnect)
{
	static bool mergeJoycons = true;
	vector<int> selectedDeviceIds;
	bool hasSelection = false;
	string token;
	stringstream argumentStream{ string(arguments) };
	while (argumentStream >> token)
	{
		if (token == "MERGE")
		{
			mergeJoycons = true;
			continue;
		}
		if (token == "SPLIT")
		{
			mergeJoycons = false;
			continue;
		}
		if (token == "SELECT")
		{
			hasSelection = true;
			continue;
		}
		if (!hasSelection)
		{
			CERR << "Invalid argument: " << token << '\n';
			return false;
		}

		try
		{
			size_t consumed = 0;
			int deviceId = stoi(token, &consumed, 10);
			if (consumed != token.size())
			{
				CERR << "Invalid controller id: " << token << '\n';
				return false;
			}
			selectedDeviceIds.push_back(deviceId);
		}
		catch (...)
		{
			CERR << "Invalid controller id: " << token << '\n';
			return false;
		}
	}
	// else remember last
	if (hasSelection && selectedDeviceIds.empty())
	{
		CERR << "RECONNECT_CONTROLLERS SELECT requires at least one controller id.\n";
		return false;
	}
	 
	COUT << "Reconnecting controllers: " << (mergeJoycons ? "MERGE" : "SPLIT") << '\n';
	jsl->DisconnectAndDisposeAll();
	ResetFaalFilter();
	connectDevices(mergeJoycons, selectedDeviceIds);
	jsl->SetCallback(&joyShockPollCallback);
	jsl->SetTouchCallback(&touchCallback);

	if (loadOnReconnect)
		loadOnReconnect();

	return true;
}

bool do_LIST_CONTROLLERS()
{
	auto devices = jsl->ListAvailableDevices();
	COUT << "JSM_CONTROLLER_LIST_BEGIN\n";
	for (auto &device : devices)
	{
		COUT << "JSM_CONTROLLER\t"
			<< device.id << '\t'
			<< device.vendorId << '\t'
			<< device.productId << '\t'
			<< (device.isGamepad ? 1 : 0) << '\t'
			<< sanitizeControllerInfoName(device.name) << '\n';
	}
	COUT << "JSM_CONTROLLER_LIST_END\n";
	return true;
}

bool do_COUNTER_OS_MOUSE_SPEED()
{
	COUT << "Countering OS mouse speed setting\n";
	os_mouse_speed = getMouseSpeed();
	return true;
}

bool do_IGNORE_OS_MOUSE_SPEED()
{
	COUT << "Ignoring OS mouse speed setting\n";
	os_mouse_speed = 1.0;
	return true;
}

// ---------------------------------------------------------------------------
//  FAAL trace: record the raw filter input so a session can be replayed offline
// ---------------------------------------------------------------------------
static const char *FAAL_TRACE_FILE = "faal_trace.csv";

bool do_FAAL_TRACE_START()
{
	if (FaalTraceIsRecording())
	{
		COUT << "FAAL trace is already recording (" << FaalTraceRecordedFrames() << " frames)\n";
		return true;
	}
	FaalTraceStart();
	COUT << "FAAL trace recording. Play, then run ";
	COUT_INFO << "FAAL_TRACE_STOP";
	COUT << " to write " << FAAL_TRACE_FILE << "\n";
	return true;
}

bool do_FAAL_TRACE_STOP()
{
	const string path = string(BASE_JSM_CONFIG_FOLDER()) + FAAL_TRACE_FILE;
	const auto written = FaalTraceStopAndWrite(path.c_str());
	if (written == 0)
	{
		CERR << "FAAL trace was not recording, or nothing was captured\n";
		return true;
	}
	COUT << "FAAL trace written: " << written << " frames -> " << path << '\n';
	return true;
}

bool do_ONE_EURO_FILTER()
{
	COUT << "One Euro Filter enabled for gyro\n";
	gyroOneEuroEnabled = true;
	for (auto &[id, jc] : handle_to_joyshock)
	{
		jc->resetOneEuroFilter();
	}
	ResetFaalFilter();
	return true;
}

bool do_CALCULATE_REAL_WORLD_CALIBRATION(string_view argument)
{
	// first, check for a parameter
	float numRotations = 1.0;
	if (argument.length() > 0)
	{
		try
		{
			numRotations = stof(string(argument));
		}
		catch (invalid_argument ia)
		{
			COUT << "Can't convert \"" << argument << "\" to a number\n";
			return false;
		}
	}
	if (numRotations == 0)
	{
		COUT << "Can't calculate calibration from zero rotations\n";
	}
	else if (last_flick_and_rotation == 0)
	{
		COUT << "Need to use the flick stick at least once before calculating an appropriate calibration value\n";
	}
	else
	{
		COUT << "Recommendation: REAL_WORLD_CALIBRATION = " << setprecision(5) << (SettingsManager::get<float>(SettingID::REAL_WORLD_CALIBRATION)->value() * last_flick_and_rotation / numRotations) << '\n';
	}
	return true;
}

bool do_FINISH_GYRO_CALIBRATION()
{
	COUT << "Finishing continuous calibration for all devices\n";
	for (auto iter = handle_to_joyshock.begin(); iter != handle_to_joyshock.end(); ++iter)
	{
		iter->second->_motion->PauseContinuousCalibration();
	}
	devicesCalibrating = false;
	return true;
}

bool do_RESTART_GYRO_CALIBRATION()
{
	COUT << "Restarting continuous calibration for all devices\n";
	for (auto iter = handle_to_joyshock.begin(); iter != handle_to_joyshock.end(); ++iter)
	{
		iter->second->_motion->ResetContinuousCalibration();
		iter->second->_motion->StartContinuousCalibration();
	}
	devicesCalibrating = true;
	return true;
}

bool do_SET_MOTION_STICK_NEUTRAL()
{
	COUT << "Setting neutral motion stick orientation...\n";
	for (auto iter = handle_to_joyshock.begin(); iter != handle_to_joyshock.end(); ++iter)
	{
		iter->second->set_neutral_quat = true;
	}
	return true;
}

bool do_SLEEP(string_view argument)
{
	// first, check for a parameter
	float sleepTime = 1.0;
	if (argument.length() > 0)
	{
		try
		{
			sleepTime = stof(argument.data());
		}
		catch (invalid_argument ia)
		{
			COUT << "Can't convert \"" << argument << "\" to a number\n";
			return false;
		}
	}

	if (sleepTime <= 0)
	{
		COUT << "Sleep time must be greater than 0 and less than or equal to 10\n";
		return false;
	}

	if (sleepTime > 10)
	{
		COUT << "Sleep is capped at 10s per command\n";
		sleepTime = 10.f;
	}
	COUT << "Sleeping for " << setprecision(3) << sleepTime << " second(s)...\n";
	this_thread::sleep_for(chrono::milliseconds((int)(sleepTime * 1000)));
	COUT << "Finished sleeping.\n";

	return true;
}

bool do_README()
{
	auto err = ShowOnlineHelp();
	if (err != 0)
	{
		COUT << "Could not open online help. Error #" << err << '\n';
	}
	return true;
}

bool do_WHITELIST_SHOW()
{
	if (whitelister)
	{
		COUT << "Your PID is " << GetCurrentProcessId() << '\n';
		whitelister->ShowConsole();
	}
	return true;
}

bool do_WHITELIST_ADD()
{
	string errMsg = "Whitelister is not implemented";
	if (whitelister && whitelister->Add(&errMsg))
	{
		COUT << "JoyShockMapper was successfully whitelisted\n";
	}
	else
	{
		CERR << "Whitelist operation failed: " << errMsg << '\n';
	}
	return true;
}

bool do_WHITELIST_REMOVE()
{
	string errMsg = "Whitelister is not implemented";
	if (whitelister && whitelister->Remove(&errMsg))
	{
		COUT << "JoyShockMapper removed from whitelist\n";
	}
	else
	{
		CERR << "Whitelist operation failed: " << errMsg << '\n';
	}
	return true;
}

void beforeShowTrayMenu()
{
	if (!tray || !*tray)
		CERR << "ERROR: Cannot create tray item.\n";
	else
	{
		tray->ClearMenuMap();
		tray->AddMenuItem(U("Show Console"), &ShowConsole);
		tray->AddMenuItem(U("Reconnect controllers"), []()
		  { WriteToConsole("RECONNECT_CONTROLLERS"); });
		tray->AddMenuItem(
		  U("AutoLoad"), [](bool isChecked)
		  { SettingsManager::get<Switch>(SettingID::AUTOLOAD)->set(isChecked ? Switch::ON : Switch::OFF); },
		  bind(&PollingThread::isRunning, autoLoadThread.get()));

		tray->AddMenuItem(
		  U("AutoConnect"), [](bool isChecked)
		  { SettingsManager::get<Switch>(SettingID::AUTOCONNECT)->set(isChecked ? Switch::ON : Switch::OFF); },
		  bind(&PollingThread::isRunning, autoConnectThread.get()));

		if (whitelister && whitelister->IsAvailable())
		{
			tray->AddMenuItem(
			  U("Whitelist"), [](bool isChecked)
			  { isChecked ?
				  do_WHITELIST_ADD() :
				  do_WHITELIST_REMOVE(); },
			  bind(&Whitelister::operator bool, whitelister.get()));
		}
		tray->AddMenuItem(
		  U("Calibrate all devices"), [](bool isChecked)
		  { isChecked ?
			  WriteToConsole("RESTART_GYRO_CALIBRATION") :
			  WriteToConsole("FINISH_GYRO_CALIBRATION"); },
		  []()
		  { return devicesCalibrating; });

		string autoloadFolder{ AUTOLOAD_FOLDER() };
		for (auto file : ListDirectory(autoloadFolder.c_str()))
		{
			std::filesystem::path fullPath = std::filesystem::path("AutoLoad") / file;
			string fullPathName = fullPath.string();
			auto noext = file.substr(0, file.find_last_of('.'));
			tray->AddMenuItem(U("AutoLoad folder"), UnicodeString(noext.begin(), noext.end()), [fullPathName]
			  {
				WriteToConsole(string(fullPathName.begin(), fullPathName.end()));
				autoLoadThread->Stop(); });
		}
		string gyroConfigsFolder{ GYRO_CONFIGS_FOLDER() };
		for (auto file : ListDirectory(gyroConfigsFolder.c_str()))
		{
			std::filesystem::path fullPath = std::filesystem::path("GyroConfigs") / file;
			string fullPathName = fullPath.string();
			auto noext = file.substr(0, file.find_last_of('.'));
			tray->AddMenuItem(U("GyroConfigs folder"), UnicodeString(noext.begin(), noext.end()), [fullPathName]
			  {
				WriteToConsole(string(fullPathName.begin(), fullPathName.end()));
				autoLoadThread->Stop(); });
		}
		tray->AddMenuItem(U("Calculate RWC"), []()
		  {
			WriteToConsole("CALCULATE_REAL_WORLD_CALIBRATION");
			ShowConsole(); });
		tray->AddMenuItem(
		  U("Hide when minimized"), [](bool isChecked)
		  {
			  SettingsManager::getV<Switch>(SettingID::HIDE_MINIMIZED)->set(isChecked ? Switch::ON : Switch::OFF);
			  if (!isChecked)
				  UnhideConsole(); },
		  bind(&PollingThread::isRunning, minimizeThread.get()));
		tray->AddMenuItem(U("Quit"), []()
		  { WriteToConsole("QUIT"); });
	}
}

// Perform all cleanup tasks when JSM is exiting
void cleanUp()
{
	Telemetry::Shutdown();
	if (tray)
	{
		tray->Hide();
	}
	HideConsole();
	jsl->DisconnectAndDisposeAll();
	handle_to_joyshock.clear(); // Destroy Vigem Gamepads
	ReleaseConsole();
}

int filterClampByte(int current, int next)
{
	return max(0, min(0xff, next));
}

float filterClamp01(float current, float next)
{
	return max(0.0f, min(1.0f, next));
}

float filterPositive(float current, float next)
{
	return max(0.0f, next);
}

float filterClampPercent(float current, float next)
{
	return clamp(next, -100.0f, 100.0f);
}

float filterSign(float current, float next)
{
	return next == -1.0f || next == 0.0f || next == 1.0f ?
	  next :
	  current;
}

template<typename E, E invalid>
E filterInvalidValue(E current, E next)
{
	return next != invalid ? next : current;
}

AdaptiveTriggerSetting filterInvalidValue(AdaptiveTriggerSetting current, AdaptiveTriggerSetting next)
{
	return next.mode != AdaptiveTriggerMode::INVALID ? next : current;
}

float filterFloat(float current, float next)
{
	// Exclude Infinite, NaN and Subnormal
	return fpclassify(next) == FP_NORMAL || fpclassify(next) == FP_ZERO ? next : current;
}

FloatXY filterFloatPair(FloatXY current, FloatXY next)
{
	return (fpclassify(next.x()) == FP_NORMAL || fpclassify(next.x()) == FP_ZERO) &&
	    (fpclassify(next.y()) == FP_NORMAL || fpclassify(next.y()) == FP_ZERO) ?
	  next :
	  current;
}

AxisSignPair filterSignPair(AxisSignPair current, AxisSignPair next)
{
	return next.first != AxisMode::INVALID && next.second != AxisMode::INVALID ?
	  next :
	  current;
}

float filterHoldPressDelay(float c, float next)
{
	auto sim_press_window = SettingsManager::getV<float>(SettingID::SIM_PRESS_WINDOW);
	if (sim_press_window && next <= sim_press_window->value())
	{
		CERR << SettingID::HOLD_PRESS_TIME << " can only be set to a value higher than " << SettingID::SIM_PRESS_WINDOW << " which is " << sim_press_window->value() << "ms.\n";
		return c;
	}
	return next;
}

float filterTickTime(float c, float next)
{
	return max(1.f, min(100.f, round(next)));
}

Mapping filterMapping(Mapping current, Mapping next)
{
	auto virtual_controller = SettingsManager::getV<ControllerScheme>(SettingID::VIRTUAL_CONTROLLER);
	if (next.hasViGEmBtn())
	{
		if (virtual_controller && virtual_controller->value() == ControllerScheme::NONE)
		{
			COUT_WARN << "Before using this mapping, you need to set VIRTUAL_CONTROLLER.\n";
			return current;
		}
		for (auto &js : handle_to_joyshock)
		{
			if (js.second->hasVirtualController() == false)
				return current;
		}
	}
	return next.isValid() ? next : current;
}

TriggerMode filterTriggerMode(TriggerMode current, TriggerMode next)
{
	// With SDL, I'm not sure if we have a reliable way to check if the device has analog or digital triggers. There's a function to query them, but I don't know if it works with the devices with custom readers (Switch, PS)
	/*	for (auto &js : handle_to_joyshock)
	{
	    if (jsl->GetControllerType(js.first) != JS_TYPE_DS4 && next != TriggerMode::NO_FULL)
	    {
	        COUT_WARN << "WARNING: Dual Stage Triggers are only valid on analog triggers. Full pull bindings will be ignored on non DS4 controllers.\n";
	        break;
	    }
	}
*/
	auto virtual_controller = SettingsManager::getV<ControllerScheme>(SettingID::VIRTUAL_CONTROLLER);

	if (next == TriggerMode::X_LT || next == TriggerMode::X_RT)
	{
		if (virtual_controller && virtual_controller->value() == ControllerScheme::NONE)
		{
			COUT_WARN << "Before using this trigger mode, you need to set VIRTUAL_CONTROLLER.\n";
			return current;
		}
		for (auto &js : handle_to_joyshock)
		{
			if (js.second->hasVirtualController() == false)
				return current;
		}
	}
	return filterInvalidValue<TriggerMode, TriggerMode::INVALID>(current, next);
}

TriggerMode filterTouchpadDualStageMode(TriggerMode current, TriggerMode next)
{
	if (next == TriggerMode::X_LT || next == TriggerMode::X_RT || next == TriggerMode::INVALID)
	{
		COUT_WARN << SettingID::TOUCHPAD_DUAL_STAGE_MODE << " doesn't support vigem analog modes.\n";
		return current;
	}
	return next;
}

StickMode filterMotionStickMode(StickMode current, StickMode next)
{
	auto virtual_controller = SettingsManager::getV<ControllerScheme>(SettingID::VIRTUAL_CONTROLLER);
	if (next >= StickMode::LEFT_STICK && next <= StickMode::RIGHT_WIND_X)
	{
		if (virtual_controller && virtual_controller->value() == ControllerScheme::NONE)
		{
			COUT_WARN << "Before using this stick mode, you need to set VIRTUAL_CONTROLLER.\n";
			return current;
		}
		for (auto &js : handle_to_joyshock)
		{
			if (js.second->hasVirtualController() == false)
				return current;
		}
	}
	return filterInvalidValue<StickMode, StickMode::INVALID>(current, next);
}

StickMode filterStickMode(StickMode current, StickMode next)
{
	// these modes are only available to _motion stick
	if (next == StickMode::LEFT_STEER_X || next == StickMode::RIGHT_STEER_X)
	{
		COUT_WARN << "This mode is only available for MOTION_STICK_MODE.\n";
		return current;
	}
	return filterMotionStickMode(current, next);
}

GyroOutput filterGyroOutput(GyroOutput current, GyroOutput next)
{
	auto virtual_controller = SettingsManager::getV<ControllerScheme>(SettingID::VIRTUAL_CONTROLLER);
	if (next == GyroOutput::PS_MOTION && virtual_controller && virtual_controller->value() != ControllerScheme::DS4)
	{
		COUT_WARN << "Before using gyro mode PS_MOTION, you need to set ";
		COUT_INFO << "VIRTUAL_CONTROLLER = DS4\n";
		return current;
	}
	if (next == GyroOutput::LEFT_STICK || next == GyroOutput::RIGHT_STICK)
	{
		if (virtual_controller && virtual_controller->value() == ControllerScheme::NONE)
		{
			COUT_WARN << "Before using this gyro mode, you need to set VIRTUAL_CONTROLLER.\n";
			return current;
		}
		for (auto &js : handle_to_joyshock)
		{
			if (js.second->hasVirtualController() == false)
				return current;
		}
	}
	return filterInvalidValue<GyroOutput, GyroOutput::INVALID>(current, next);
}

void updateRingModeFromStickMode(JSMVariable<RingMode> *stickRingMode, const StickMode &newValue)
{
	if (newValue == StickMode::INNER_RING)
	{
		stickRingMode->set(RingMode::INNER);
	}
	else if (newValue == StickMode::OUTER_RING)
	{
		stickRingMode->set(RingMode::OUTER);
	}
}

ControllerScheme updateVirtualController(ControllerScheme prevScheme, ControllerScheme nextScheme)
{
	string error;
	bool success = true;
	for (auto &js : handle_to_joyshock)
	{
		lock_guard guard(js.second->_context->callback_lock);
		if (!js.second->_context->_vigemController ||
		  js.second->_context->_vigemController->getType() != nextScheme)
		{
			if (nextScheme == ControllerScheme::NONE)
			{
				js.second->_context->_vigemController.reset(nullptr);
			}
			else
			{
				js.second->_context->_vigemController.reset(Gamepad::getNew(nextScheme, bind(&JoyShock::onVirtualControllerNotification, js.second.get(), placeholders::_1, placeholders::_2, placeholders::_3)));
				success &= js.second->_context->_vigemController && js.second->_context->_vigemController->isInitialized(&error);
				if (!error.empty())
				{
					CERR << error << '\n';
					error.clear();
				}
				if (!success)
				{
					js.second->_context->_vigemController.release();
					break;
				}
			}
		}
	}
	return success ? nextScheme : prevScheme;
}

void onVirtualControllerChange(const ControllerScheme &newScheme)
{
	for (auto &js : handle_to_joyshock)
	{
		// Display an error message if any vigem is no good.
		lock_guard guard(js.second->_context->callback_lock);
		if (!js.second->hasVirtualController())
		{
			break;
		}
	}
	// TODO: on NONE clear mappings with vigem commands?
}

void refreshAutoLoadHelp(JSMAssignment<Switch> *autoloadCmd)
{
	stringstream ss;
	ss << "AUTOLOAD will attempt load a file from the following folder when a window with a matching executable name enters focus:\n"
	   << AUTOLOAD_FOLDER();
	autoloadCmd->setHelp(ss.str());
}

void onNewGridDimensions(CmdRegistry *registry, const FloatXY &newGridDims)
{
	_ASSERT_EXPR(registry, U("You forgot to bind the command registry properly!"));
	auto numberOfButtons = size_t(newGridDims.first * newGridDims.second);

	if (numberOfButtons < grid_mappings.size())
	{
		// Remove all extra touch button commands
		bool successfulRemove = true;
		for (auto id = FIRST_TOUCH_BUTTON + numberOfButtons; successfulRemove; ++id)
		{
			string name(magic_enum::enum_name(*magic_enum::enum_cast<ButtonID>(id)));
			successfulRemove = registry->Remove(name);
		}

		// For all joyshocks, remove extra touch DigitalButtons
		for (auto &js : handle_to_joyshock)
		{
			lock_guard guard(js.second->_context->callback_lock);
			js.second->updateGridSize();
		}

		// Remove extra touch button variables
		while (grid_mappings.size() > numberOfButtons)
			grid_mappings.pop_back();
	}
	else if (numberOfButtons > grid_mappings.size())
	{
		// Add new touch button variables and commands
		for (int id = FIRST_TOUCH_BUTTON + int(grid_mappings.size()); grid_mappings.size() < numberOfButtons; ++id)
		{
			JSMButton touchButton(*magic_enum::enum_cast<ButtonID>(id), Mapping::NO_MAPPING);
			touchButton.setFilter(&filterMapping);
			grid_mappings.push_back(touchButton);
			registry->add(new JSMAssignment<Mapping>(grid_mappings.back()));
		}

		// For all joyshocks, remove extra touch DigitalButtons
		for (auto &js : handle_to_joyshock)
		{
			lock_guard guard(js.second->_context->callback_lock);
			js.second->updateGridSize();
		}
	}
	// Else numbers are the same, possibly just reconfigured
}

void onNewStickAxis(AxisMode newAxisMode, bool isVertical)
{
	static auto left_stick_axis = SettingsManager::get<AxisSignPair>(SettingID::LEFT_STICK_AXIS);
	static auto right_stick_axis = SettingsManager::get<AxisSignPair>(SettingID::RIGHT_STICK_AXIS);
	static auto motion_stick_axis = SettingsManager::get<AxisSignPair>(SettingID::MOTION_STICK_AXIS);
	static auto touch_stick_axis = SettingsManager::get<AxisSignPair>(SettingID::TOUCH_STICK_AXIS);
	if (isVertical)
	{
		left_stick_axis->set(AxisSignPair{ left_stick_axis->value().first, newAxisMode });
		right_stick_axis->set(AxisSignPair{ right_stick_axis->value().first, newAxisMode });
		motion_stick_axis->set(AxisSignPair{ motion_stick_axis->value().first, newAxisMode });
		touch_stick_axis->set(AxisSignPair{ touch_stick_axis->value().first, newAxisMode });
	}
	else // is horizontal
	{
		left_stick_axis->set(AxisSignPair{ newAxisMode, left_stick_axis->value().second });
		right_stick_axis->set(AxisSignPair{ newAxisMode, right_stick_axis->value().second });
		motion_stick_axis->set(AxisSignPair{ newAxisMode, motion_stick_axis->value().second });
		touch_stick_axis->set(AxisSignPair{ newAxisMode, touch_stick_axis->value().second });
	}
}

class GyroSensAssignment : public JSMAssignment<FloatXY>
{
public:
	GyroSensAssignment(SettingID id, JSMSetting<FloatXY> &gyroSens)
	  : JSMAssignment(magic_enum::enum_name(id).data(), string(magic_enum::enum_name(gyroSens._id)), gyroSens)
	{
		// min and max gyro sens already have a listener
		gyroSens.removeOnChangeListener(_listenerId);
	}
};

class StickDeadzoneAssignment : public JSMAssignment<float>
{
public:
	StickDeadzoneAssignment(SettingID id, JSMSetting<float> &stickDeadzone)
	  : JSMAssignment(magic_enum::enum_name(id).data(), string(magic_enum::enum_name(stickDeadzone._id)), stickDeadzone)
	{
		// min and max gyro sens already have a listener
		stickDeadzone.removeOnChangeListener(_listenerId);
	}
};

class GyroButtonAssignment : public JSMAssignment<GyroSettings>
{
protected:
	const bool _always_off;
	const ButtonID _chordButton;

	virtual void displayCurrentValue() override
	{
		GyroSettings value(_var);
		if (_chordButton > ButtonID::NONE)
		{
			COUT << _chordButton << ',';
		}
		COUT << (value.always_off ? string("GYRO_ON") : string("GYRO_OFF")) << " = " << value << '\n';
	}

	virtual GyroSettings readValue(stringstream &in) override
	{
		GyroSettings value;
		value.always_off = _always_off; // Added line from defaultParser
		in >> value;
		return value;
	}

	virtual void displayNewValue(const GyroSettings &value) override
	{
		if (_chordButton > ButtonID::NONE)
		{
			COUT << _chordButton << ',';
		}
		COUT << (value.always_off ? string("GYRO_ON") : string("GYRO_OFF")) << " has been set to " << value << '\n';
	}

public:
	GyroButtonAssignment(string_view name, string_view displayName, JSMVariable<GyroSettings> &setting, bool always_off, ButtonID chord = ButtonID::NONE)
	  : JSMAssignment(name, name, setting, true)
	  , _always_off(always_off)
	  , _chordButton(chord)
	{
	}

	GyroButtonAssignment(SettingID id, bool always_off)
	  : GyroButtonAssignment(magic_enum::enum_name(id).data(), magic_enum::enum_name(id).data(), *SettingsManager::get<GyroSettings>(SettingID::GYRO_ON), always_off)
	{
	}

	GyroButtonAssignment *setListener()
	{
		_listenerId = _var.addOnChangeListener(bind(&GyroButtonAssignment::displayNewValue, this, placeholders::_1));
		NONAME.push_back(NONAME[0] ^ 0x05);
		NONAME.push_back(NONAME[1] ^ 14);
		return this;
	}

	virtual unique_ptr<JSMCommand> getModifiedCmd(char op, string_view chord) override
	{
		auto optBtn = magic_enum::enum_cast<ButtonID>(chord);
		auto settingVar = dynamic_cast<JSMSetting<GyroSettings> *>(&_var);
		if (optBtn > ButtonID::NONE && op == ',' && settingVar)
		{
			// Create Modeshift
			string name{ chord };
			(name += op) += _displayName;
			auto chordAssignment = make_unique<GyroButtonAssignment>(_name, name, *settingVar->atChord(*optBtn), _always_off, *optBtn);
			chordAssignment->setListener();
			chordAssignment->setHelp(_help)->setParser(bind(&GyroButtonAssignment::modeshiftParser, *optBtn, settingVar, &_parse, placeholders::_1, placeholders::_2, placeholders::_3))->setTaskOnDestruction(bind(&JSMSetting<GyroSettings>::processModeshiftRemoval, settingVar, *optBtn));
			return chordAssignment;
		}
		return JSMCommand::getModifiedCmd(op, chord);
	}

	virtual ~GyroButtonAssignment()
	{
	}
};

class HelpCmd : public JSMMacro
{
private:
	// HELP runs the macro for each argument given to it.
	string arg; // parsed argument

	bool parser(string_view arguments)
	{
		stringstream ss(arguments.data());
		ss >> arg;
		do
		{ // Run at least once with an empty arg string if there's no argument.
			_macro(this, arguments);
			ss >> arg;
		} while (!ss.fail());
		arg.clear();
		return true;
	}

	// The run function is nothing like the delegate. See how I use the bind function
	// below to hard-code the pointer parameter and the instance pointer 'this'.
	bool runHelp(CmdRegistry *registry)
	{
		if (arg.empty())
		{
			// Show all commands
			COUT << "Here's the list of all commands.\n";
			vector<string_view> list;
			registry->GetCommandList(list);
			for (auto cmd : list)
			{
				COUT_INFO << "    " << cmd << '\n';
			}
			COUT << "Enter HELP [cmd1] [cmd2] ... for details on specific commands.\n";
		}
		else if (registry->hasCommand(arg))
		{
			auto help = registry->GetHelp(arg);
			if (!help.empty())
			{
				COUT << arg << " :\n"
				     << "    " << help << '\n';
			}
			else
			{
				COUT << arg << " is not a recognized command\n";
			}
		}
		else
		{
			// Show all commands that include ARG
			COUT << "\"" << arg << "\" is not a command, but the following are:\n";
			vector<string_view> list;
			registry->GetCommandList(list);
			for (auto cmd : list)
			{
				auto pos = cmd.find(arg);
				if (pos != string::npos)
					COUT_INFO << "    " << cmd << '\n';
			}
			COUT << "Enter HELP [cmd1] [cmd2] ... for details on specific commands.\n";
		}
		return true;
	}

public:
	HelpCmd(CmdRegistry &reg)
	  : JSMMacro("HELP")
	{
		// Bind allows me to use instance function by hardcoding the invisible "this" parameter, and the registry pointer
		SetMacro(bind(&HelpCmd::runHelp, this, &reg));

		// The placeholder parameter says to pass 2nd parameter of call to _parse to the 1st argument of the call to HelpCmd::parser.
		// The first parameter is the command pointer which is not required because parser is an instance function rather than a static one.
		setParser(bind(&HelpCmd::parser, this, ::placeholders::_2));
		NONAME.push_back(NONAME[2] - 1);
		NONAME.push_back(NONAME[1] & ~0x06);
	}
};

// Contains all settings that can be modeshifted. They should be accessed only via Joyshock::getSetting
void initJsmSettings(CmdRegistry *commandRegistry)
{
	auto left_ring_mode = new JSMSetting<RingMode>(SettingID::LEFT_RING_MODE, RingMode::OUTER);
	left_ring_mode->setFilter(&filterInvalidValue<RingMode, RingMode::INVALID>);
	SettingsManager::add(left_ring_mode);
	commandRegistry->add((new JSMAssignment<RingMode>(*left_ring_mode))
	                       ->setHelp("Pick a ring where to apply the LEFT_RING binding. Valid values are the following: INNER and OUTER."));

	auto left_stick_mode = new JSMSetting<StickMode>(SettingID::LEFT_STICK_MODE, StickMode::NO_MOUSE);
	left_stick_mode->setFilter(&filterStickMode);
	left_stick_mode->addOnChangeListener(bind(&updateRingModeFromStickMode, left_ring_mode, placeholders::_1));
	SettingsManager::add(left_stick_mode);
	commandRegistry->add((new JSMAssignment<StickMode>(*left_stick_mode))
	                       ->setHelp("Set a mouse mode for the left stick. Valid values are the following:\nNO_MOUSE, AIM, FLICK, FLICK_ONLY, ROTATE_ONLY, MOUSE_RING, MOUSE_AREA, OUTER_RING, INNER_RING, SCROLL_WHEEL, LEFT_STICK, RIGHT_STICK"));

	auto right_ring_mode = new JSMSetting<RingMode>(SettingID::RIGHT_RING_MODE, RingMode::OUTER);
	right_ring_mode->setFilter(&filterInvalidValue<RingMode, RingMode::INVALID>);
	SettingsManager::add(right_ring_mode);
	commandRegistry->add((new JSMAssignment<RingMode>(*right_ring_mode))
	                       ->setHelp("Pick a ring where to apply the RIGHT_RING binding. Valid values are the following: INNER and OUTER."));

	auto right_stick_mode = new JSMSetting<StickMode>(SettingID::RIGHT_STICK_MODE, StickMode::NO_MOUSE);
	right_stick_mode->setFilter(&filterStickMode);
	right_stick_mode->addOnChangeListener(bind(&updateRingModeFromStickMode, right_ring_mode, ::placeholders::_1));
	SettingsManager::add(right_stick_mode);
	commandRegistry->add((new JSMAssignment<StickMode>(*right_stick_mode))
	                       ->setHelp("Set a mouse mode for the right stick. Valid values are the following:\nNO_MOUSE, AIM, FLICK, FLICK_ONLY, ROTATE_ONLY, MOUSE_RING, MOUSE_AREA, OUTER_RING, INNER_RING LEFT_STICK, RIGHT_STICK"));

	auto motion_ring_mode = new JSMSetting<RingMode>(SettingID::MOTION_RING_MODE, RingMode::OUTER);
	motion_ring_mode->setFilter(&filterInvalidValue<RingMode, RingMode::INVALID>);
	SettingsManager::add(motion_ring_mode);
	commandRegistry->add((new JSMAssignment<RingMode>(*motion_ring_mode))
	                       ->setHelp("Pick a ring where to apply the MOTION_RING binding. Valid values are the following: INNER and OUTER."));

	auto motion_stick_mode = new JSMSetting<StickMode>(SettingID::MOTION_STICK_MODE, StickMode::NO_MOUSE);
	motion_stick_mode->setFilter(&filterMotionStickMode);
	motion_stick_mode->addOnChangeListener(bind(&updateRingModeFromStickMode, motion_ring_mode, ::placeholders::_1));
	SettingsManager::add(motion_stick_mode);
	commandRegistry->add((new JSMAssignment<StickMode>(*motion_stick_mode))
	                       ->setHelp("Set a mouse mode for the motion-stick -- the whole controller is treated as a stick. Valid values are the following:\nNO_MOUSE, AIM, FLICK, FLICK_ONLY, ROTATE_ONLY, MOUSE_RING, MOUSE_AREA, OUTER_RING, INNER_RING LEFT_STICK, RIGHT_STICK"));

	auto mouse_x_from_gyro = new JSMSetting<GyroAxisMask>(SettingID::MOUSE_X_FROM_GYRO_AXIS, GyroAxisMask::Y);
	mouse_x_from_gyro->setFilter(&filterInvalidValue<GyroAxisMask, GyroAxisMask::INVALID>);
	SettingsManager::add(mouse_x_from_gyro);
	commandRegistry->add((new JSMAssignment<GyroAxisMask>(*mouse_x_from_gyro))
	                       ->setHelp("Pick a gyro axis to operate on the mouse's X axis. Valid values are the following: X, Y and Z."));

	auto mouse_y_from_gyro = new JSMSetting<GyroAxisMask>(SettingID::MOUSE_Y_FROM_GYRO_AXIS, GyroAxisMask::X);
	mouse_y_from_gyro->setFilter(&filterInvalidValue<GyroAxisMask, GyroAxisMask::INVALID>);
	SettingsManager::add(mouse_y_from_gyro);
	commandRegistry->add((new JSMAssignment<GyroAxisMask>(*mouse_y_from_gyro))
	                       ->setHelp("Pick a gyro axis to operate on the mouse's Y axis. Valid values are the following: X, Y and Z."));

	auto gyro_settings = new JSMSetting<GyroSettings>(SettingID::GYRO_ON, GyroSettings());
	gyro_settings->setFilter([](GyroSettings current, GyroSettings next)
	  { return next.ignore_mode != GyroIgnoreMode::INVALID ? next : current; });
	SettingsManager::add(gyro_settings);
	commandRegistry->add((new GyroButtonAssignment(SettingID::GYRO_OFF, false))
	                       ->setHelp("Assign a controller button to disable the gyro when pressed."));
	commandRegistry->add((new GyroButtonAssignment(SettingID::GYRO_ON, true))->setListener() // Set only one listener
	                       ->setHelp("Assign a controller button to enable the gyro when pressed."));

	auto joycon_gyro_mask = new JSMSetting<JoyconMask>(SettingID::JOYCON_GYRO_MASK, JoyconMask::IGNORE_LEFT);
	joycon_gyro_mask->setFilter(&filterInvalidValue<JoyconMask, JoyconMask::INVALID>);
	SettingsManager::add(joycon_gyro_mask);
	commandRegistry->add((new JSMAssignment<JoyconMask>(*joycon_gyro_mask))
	                       ->setHelp("When using two Joycons, select which one will be used for gyro. Valid values are the following:\nUSE_BOTH, IGNORE_LEFT, IGNORE_RIGHT, IGNORE_BOTH"));

	auto joycon_motion_mask = new JSMSetting<JoyconMask>(SettingID::JOYCON_MOTION_MASK, JoyconMask::IGNORE_RIGHT);
	joycon_motion_mask->setFilter(&filterInvalidValue<JoyconMask, JoyconMask::INVALID>);
	SettingsManager::add(joycon_motion_mask);
	commandRegistry->add((new JSMAssignment<JoyconMask>(*joycon_motion_mask))
	                       ->setHelp("When using two Joycons, select which one will be used for non-gyro motion. Valid values are the following:\nUSE_BOTH, IGNORE_LEFT, IGNORE_RIGHT, IGNORE_BOTH"));

	auto ignore_gyro_devices = new JSMSetting<string>(SettingID::IGNORE_GYRO_DEVICES, "");
	SettingsManager::add(ignore_gyro_devices);
	auto ignoreParser = [ignore_gyro_devices](JSMCommand *, string_view data, string_view) {
		string value(data);
		auto first = value.find_first_not_of(" \t");
		auto last = value.find_last_not_of(" \t");
		if (first == string::npos || last == string::npos)
		{
			value.clear();
		}
		else
		{
			value = value.substr(first, last - first + 1);
		}
		ignore_gyro_devices->set(value);
		COUT << "IGNORE_GYRO_DEVICES has been set to " << value << '\n';
		return true;
	};
	commandRegistry->add((new JSMAssignment<string>(*ignore_gyro_devices))
	                       ->setParser(ignoreParser)
	                       ->setHelp("Space-separated list of VID:PID pairs (hex) whose gyro should be ignored, e.g. IGNORE_GYRO_DEVICES = 0x054c:0x0ce6"));
	ignore_gyro_devices->addOnChangeListener([](const string &) { UpdateIgnoredGyroDevices(); });

	auto zlMode = new JSMSetting<TriggerMode>(SettingID::ZL_MODE, TriggerMode::NO_FULL);
	zlMode->setFilter(&filterTriggerMode);
	SettingsManager::add(zlMode);
	commandRegistry->add((new JSMAssignment<TriggerMode>(*zlMode))
	                       ->setHelp("Controllers with a right analog trigger can use one of the following dual stage trigger modes:\nNO_FULL, NO_SKIP, MAY_SKIP, MUST_SKIP, MAY_SKIP_R, MUST_SKIP_R, NO_SKIP_EXCLUSIVE, X_LT, X_RT, PS_L2, PS_R2"));

	auto zrMode = new JSMSetting<TriggerMode>(SettingID::ZR_MODE, TriggerMode::NO_FULL);
	zrMode->setFilter(&filterTriggerMode);
	SettingsManager::add(zrMode);
	commandRegistry->add((new JSMAssignment<TriggerMode>(*zrMode))
	                       ->setHelp("Controllers with a left analog trigger can use one of the following dual stage trigger modes:\nNO_FULL, NO_SKIP, MAY_SKIP, MUST_SKIP, MAY_SKIP_R, MUST_SKIP_R, NO_SKIP_EXCLUSIVE, X_LT, X_RT, PS_L2, PS_R2"));

	auto flick_snap_mode = new JSMSetting<FlickSnapMode>(SettingID::FLICK_SNAP_MODE, FlickSnapMode::NONE);
	flick_snap_mode->setFilter(&filterInvalidValue<FlickSnapMode, FlickSnapMode::INVALID>);
	SettingsManager::add(flick_snap_mode);
	commandRegistry->add((new JSMAssignment<FlickSnapMode>(*flick_snap_mode))
	                       ->setHelp("Snap flicks to cardinal directions. Valid values are the following: NONE or 0, FOUR or 4 and EIGHT or 8."));

	auto min_gyro_sens = new JSMSetting<FloatXY>(SettingID::MIN_GYRO_SENS, { 0.0f, 0.0f });
	min_gyro_sens->setFilter(&filterFloatPair);
	SettingsManager::add(min_gyro_sens);
	commandRegistry->add((new JSMAssignment<FloatXY>(*min_gyro_sens))
	                       ->setHelp("Minimum gyro sensitivity when turning controller at or below MIN_GYRO_THRESHOLD.\nYou can assign a second value as a different vertical sensitivity."));

	auto max_gyro_sens = new JSMSetting<FloatXY>(SettingID::MAX_GYRO_SENS, { 0.0f, 0.0f });
	max_gyro_sens->setFilter(&filterFloatPair);
	SettingsManager::add(max_gyro_sens);
	commandRegistry->add((new JSMAssignment<FloatXY>(*max_gyro_sens))
	                       ->setHelp("Maximum gyro sensitivity when turning controller at or above MAX_GYRO_THRESHOLD.\nYou can assign a second value as a different vertical sensitivity."));

	commandRegistry->add((new GyroSensAssignment(SettingID::GYRO_SENS, *max_gyro_sens))->setHelp(""));
	commandRegistry->add((new GyroSensAssignment(SettingID::GYRO_SENS, *min_gyro_sens))
	                       ->setHelp("Sets a gyro sensitivity to use. This sets both MIN_GYRO_SENS and MAX_GYRO_SENS to the same values. You can assign a second value as a different vertical sensitivity."));

	auto min_gyro_threshold = new JSMSetting<float>(SettingID::MIN_GYRO_THRESHOLD, 0.0f);
	min_gyro_threshold->setFilter(&filterFloat);
	SettingsManager::add(min_gyro_threshold);
	commandRegistry->add((new JSMAssignment<float>(*min_gyro_threshold))
	                       ->setHelp("Degrees per second at and below which to apply minimum gyro sensitivity."));

	auto max_gyro_threshold = new JSMSetting<float>(SettingID::MAX_GYRO_THRESHOLD, 0.0f);
	max_gyro_threshold->setFilter(&filterFloat);
	SettingsManager::add(max_gyro_threshold);
	commandRegistry->add((new JSMAssignment<float>(*max_gyro_threshold))
	                       ->setHelp("Degrees per second at and above which to apply maximum gyro sensitivity."));

	auto accel_curve = new JSMSetting<AccelCurve>(SettingID::ACCEL_CURVE, AccelCurve::LINEAR);
	accel_curve->setFilter(&filterInvalidValue<AccelCurve, AccelCurve::INVALID>);
	SettingsManager::add(accel_curve);
	commandRegistry->add((new JSMAssignment<AccelCurve>("ACCEL_CURVE", *accel_curve))
	                       ->setHelp("Selects gyro acceleration curve. Options: LINEAR (default), NATURAL, POWER, QUADRATIC, SIGMOID, JUMP."));

	auto accel_natural_vhalf = new JSMSetting<float>(SettingID::ACCEL_NATURAL_VHALF, 200.0f);
	accel_natural_vhalf->setFilter(&filterPositive);
	SettingsManager::add(accel_natural_vhalf);
	commandRegistry->add((new JSMAssignment<float>(*accel_natural_vhalf))
	                       ->setHelp("Natural curve: velocity at which sensitivity reaches midpoint between MIN_GYRO_SENS and MAX_GYRO_SENS."));

	auto accel_power_vref = new JSMSetting<float>(SettingID::ACCEL_POWER_VREF, 0.01f);
	accel_power_vref->setFilter(&filterPositive);
	SettingsManager::add(accel_power_vref);
	commandRegistry->add((new JSMAssignment<float>(*accel_power_vref))
	                       ->setHelp("Power curve: scale applied to gyro speed before exponent."));

	auto accel_power_exponent = new JSMSetting<float>(SettingID::ACCEL_POWER_EXPONENT, 0.5f);
	accel_power_exponent->setFilter(&filterPositive);
	SettingsManager::add(accel_power_exponent);
	commandRegistry->add((new JSMAssignment<float>(*accel_power_exponent))
	                       ->setHelp("Power curve: exponent applied to scaled gyro speed."));

	auto accel_sigmoid_mid = new JSMSetting<float>(SettingID::ACCEL_SIGMOID_MID, 20.0f);
	accel_sigmoid_mid->setFilter(&filterPositive);
	SettingsManager::add(accel_sigmoid_mid);
	commandRegistry->add((new JSMAssignment<float>(*accel_sigmoid_mid))
	                       ->setHelp("Sigmoid curve: input speed at the midpoint between MIN_GYRO_SENS and MAX_GYRO_SENS."));

	auto accel_sigmoid_width = new JSMSetting<float>(SettingID::ACCEL_SIGMOID_WIDTH, 8.0f);
	accel_sigmoid_width->setFilter(&filterPositive);
	SettingsManager::add(accel_sigmoid_width);
	commandRegistry->add((new JSMAssignment<float>(*accel_sigmoid_width))
	                       ->setHelp("Sigmoid curve: width/steepness; larger values give gentler transitions."));

	auto accel_jump_tau = new JSMSetting<float>(SettingID::ACCEL_JUMP_TAU, 1.5f);
	accel_jump_tau->setFilter(&filterPositive);
	SettingsManager::add(accel_jump_tau);
	commandRegistry->add((new JSMAssignment<float>(*accel_jump_tau))
	                       ->setHelp("Jump curve: rise length (smaller = steeper) before reaching peak sensitivity."));

	auto stick_power = new JSMSetting<float>(SettingID::STICK_POWER, 1.0f);
	stick_power->setFilter(&filterFloat);
	SettingsManager::add(stick_power);
	commandRegistry->add((new JSMAssignment<float>(*stick_power))
	                       ->setHelp("Power curve for stick input when in AIM mode. 1 for linear, 0 for no curve (full strength once out of deadzone). Higher numbers make more of the stick's range appear like a very slight tilt."));

	auto stick_sens = new JSMSetting<FloatXY>(SettingID::STICK_SENS, { 360.0f, 360.0f });
	stick_sens->setFilter(&filterFloatPair);
	SettingsManager::add(stick_sens);
	commandRegistry->add((new JSMAssignment<FloatXY>(*stick_sens))
	                      ->setHelp("Stick sensitivity when using classic AIM mode."));

	auto real_world_calibration = new JSMSetting<float>(SettingID::REAL_WORLD_CALIBRATION, 40.0f);
	real_world_calibration->setFilter(&filterFloat);
	SettingsManager::add(real_world_calibration);
	commandRegistry->add((new JSMAssignment<float>(*real_world_calibration))
	                       ->setHelp("Calibration value mapping mouse values to in game degrees. This value is used for FLICK mode, and to make GYRO and stick AIM sensitivities use real world values."));

	auto virtual_stick_calibration = new JSMSetting<float>(SettingID::VIRTUAL_STICK_CALIBRATION, 360.0f);
	virtual_stick_calibration->setFilter(&filterFloat);
	SettingsManager::add(virtual_stick_calibration);
	commandRegistry->add((new JSMAssignment<float>(*virtual_stick_calibration))
	                       ->setHelp("With a virtual controller, how fast a full tilt of the stick will turn the controller, in degrees per second. This value is used for FLICK mode with virtual controllers and to make GYRO sensitivities use real world values."));

	auto in_game_sens = new JSMSetting<float>(SettingID::IN_GAME_SENS, 1.0f);
	in_game_sens->setFilter(bind(&fmaxf, 0.0001f, ::placeholders::_2));
	SettingsManager::add(in_game_sens);
	commandRegistry->add((new JSMAssignment<float>(*in_game_sens))
	                       ->setHelp("Set this value to the sensitivity you use in game. It is used by stick FLICK and AIM modes as well as GYRO aiming."));

	auto trigger_threshold = new JSMSetting<float>(SettingID::TRIGGER_THRESHOLD, 0.0f);
	trigger_threshold->setFilter(&filterFloat);
	SettingsManager::add(trigger_threshold);
	commandRegistry->add((new JSMAssignment<float>(*trigger_threshold))
	                       ->setHelp("Set this to a value between 0 and 1. This is the threshold at which a soft press binding is triggered. Or set the value to -1 to use hair trigger mode"));

	auto left_stick_axis = new JSMSetting<AxisSignPair>(SettingID::LEFT_STICK_AXIS, { AxisMode::STANDARD, AxisMode::STANDARD });
	left_stick_axis->setFilter(&filterSignPair);
	SettingsManager::add(left_stick_axis);
	commandRegistry->add((new JSMAssignment<AxisSignPair>(*left_stick_axis))
	                       ->setHelp("When in AIM mode, set stick X axis inversion. Valid values are the following:\nSTANDARD or 1, and INVERTED or -1"));

	auto right_stick_axis = new JSMSetting<AxisSignPair>(SettingID::RIGHT_STICK_AXIS, { AxisMode::STANDARD, AxisMode::STANDARD });
	right_stick_axis->setFilter(&filterSignPair);
	SettingsManager::add(right_stick_axis);
	commandRegistry->add((new JSMAssignment<AxisSignPair>(*right_stick_axis))
	                       ->setHelp("When in AIM mode, set stick X axis inversion. Valid values are the following:\nSTANDARD or 1, and INVERTED or -1"));

	auto motion_stick_axis = new JSMSetting<AxisSignPair>(SettingID::MOTION_STICK_AXIS, { AxisMode::STANDARD, AxisMode::STANDARD });
	motion_stick_axis->setFilter(&filterSignPair);
	SettingsManager::add(motion_stick_axis);
	commandRegistry->add((new JSMAssignment<AxisSignPair>(*motion_stick_axis))
	                       ->setHelp("When in AIM mode, set stick X axis inversion. Valid values are the following:\nSTANDARD or 1, and INVERTED or -1"));

	auto touch_stick_axis = new JSMSetting<AxisSignPair>(SettingID::TOUCH_STICK_AXIS, { AxisMode::STANDARD, AxisMode::STANDARD });
	touch_stick_axis->setFilter(&filterSignPair);
	SettingsManager::add(touch_stick_axis);
	commandRegistry->add((new JSMAssignment<AxisSignPair>(*touch_stick_axis))
	                       ->setHelp("When in AIM mode, set stick X axis inversion. Valid values are the following:\nSTANDARD or 1, and INVERTED or -1"));

	// Legacy command
	auto aim_x_sign = new JSMSetting<AxisMode>(SettingID::STICK_AXIS_X, AxisMode::STANDARD);
	aim_x_sign->setFilter(&filterInvalidValue<AxisMode, AxisMode::INVALID>)->addOnChangeListener(bind(onNewStickAxis, placeholders::_1, false));
	SettingsManager::add(aim_x_sign);
	commandRegistry->add(new JSMAssignment<AxisMode>(*aim_x_sign, true));

	// Legacy command
	auto aim_y_sign = new JSMSetting<AxisMode>(SettingID::STICK_AXIS_Y, AxisMode::STANDARD);
	aim_y_sign->setFilter(&filterInvalidValue<AxisMode, AxisMode::INVALID>)->addOnChangeListener(bind(onNewStickAxis, placeholders::_1, true));
	SettingsManager::add(aim_y_sign);
	commandRegistry->add(new JSMAssignment<AxisMode>(*aim_y_sign, true));

	auto gyro_x_sign = new JSMSetting<AxisMode>(SettingID::GYRO_AXIS_Y, AxisMode::STANDARD);
	gyro_x_sign->setFilter(&filterInvalidValue<AxisMode, AxisMode::INVALID>);
	SettingsManager::add(gyro_x_sign);
	commandRegistry->add((new JSMAssignment<AxisMode>(*gyro_x_sign))
	                       ->setHelp("Set gyro X axis inversion. Valid values are the following:\nSTANDARD or 1, and INVERTED or -1"));

	auto gyro_y_sign = new JSMSetting<AxisMode>(SettingID::GYRO_AXIS_X, AxisMode::STANDARD);
	gyro_y_sign->setFilter(&filterInvalidValue<AxisMode, AxisMode::INVALID>);
	SettingsManager::add(gyro_y_sign);
	commandRegistry->add((new JSMAssignment<AxisMode>(*gyro_y_sign))
	                       ->setHelp("Set gyro Y axis inversion. Valid values are the following:\nSTANDARD or 1, and INVERTED or -1"));

	auto flick_time = new JSMSetting<float>(SettingID::FLICK_TIME, 0.1f);
	flick_time->setFilter(bind(&fmaxf, 0.0001f, ::placeholders::_2));
	SettingsManager::add(flick_time);
	commandRegistry->add((new JSMAssignment<float>(*flick_time))
	                       ->setHelp("Sets how long a flick takes in seconds. This value is used by stick FLICK mode."));

	auto flick_time_exponent = new JSMSetting<float>(SettingID::FLICK_TIME_EXPONENT, 0.0f);
	flick_time_exponent->setFilter(&filterFloat);
	SettingsManager::add(flick_time_exponent);
	commandRegistry->add((new JSMAssignment<float>(*flick_time_exponent))
	                       ->setHelp("Applies a delta exponent to flick_time, effectively making flick speed depend on the flick angle: use 0 for no effect and 1 for linear. This value is used by stick FLICK mode."));

	auto gyro_smooth_time = new JSMSetting<float>(SettingID::GYRO_SMOOTH_TIME, 0.125f);
	gyro_smooth_time->setFilter(bind(&fmaxf, 0.0001f, ::placeholders::_2));
	SettingsManager::add(gyro_smooth_time);
	commandRegistry->add((new JSMAssignment<float>(*gyro_smooth_time))
	                       ->setHelp("This length of the smoothing window in seconds. Smoothing is only applied below the GYRO_SMOOTH_THRESHOLD, with a smooth transition to full smoothing."));

	auto gyro_smooth_threshold = new JSMSetting<float>(SettingID::GYRO_SMOOTH_THRESHOLD, 0.0f);
	gyro_smooth_threshold->setFilter(&filterPositive);
	SettingsManager::add(gyro_smooth_threshold);
	commandRegistry->add((new JSMAssignment<float>(*gyro_smooth_threshold))
	                       ->setHelp("When the controller's angular velocity is below this threshold (in degrees per second), smoothing will be applied."));

	auto gyro_smoothing_decay = new JSMSetting<Switch>(SettingID::GYRO_SMOOTHING_DECAY, Switch::OFF);
	gyro_smoothing_decay->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	SettingsManager::add(gyro_smoothing_decay);
	commandRegistry->add((new JSMAssignment<Switch>(*gyro_smoothing_decay))
	                       ->setHelp("When ON, uses speed-decay EMA smoothing instead of the legacy moving-average gyro smoothing."));

	auto gyro_cutoff_speed = new JSMSetting<float>(SettingID::GYRO_CUTOFF_SPEED, 0.0f);
	gyro_cutoff_speed->setFilter(&filterPositive);
	SettingsManager::add(gyro_cutoff_speed);
	commandRegistry->add((new JSMAssignment<float>(*gyro_cutoff_speed))
	                       ->setHelp("Gyro deadzone. Gyro input will be ignored when below this angular velocity (in degrees per second). This should be a last-resort stability option."));

	auto gyro_cutoff_recovery = new JSMSetting<float>(SettingID::GYRO_CUTOFF_RECOVERY, 0.0f);
	gyro_cutoff_recovery->setFilter(&filterPositive);
	SettingsManager::add(gyro_cutoff_recovery);
	commandRegistry->add((new JSMAssignment<float>(*gyro_cutoff_recovery))
	                       ->setHelp("Below this threshold (in degrees per second), gyro sensitivity is pushed down towards zero. This can tighten and steady aim without a deadzone."));

	auto one_euro_min_cutoff = new JSMSetting<float>(SettingID::ONE_EURO_MIN_CUTOFF, 6.0f);
	one_euro_min_cutoff->setFilter(&filterPositive);
	SettingsManager::add(one_euro_min_cutoff);
	commandRegistry->add((new JSMAssignment<float>(*one_euro_min_cutoff))
	                       ->setHelp("Minimum cutoff frequency for One Euro filter. Lower this value to reduce slow speed jitter."));

	auto one_euro_speed_coeff = new JSMSetting<float>(SettingID::ONE_EURO_SPEED_COEFF, 0.3f);
	one_euro_speed_coeff->setFilter(&filterPositive);
	SettingsManager::add(one_euro_speed_coeff);
	commandRegistry->add((new JSMAssignment<float>(*one_euro_speed_coeff))
	                       ->setHelp("Speed coefficient for One Euro filter. Raise this value to reduce speed lag."));

	auto gyro_angle_snap_ease = new JSMSetting<Switch>(SettingID::GYRO_ANGLE_SNAP_EASE, Switch::OFF);
	gyro_angle_snap_ease->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	SettingsManager::add(gyro_angle_snap_ease);
	commandRegistry->add((new JSMAssignment<Switch>(*gyro_angle_snap_ease))
	                       ->setHelp("When ON, applies a smooth transition into angle snapping instead of a hard snap."));

	auto gyro_angle_snap = new JSMSetting<float>(SettingID::GYRO_ANGLE_SNAP, 0.0f);
	gyro_angle_snap->setFilter([](float current, float next)
	  { return std::clamp(next, 0.0f, 45.0f); });
	SettingsManager::add(gyro_angle_snap);
	commandRegistry->add((new JSMAssignment<float>(*gyro_angle_snap))
	                       ->setHelp("Degrees of angle snapping for gyro input. Snaps movement to horizontal/vertical when within this angle. 0 disables snapping. (Range: 0-45)"));

	auto decel_brake_strength = new JSMSetting<float>(SettingID::DECEL_BRAKE_STRENGTH, 0.0f);
	decel_brake_strength->setFilter([](float current, float next)
	  { return std::clamp(next, 0.0f, 1.0f); });
	SettingsManager::add(decel_brake_strength);
	commandRegistry->add((new JSMAssignment<float>(*decel_brake_strength))
	                       ->setHelp("Deceleration brake strength (0-1). Higher values apply more braking when stopping."));

	auto decel_brake_threshold = new JSMSetting<float>(SettingID::DECEL_BRAKE_THRESHOLD, 25.0f);
	decel_brake_threshold->setFilter(&filterPositive);
	SettingsManager::add(decel_brake_threshold);
	commandRegistry->add((new JSMAssignment<float>(*decel_brake_threshold))
	                       ->setHelp("Deceleration brake trigger threshold (deg/s drop over a short window). Lower values trigger more easily."));

	auto stick_acceleration_rate = new JSMSetting<float>(SettingID::STICK_ACCELERATION_RATE, 0.0f);
	stick_acceleration_rate->setFilter(&filterPositive);
	SettingsManager::add(stick_acceleration_rate);
	commandRegistry->add((new JSMAssignment<float>(*stick_acceleration_rate))
	                       ->setHelp("When in AIM mode and the stick is fully tilted, stick sensitivity increases over time. This is a multiplier starting at 1x and increasing this by this value per second."));

	auto stick_acceleration_cap = new JSMSetting<float>(SettingID::STICK_ACCELERATION_CAP, 1000000.0f);
	stick_acceleration_cap->setFilter(bind(&fmaxf, 1.0f, ::placeholders::_2));
	SettingsManager::add(stick_acceleration_cap);
	commandRegistry->add((new JSMAssignment<float>(*stick_acceleration_cap))
	                       ->setHelp("When in AIM mode and the stick is fully tilted, stick sensitivity increases over time. This value is the maximum sensitivity multiplier."));

	auto left_stick_deadzone_inner = new JSMSetting<float>(SettingID::LEFT_STICK_DEADZONE_INNER, 0.15f);
	left_stick_deadzone_inner->setFilter(&filterClamp01);
	SettingsManager::add(left_stick_deadzone_inner);
	commandRegistry->add((new JSMAssignment<float>(*left_stick_deadzone_inner))
	                       ->setHelp("Defines a radius of the left stick within which all values will be ignored. This value can only be between 0 and 1 but it should be small. Stick input out of this radius will be adjusted."));

	auto left_stick_deadzone_outer = new JSMSetting<float>(SettingID::LEFT_STICK_DEADZONE_OUTER, 0.1f);
	left_stick_deadzone_outer->setFilter(&filterClamp01);
	SettingsManager::add(left_stick_deadzone_outer);
	commandRegistry->add((new JSMAssignment<float>(*left_stick_deadzone_outer))
	                       ->setHelp("Defines a distance from the left stick's outer edge for which the stick will be considered fully tilted. This value can only be between 0 and 1 but it should be small. Stick input out of this deadzone will be adjusted."));

	auto flick_deadzone_angle = new JSMSetting<float>(SettingID::FLICK_DEADZONE_ANGLE, 0.0f);
	flick_deadzone_angle->setFilter(&filterPositive);
	SettingsManager::add(flick_deadzone_angle);
	commandRegistry->add((new JSMAssignment<float>(*flick_deadzone_angle))
	                       ->setHelp("Defines a minimum angle (in degrees) for the flick to be considered a flick. Helps ignore unintentional turns when tilting the stick straight forward."));

	auto right_stick_deadzone_inner = new JSMSetting<float>(SettingID::RIGHT_STICK_DEADZONE_INNER, 0.15f);
	right_stick_deadzone_inner->setFilter(&filterClamp01);
	SettingsManager::add(right_stick_deadzone_inner);
	commandRegistry->add((new JSMAssignment<float>(*right_stick_deadzone_inner))
	                       ->setHelp("Defines a radius of the right stick within which all values will be ignored. This value can only be between 0 and 1 but it should be small. Stick input out of this radius will be adjusted."));

	auto right_stick_deadzone_outer = new JSMSetting<float>(SettingID::RIGHT_STICK_DEADZONE_OUTER, 0.1f);
	right_stick_deadzone_outer->setFilter(&filterClamp01);
	SettingsManager::add(right_stick_deadzone_outer);
	commandRegistry->add((new JSMAssignment<float>(*right_stick_deadzone_outer))
	                       ->setHelp("Defines a distance from the right stick's outer edge for which the stick will be considered fully tilted. This value can only be between 0 and 1 but it should be small. Stick input out of this deadzone will be adjusted."));

	commandRegistry->add((new StickDeadzoneAssignment(SettingID::STICK_DEADZONE_INNER, *right_stick_deadzone_inner))->setHelp(""));
	commandRegistry->add((new StickDeadzoneAssignment(SettingID::STICK_DEADZONE_INNER, *left_stick_deadzone_inner))->setHelp(""));

	commandRegistry->add((new StickDeadzoneAssignment(SettingID::STICK_DEADZONE_OUTER, *right_stick_deadzone_outer))->setHelp(""));
	commandRegistry->add((new StickDeadzoneAssignment(SettingID::STICK_DEADZONE_OUTER, *left_stick_deadzone_outer))
	                       ->setHelp("Defines a distance from both sticks' outer edge for which the stick will be considered fully tilted. This value can only be between 0 and 1 but it should be small. Stick input out of this deadzone will be adjusted."));

	auto motion_deadzone_inner = new JSMSetting<float>(SettingID::MOTION_DEADZONE_INNER, 15.f);
	motion_deadzone_inner->setFilter(&filterPositive);
	SettingsManager::add(motion_deadzone_inner);
	commandRegistry->add((new JSMAssignment<float>(*motion_deadzone_inner))
	                       ->setHelp("Defines a radius of the motion-stick within which all values will be ignored. This value can only be between 0 and 1 but it should be small. Stick input out of this radius will be adjusted."));

	auto motion_deadzone_outer = new JSMSetting<float>(SettingID::MOTION_DEADZONE_OUTER, 135.f);
	motion_deadzone_outer->setFilter(&filterPositive);
	SettingsManager::add(motion_deadzone_outer);
	commandRegistry->add((new JSMAssignment<float>(*motion_deadzone_outer))
	                       ->setHelp("Defines a distance from the motion-stick's outer edge for which the stick will be considered fully tilted. Stick input out of this deadzone will be adjusted."));

	auto angle_to_axis_deadzone_inner = new JSMSetting<float>(SettingID::ANGLE_TO_AXIS_DEADZONE_INNER, 0.f);
	angle_to_axis_deadzone_inner->setFilter(&filterPositive);
	SettingsManager::add(angle_to_axis_deadzone_inner);
	commandRegistry->add((new JSMAssignment<float>(*angle_to_axis_deadzone_inner))
	                       ->setHelp("Defines an angle within which _ANGLE_TO_X and _ANGLE_TO_Y stick modes will be ignored (in degrees). Since a circular deadzone is already used for deciding whether the stick is engaged at all, it's recommended not to use an inner angular deadzone, which is why the default value is 0."));

	auto angle_to_axis_deadzone_outer = new JSMSetting<float>(SettingID::ANGLE_TO_AXIS_DEADZONE_OUTER, 10.f);
	angle_to_axis_deadzone_outer->setFilter(&filterPositive);
	SettingsManager::add(angle_to_axis_deadzone_outer);
	commandRegistry->add((new JSMAssignment<float>(*angle_to_axis_deadzone_outer))
	                       ->setHelp("Defines an angle from max or min rotation that will be treated as max or min rotation, respectively, for _ANGLE_TO_X and _ANGLE_TO_Y stick modes. Since players intending to point the stick perfectly up/down or perfectly left/right will usually be off by a few degrees, this enables players to more easily hit their intended min/max values, so the default value is 10 degrees."));

	auto lean_threshold = new JSMSetting<float>(SettingID::LEAN_THRESHOLD, 15.f);
	lean_threshold->setFilter(&filterPositive);
	SettingsManager::add(lean_threshold);
	commandRegistry->add((new JSMAssignment<float>(*lean_threshold))
	                       ->setHelp("How far the controller must be leaned left or right to trigger a LEAN_LEFT or LEAN_RIGHT binding."));

	auto controller_orientation = new JSMSetting<ControllerOrientation>(SettingID::CONTROLLER_ORIENTATION, ControllerOrientation::FORWARD);
	controller_orientation->setFilter(&filterInvalidValue<ControllerOrientation, ControllerOrientation::INVALID>);
	SettingsManager::add(controller_orientation);
	commandRegistry->add((new JSMAssignment<ControllerOrientation>(*controller_orientation))
	                       ->setHelp("Let the stick modes account for how you're holding the controller:\nFORWARD, LEFT, RIGHT, BACKWARD"));

	auto gyro_space = new JSMSetting<GyroSpace>(SettingID::GYRO_SPACE, GyroSpace::LOCAL);
	gyro_space->setFilter(&filterInvalidValue<GyroSpace, GyroSpace::INVALID>);
	SettingsManager::add(gyro_space);
	commandRegistry->add((new JSMAssignment<GyroSpace>(*gyro_space))
	                       ->setHelp("How gyro input is converted to 2D input. With LOCAL, your MOUSE_X_FROM_GYRO_AXIS and MOUSE_Y_FROM_GYRO_AXIS settings decide which local angular axis maps to which 2D mouse axis.\nYAW_PLUS_ROLL keeps pitch on Y and combines yaw + roll on X using ROLL_CONTRIBUTION.\nYour other options are PLAYER_TURN and PLAYER_LEAN. These both take gravity into account to combine your axes more reliably.\n\tUse PLAYER_TURN if you like to turn your camera or move your cursor by turning your controller side to side.\n\tUse PLAYER_LEAN if you'd rather lean your controller to turn the camera."));

	auto roll_contribution = new JSMSetting<float>(SettingID::ROLL_CONTRIBUTION, 0.0f);
	roll_contribution->setFilter(&filterClampPercent);
	SettingsManager::add(roll_contribution);
	commandRegistry->add((new JSMAssignment<float>(*roll_contribution))
	                       ->setHelp("When GYRO_SPACE is YAW_PLUS_ROLL, adds roll to horizontal turn as a percentage of yaw sensitivity. Valid range is -100 to 100."));

	auto trackball_decay = new JSMSetting<float>(SettingID::TRACKBALL_DECAY, 1.0f);
	trackball_decay->setFilter(&filterPositive);
	SettingsManager::add(trackball_decay);
	commandRegistry->add((new JSMAssignment<float>(*trackball_decay))
	                       ->setHelp("Choose the rate at which trackball gyro slows down. 0 means no decay, 1 means it'll halve each second, 2 to halve each 1/2 seconds, etc."));

	auto screen_resolution_x = new JSMSetting<float>(SettingID::SCREEN_RESOLUTION_X, 1920.0f);
	screen_resolution_x->setFilter(&filterPositive);
	SettingsManager::add(screen_resolution_x);
	commandRegistry->add((new JSMAssignment<float>(*screen_resolution_x))
	                       ->setHelp("Indicate your monitor's horizontal resolution when using the stick mode MOUSE_RING."));

	auto screen_resolution_y = new JSMSetting<float>(SettingID::SCREEN_RESOLUTION_Y, 1080.0f);
	screen_resolution_y->setFilter(&filterPositive);
	SettingsManager::add(screen_resolution_y);
	commandRegistry->add((new JSMAssignment<float>(*screen_resolution_y))
	                       ->setHelp("Indicate your monitor's vertical resolution when using the stick mode MOUSE_RING."));

	auto mouse_ring_radius = new JSMSetting<float>(SettingID::MOUSE_RING_RADIUS, 128.0f);
	mouse_ring_radius->setFilter([](float c, float n) -> float
	  { return n <= SettingsManager::get<float>(SettingID::SCREEN_RESOLUTION_Y)->value() ? floorf(n) : c; });
	SettingsManager::add(mouse_ring_radius);
	commandRegistry->add((new JSMAssignment<float>(*mouse_ring_radius))
	                       ->setHelp("Pick a radius on which the cursor will be allowed to move. This value is used for stick mode MOUSE_RING and MOUSE_AREA."));

	auto rotate_smooth_override = new JSMSetting<float>(SettingID::ROTATE_SMOOTH_OVERRIDE, -1.0f);
	// No filtering needed for rotate_smooth_override
	SettingsManager::add(rotate_smooth_override);
	commandRegistry->add((new JSMAssignment<float>(*rotate_smooth_override))
	                       ->setHelp("Some smoothing is applied to flick stick rotations to account for the controller's stick resolution. This value overrides the smoothing threshold."));

	auto flick_snap_strength = new JSMSetting<float>(SettingID::FLICK_SNAP_STRENGTH, 01.0f);
	flick_snap_strength->setFilter(&filterClamp01);
	SettingsManager::add(flick_snap_strength);
	commandRegistry->add((new JSMAssignment<float>(*flick_snap_strength))
	                       ->setHelp("If FLICK_SNAP_MODE is set to something other than NONE, this sets the degree of snapping -- 0 for none, 1 for full snapping to the nearest direction, and values in between will bias you towards the nearest direction instead of snapping."));

	auto trigger_skip_delay = new JSMSetting<float>(SettingID::TRIGGER_SKIP_DELAY, 150.0f);
	trigger_skip_delay->setFilter(&filterPositive);
	SettingsManager::add(trigger_skip_delay);
	commandRegistry->add((new JSMAssignment<float>(*trigger_skip_delay))
	                       ->setHelp("Sets the amount of time in milliseconds within which the user needs to reach the full press to skip the soft pull binding of the trigger."));

	auto turbo_period = new JSMSetting<float>(SettingID::TURBO_PERIOD, 80.0f);
	turbo_period->setFilter(&filterPositive);
	SettingsManager::add(turbo_period);
	commandRegistry->add((new JSMAssignment<float>(*turbo_period))
	                       ->setHelp("Sets the time in milliseconds to wait between each turbo activation."));

	auto hold_press_time = new JSMSetting<float>(SettingID::HOLD_PRESS_TIME, 150.0f);
	hold_press_time->setFilter(&filterHoldPressDelay);
	SettingsManager::add(hold_press_time);
	commandRegistry->add((new JSMAssignment<float>(*hold_press_time))
	                       ->setHelp("Sets the amount of time in milliseconds to hold a button before the hold press is enabled. Releasing the button before this time will trigger the tap press. Turbo press only starts after this delay."));

	auto sim_press_window = new JSMVariable<float>(50.0f);
	sim_press_window->setFilter(&filterPositive);
	SettingsManager::add(SettingID::SIM_PRESS_WINDOW, sim_press_window);
	commandRegistry->add((new JSMAssignment<float>("SIM_PRESS_WINDOW", *sim_press_window))
	                       ->setHelp("Sets the amount of time in milliseconds within which both buttons of a simultaneous press needs to be pressed before enabling the sim press mappings. This setting does not support modeshift."));

	auto dbl_press_window = new JSMSetting<float>(SettingID::DBL_PRESS_WINDOW, 150.0f);
	dbl_press_window->setFilter(&filterPositive);
	SettingsManager::add(dbl_press_window);
	commandRegistry->add((new JSMAssignment<float>("DBL_PRESS_WINDOW", *dbl_press_window))
	                       ->setHelp("Sets the amount of time in milliseconds within which the user needs to press a button twice before enabling the double press mappings. This setting does not support modeshift."));

	auto tick_time = new JSMSetting<float>(SettingID::TICK_TIME, 3);
	tick_time->setFilter(&filterTickTime);
	SettingsManager::add(tick_time);
	commandRegistry->add((new JSMAssignment<float>("TICK_TIME", *tick_time))
	                       ->setHelp("Sets the time in milliseconds that JoyShockMaper waits before reading from each controller again."));

	auto light_bar = new JSMSetting<Color>(SettingID::LIGHT_BAR, 0xFFFFFF);
	// light_bar needs no filter or listener. The callback polls and updates the color.
	SettingsManager::add(light_bar);
	commandRegistry->add((new JSMAssignment<Color>(*light_bar))
	                       ->setHelp("Changes the color bar of the DS4. Either enter as a hex code (xRRGGBB), as three decimal values between 0 and 255 (RRR GGG BBB), or as a common color name in all caps and underscores."));

	auto scroll_sens = new JSMSetting<FloatXY>(SettingID::SCROLL_SENS, { 30.f, 30.f });
	scroll_sens->setFilter(&filterFloatPair);
	SettingsManager::add(scroll_sens);
	commandRegistry->add((new JSMAssignment<FloatXY>(*scroll_sens))
	                       ->setHelp("Scrolling sensitivity for sticks."));

	auto autoloadSwitch = new JSMVariable<Switch>(Switch::ON);
	autoLoadThread.reset(new JSM::AutoLoad(commandRegistry, autoloadSwitch->value() == Switch::ON)); // Start by default
	autoloadSwitch->setFilter(&filterInvalidValue<Switch, Switch::INVALID>)->addOnChangeListener(bind(&updateThread, autoLoadThread.get(), placeholders::_1));
	SettingsManager::add(SettingID::AUTOLOAD, autoloadSwitch);
	auto *autoloadCmd = new JSMAssignment<Switch>("AUTOLOAD", *autoloadSwitch);
	commandRegistry->add(autoloadCmd);

	auto autoConnectSwitch = new JSMVariable<Switch>(g_manualConnectMode ? Switch::OFF : Switch::ON);
	autoConnectThread.reset(new JSM::AutoConnect(jsl, autoConnectSwitch->value() == Switch::ON)); // Start by default
	autoConnectSwitch->setFilter(&filterInvalidValue<Switch, Switch::INVALID>)->addOnChangeListener(bind(&updateThread, autoConnectThread.get(), placeholders::_1));
	SettingsManager::add(SettingID::AUTOCONNECT, autoConnectSwitch);
	commandRegistry->add((new JSMAssignment<Switch>("AUTOCONNECT", *autoConnectSwitch))->setHelp("Enable or disable device hotplugging. Valid values are ON and OFF."));

	auto grid_size = new JSMVariable(FloatXY{ 2.f, 1.f });
	grid_size->setFilter([](auto current, auto next)
	  {
		float floorX = floorf(next.x());
		float floorY = floorf(next.y());
		return floorX * floorY >= 1 && floorX * floorY <= 25 ? FloatXY{ floorX, floorY } : current; });
	grid_size->addOnChangeListener(bind(&onNewGridDimensions, commandRegistry, placeholders::_1), true); // Call the listener now
	SettingsManager::add(SettingID::GRID_SIZE, grid_size);
	commandRegistry->add((new JSMAssignment<FloatXY>("GRID_SIZE", *grid_size))
	                       ->setHelp("When TOUCHPAD_MODE is set to GRID_AND_STICK, this variable sets the number of rows and columns in the grid. The product of the two numbers need to be between 1 and 25."));

	auto touchpad_mode = new JSMSetting<TouchpadMode>(SettingID::TOUCHPAD_MODE, TouchpadMode::GRID_AND_STICK);
	touchpad_mode->setFilter(&filterInvalidValue<TouchpadMode, TouchpadMode::INVALID>);
	SettingsManager::add(touchpad_mode);
	commandRegistry->add((new JSMAssignment<TouchpadMode>("TOUCHPAD_MODE", *touchpad_mode))
	                       ->setHelp("Assign a mode to the touchpad. Valid values are GRID_AND_STICK or MOUSE."));

	auto touch_ring_mode = new JSMSetting<RingMode>(SettingID::TOUCH_RING_MODE, RingMode::OUTER);
	touch_ring_mode->setFilter(&filterInvalidValue<RingMode, RingMode::INVALID>);
	SettingsManager::add(touch_ring_mode);
	commandRegistry->add((new JSMAssignment<RingMode>(*touch_ring_mode))
	                       ->setHelp("Sets the ring mode for the touch stick. Valid values are INNER and OUTER"));

	auto touch_stick_mode = new JSMSetting<StickMode>(SettingID::TOUCH_STICK_MODE, StickMode::NO_MOUSE);
	touch_stick_mode->setFilter(&filterInvalidValue<StickMode, StickMode::INVALID>)->addOnChangeListener(bind(&updateRingModeFromStickMode, touch_ring_mode, ::placeholders::_1));
	SettingsManager::add(touch_stick_mode);
	commandRegistry->add((new JSMAssignment<StickMode>(*touch_stick_mode))
	                       ->setHelp("Set a mouse mode for the touchpad stick. Valid values are the following:\nNO_MOUSE, AIM, FLICK, FLICK_ONLY, ROTATE_ONLY, MOUSE_RING, MOUSE_AREA, OUTER_RING, INNER_RING"));

	auto touch_deadzone_inner = new JSMSetting<float>(SettingID::TOUCH_DEADZONE_INNER, 0.3f);
	touch_deadzone_inner->setFilter(&filterPositive);
	SettingsManager::add(touch_deadzone_inner);
	commandRegistry->add((new JSMAssignment<float>(*touch_deadzone_inner))
	                       ->setHelp("Sets the radius of the circle in which a touch stick input sends no output."));

	auto touch_stick_radius = new JSMSetting<float>(SettingID::TOUCH_STICK_RADIUS, 300.f);
	touch_stick_radius->setFilter([](auto current, auto next)
	  { return filterPositive(current, floorf(next)); });
	SettingsManager::add(touch_stick_radius);
	commandRegistry->add((new JSMAssignment<float>(*touch_stick_radius))
	                       ->setHelp("Set the radius of the touchpad stick. The center of the stick is always the first point of contact. Use a very large value (ex: 800) to use it as swipe gesture."));

	auto touchpad_sens = new JSMSetting<FloatXY>(SettingID::TOUCHPAD_SENS, { 1.f, 1.f });
	touchpad_sens->setFilter(filterFloatPair);
	SettingsManager::add(touchpad_sens);
	commandRegistry->add((new JSMAssignment<FloatXY>(*touchpad_sens))
	                       ->setHelp("Changes the sensitivity of the touchpad when set as a mouse. Enter a second value for a different vertical sensitivity."));

	auto hide_minimized = new JSMVariable<Switch>(Switch::OFF);
	minimizeThread.reset(new PollingThread( "Minimize thread", [] (void *param)
		{
			if (isConsoleMinimized())
			{
				HideConsole();
			}
			return true; 
		}, nullptr, 1000, hide_minimized->value() == Switch::ON)); // Start by default
	hide_minimized->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	hide_minimized->addOnChangeListener(bind(&updateThread, minimizeThread.get(), placeholders::_1));
	SettingsManager::add(SettingID::HIDE_MINIMIZED, hide_minimized);
	commandRegistry->add((new JSMAssignment<Switch>("HIDE_MINIMIZED", *hide_minimized))
	                       ->setHelp("JSM will be hidden in the notification area when minimized if this setting is ON. Otherwise it stays in the taskbar."));

	auto virtual_controller = new JSMVariable<ControllerScheme>(ControllerScheme::NONE);
	virtual_controller->setFilter(&updateVirtualController);
	virtual_controller->addOnChangeListener(&onVirtualControllerChange);
	SettingsManager::add(SettingID::VIRTUAL_CONTROLLER, virtual_controller);
	commandRegistry->add((new JSMAssignment<ControllerScheme>(magic_enum::enum_name(SettingID::VIRTUAL_CONTROLLER).data(), *virtual_controller))
	                       ->setHelp("Sets the vigem virtual controller type. Can be NONE (default), XBOX (360) or DS4 (PS4)."));

	auto touch_ds_mode = new JSMSetting<TriggerMode>(SettingID::TOUCHPAD_DUAL_STAGE_MODE, TriggerMode::NO_SKIP);
	;
	touch_ds_mode->setFilter(&filterTouchpadDualStageMode);
	SettingsManager::add(touch_ds_mode);
	commandRegistry->add((new JSMAssignment<TriggerMode>(*touch_ds_mode))
	                       ->setHelp("Dual stage mode for the touchpad TOUCH and CAPTURE (i.e. click) bindings."));

	auto rumble_enable = new JSMVariable<Switch>(Switch::ON);
	rumble_enable->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	SettingsManager::add(SettingID::RUMBLE, rumble_enable);
	commandRegistry->add((new JSMAssignment<Switch>(magic_enum::enum_name(SettingID::RUMBLE).data(), *rumble_enable))
	                       ->setHelp("Disable the rumbling feature from vigem. Valid values are ON and OFF."));

	auto telemetry_enabled = new JSMSetting<Switch>(SettingID::TELEMETRY_ENABLED, Switch::OFF);
	telemetry_enabled->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	SettingsManager::add(SettingID::TELEMETRY_ENABLED, telemetry_enabled);
	telemetry_enabled->addOnChangeListener([](const Switch &)
	                                       { RefreshTelemetrySettings(); }, true);
	commandRegistry->add((new JSMAssignment<Switch>("TELEMETRY_ENABLED", *telemetry_enabled))
	                       ->setHelp("Enable or disable the UDP telemetry stream used by the viewer. Valid values are ON and OFF."));

	auto telemetry_port = new JSMSetting<int>(SettingID::TELEMETRY_PORT, Telemetry::kDefaultPort);
	telemetry_port->setFilter([](int current, int next)
	                          {
		                          if (next < 1024 || next > 65535)
		                          {
			                          CERR << "TELEMETRY_PORT must be between 1024 and 65535.\n";
			                          return current;
		                          }
		                          return next;
	                          });
	telemetry_port->addOnChangeListener([](int)
	                                    { RefreshTelemetrySettings(); });
	SettingsManager::add(SettingID::TELEMETRY_PORT, telemetry_port);
	commandRegistry->add((new JSMAssignment<int>("TELEMETRY_PORT", *telemetry_port))
	                       ->setHelp("Set the UDP port that telemetry packets are sent to (default 8974). Valid range: 1024-65535."));

	auto adaptive_trigger = new JSMSetting<Switch>(SettingID::ADAPTIVE_TRIGGER, Switch::ON);
	adaptive_trigger->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	SettingsManager::add(adaptive_trigger);
	commandRegistry->add((new JSMAssignment<Switch>(*adaptive_trigger))
	                       ->setHelp("Control the adaptive trigger feature of the DualSense. Valid values are ON and OFF."));

	auto left_trigger_effect = new JSMSetting<AdaptiveTriggerSetting>(SettingID::LEFT_TRIGGER_EFFECT, AdaptiveTriggerSetting{});
	left_trigger_effect->setFilter(static_cast<AdaptiveTriggerSetting (*)(AdaptiveTriggerSetting, AdaptiveTriggerSetting)>(&filterInvalidValue));
	SettingsManager::add(left_trigger_effect);
	commandRegistry->add((new JSMAssignment<AdaptiveTriggerSetting>(*left_trigger_effect))
	                       ->setHelp("Sets the adaptive trigger effect on the left trigger:\n"
	                                 "OFF: No effect\n"
	                                 "ON: Use effect generated by JSM depending on ZL_MODE\n"
	                                 "RESISTANCE start[0 9] force[0 8]: Some resistance starting at point\n"
	                                 "BOW start[0 8] end[0 8] forceStart[0 8] forceEnd[0 8]: increasingly strong resistance\n"
	                                 "GALLOPING start[0 8] end[0 9] foot1[0 6] foot2[0 7] freq[Hz]: Two pulses repeated periodically\n"
	                                 "SEMI_AUTOMATIC start[2 7] end[0 8] force[0 8]: Trigger effect\n"
	                                 "AUTOMATIC start[0 9] strength[0 8] freq[Hz]: Regular pulse effect\n"
	                                 "MACHINE start[0 9] end[0 9] force1[0 7] force2[0 7] freq[Hz] period: Irregular pulsing"));

	auto right_trigger_effect = new JSMSetting<AdaptiveTriggerSetting>(SettingID::RIGHT_TRIGGER_EFFECT, AdaptiveTriggerSetting{});
	right_trigger_effect->setFilter(static_cast<AdaptiveTriggerSetting (*)(AdaptiveTriggerSetting, AdaptiveTriggerSetting)>(&filterInvalidValue));
	SettingsManager::add(right_trigger_effect);
	commandRegistry->add((new JSMAssignment<AdaptiveTriggerSetting>(*right_trigger_effect))
	                       ->setHelp("Sets the adaptive trigger effect on the right trigger:\n"
	                                 "OFF: No effect\n"
	                                 "ON: Use effect generated by JSM depending on ZR_MODE\n"
	                                 "RESISTANCE start[0 9] force[0 8]: Some resistance starting at point\n"
	                                 "BOW start[0 8] end[0 8] forceStart[0 8] forceEnd[0 8]: increasingly strong resistance\n"
	                                 "GALLOPING start[0 8] end[0 9] foot1[0 6] foot2[0 7] freq[Hz]: Two pulses repeated periodically\n"
	                                 "SEMI_AUTOMATIC start[2 7] end[0 8] force[0 8]: Trigger effect\n"
	                                 "AUTOMATIC start[0 9] strength[0 8] freq[Hz]: Regular pulse effect\n"
	                                 "MACHINE start[0 9] end[0 9] force1[0 7] force2[0 7] freq[Hz] period: Irregular pulsing"));

	auto right_trigger_offset = new JSMVariable<int>(25);
	right_trigger_offset->setFilter(&filterClampByte);
	SettingsManager::add(SettingID::RIGHT_TRIGGER_OFFSET, right_trigger_offset);
	commandRegistry->add((new JSMAssignment<int>(magic_enum::enum_name(SettingID::RIGHT_TRIGGER_OFFSET).data(), *right_trigger_offset)));

	auto left_trigger_offset = new JSMVariable<int>(25);
	left_trigger_offset->setFilter(&filterClampByte);
	SettingsManager::add(SettingID::LEFT_TRIGGER_OFFSET, left_trigger_offset);
	commandRegistry->add((new JSMAssignment<int>(magic_enum::enum_name(SettingID::LEFT_TRIGGER_OFFSET).data(), *left_trigger_offset)));

	auto right_trigger_range = new JSMVariable<int>(150);
	right_trigger_range->setFilter(&filterClampByte);
	SettingsManager::add(SettingID::RIGHT_TRIGGER_RANGE, right_trigger_range);
	commandRegistry->add((new JSMAssignment<int>(magic_enum::enum_name(SettingID::RIGHT_TRIGGER_RANGE).data(), *right_trigger_range)));

	auto left_trigger_range = new JSMVariable<int>(150);
	left_trigger_range->setFilter(&filterClampByte);
	SettingsManager::add(SettingID::LEFT_TRIGGER_RANGE, left_trigger_range);
	commandRegistry->add((new JSMAssignment<int>(magic_enum::enum_name(SettingID::LEFT_TRIGGER_RANGE).data(), *left_trigger_range)));

	auto auto_calibrate_gyro = new JSMVariable<Switch>(Switch::OFF);
	auto_calibrate_gyro->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	SettingsManager::add(SettingID::AUTO_CALIBRATE_GYRO, auto_calibrate_gyro);
	commandRegistry->add((new JSMAssignment<Switch>("AUTO_CALIBRATE_GYRO", *auto_calibrate_gyro))
	                       ->setHelp("Gyro calibration happens automatically when this setting is ON. Otherwise you'll need to calibrate the gyro manually when using gyro aiming."));

	auto left_stick_undeadzone_inner = new JSMSetting<float>(SettingID::LEFT_STICK_UNDEADZONE_INNER, 0.f);
	left_stick_undeadzone_inner->setFilter(&filterClamp01);
	SettingsManager::add(left_stick_undeadzone_inner);
	commandRegistry->add((new JSMAssignment<float>(*left_stick_undeadzone_inner))
	                       ->setHelp("When outputting as a virtual controller, account for this much inner deadzone being applied in the target game. This value can only be between 0 and 1 but it should be small."));

	auto left_stick_undeadzone_outer = new JSMSetting<float>(SettingID::LEFT_STICK_UNDEADZONE_OUTER, 0.f);
	left_stick_undeadzone_outer->setFilter(&filterClamp01);
	SettingsManager::add(left_stick_undeadzone_outer);
	commandRegistry->add((new JSMAssignment<float>(*left_stick_undeadzone_outer))
	                       ->setHelp("When outputting as a virtual controller, account for this much outer deadzone being applied in the target game. This value can only be between 0 and 1 but it should be small."));

	auto left_stick_unpower = new JSMSetting<float>(SettingID::LEFT_STICK_UNPOWER, 0.f);
	left_stick_unpower->setFilter(&filterFloat);
	SettingsManager::add(left_stick_unpower);
	commandRegistry->add((new JSMAssignment<float>(*left_stick_unpower))
	                       ->setHelp("When outputting as a virtual controller, account for this power curve being applied in the target game."));

	auto right_stick_undeadzone_inner = new JSMSetting<float>(SettingID::RIGHT_STICK_UNDEADZONE_INNER, 0.f);
	right_stick_undeadzone_inner->setFilter(&filterClamp01);
	SettingsManager::add(right_stick_undeadzone_inner);
	commandRegistry->add((new JSMAssignment<float>(*right_stick_undeadzone_inner))
	                       ->setHelp("When outputting as a virtual controller, account for this much inner deadzone being applied in the target game. This value can only be between 0 and 1 but it should be small."));

	auto right_stick_undeadzone_outer = new JSMSetting<float>(SettingID::RIGHT_STICK_UNDEADZONE_OUTER, 0.f);
	right_stick_undeadzone_outer->setFilter(&filterClamp01);
	SettingsManager::add(right_stick_undeadzone_outer);
	commandRegistry->add((new JSMAssignment<float>(*right_stick_undeadzone_outer))
	                       ->setHelp("When outputting as a virtual controller, account for this much outer deadzone being applied in the target game. This value can only be between 0 and 1 but it should be small."));

	auto right_stick_unpower = new JSMSetting<float>(SettingID::RIGHT_STICK_UNPOWER, 0.f);
	right_stick_unpower->setFilter(&filterFloat);
	SettingsManager::add(right_stick_unpower);
	commandRegistry->add((new JSMAssignment<float>(*right_stick_unpower))
	                       ->setHelp("When outputting as a virtual controller, account for this power curve being applied in the target game."));

	auto left_stick_virtual_scale = new JSMSetting<float>(SettingID::LEFT_STICK_VIRTUAL_SCALE, 1.f);
	left_stick_virtual_scale->setFilter(&filterFloat);
	SettingsManager::add(left_stick_virtual_scale);
	commandRegistry->add((new JSMAssignment<float>(*left_stick_virtual_scale))
	                       ->setHelp("When outputting as a virtual controller, use this to adjust the scale of the left stick output. This does not affect the gyro->stick conversion."));

	auto right_stick_virtual_scale = new JSMSetting<float>(SettingID::RIGHT_STICK_VIRTUAL_SCALE, 1.f);
	right_stick_virtual_scale->setFilter(&filterFloat);
	SettingsManager::add(right_stick_virtual_scale);
	commandRegistry->add((new JSMAssignment<float>(*right_stick_virtual_scale))
	                       ->setHelp("When outputting as a virtual controller, use this to adjust the scale of the right stick output. This does not affect the gyro->stick conversion."));

	auto wind_stick_range = new JSMSetting<float>(SettingID::WIND_STICK_RANGE, 900.f);
	wind_stick_range->setFilter(&filterPositive);
	SettingsManager::add(wind_stick_range);
	commandRegistry->add((new JSMAssignment<float>(*wind_stick_range))
	                       ->setHelp("When using the WIND stick modes, this is how many degrees the stick has to be wound to cover the full range of the ouptut, from minimum value to maximum value."));

	auto wind_stick_power = new JSMSetting<float>(SettingID::WIND_STICK_POWER, 1.f);
	wind_stick_power->setFilter(&filterPositive);
	SettingsManager::add(wind_stick_power);
	commandRegistry->add((new JSMAssignment<float>(*wind_stick_power))
	                       ->setHelp("Power curve for WIND stick modes, letting you have more or less sensitivity towards the neutral position."));

	auto unwind_rate = new JSMSetting<float>(SettingID::UNWIND_RATE, 1800.f);
	unwind_rate->setFilter(&filterPositive);
	SettingsManager::add(unwind_rate);
	commandRegistry->add((new JSMAssignment<float>(*unwind_rate))
	                       ->setHelp("How quickly the WIND sticks unwind on their own when the relevant stick isn't engaged (in degrees per second)."));

	auto gyro_output = new JSMSetting<GyroOutput>(SettingID::GYRO_OUTPUT, GyroOutput::MOUSE);
	gyro_output->setFilter(&filterGyroOutput);
	SettingsManager::add(gyro_output);
	commandRegistry->add((new JSMAssignment<GyroOutput>(*gyro_output))
	                       ->setHelp("Whether gyro should be converted to mouse, left stick, or right stick movement. If you don't want to use gyro aiming, simply leave GYRO_SENS set to 0."));

	auto flick_stick_output = new JSMSetting<GyroOutput>(SettingID::FLICK_STICK_OUTPUT, GyroOutput::MOUSE);
	flick_stick_output->setFilter(&filterInvalidValue<GyroOutput, GyroOutput::INVALID>);
	SettingsManager::add(flick_stick_output);
	commandRegistry->add((new JSMAssignment<GyroOutput>(*flick_stick_output))
	                       ->setHelp("Whether flick stick should be converted to a mouse, left stick, or right stick movement."));

	auto currentWorkingDir = new JSMVariable<PathString>(GetCWD());
	currentWorkingDir->setFilter([](PathString current, PathString next) -> PathString
	  { return SetCWD(string(next)) ? next : current; });
	currentWorkingDir->addOnChangeListener(bind(&refreshAutoLoadHelp, autoloadCmd), true);
	SettingsManager::add(SettingID::JSM_DIRECTORY, currentWorkingDir);
	commandRegistry->add((new JSMAssignment<PathString>("JSM_DIRECTORY", *currentWorkingDir))
	                       ->setHelp("If AUTOLOAD doesn't work properly, set this value to the path to the directory holding the JoyShockMapper.exe file. Make sure a folder named \"AutoLoad\" exists there."));

	auto mouselike_factor = new JSMSetting<FloatXY>(SettingID::MOUSELIKE_FACTOR, {90.f, 90.f});
	mouselike_factor->setFilter(&filterFloatPair);
	SettingsManager::add(SettingID::MOUSELIKE_FACTOR, mouselike_factor);
	commandRegistry->add((new JSMAssignment<FloatXY>(*mouselike_factor))
		->setHelp("Stick sensitivity of the relative movement when in HYBRID_AIM mode. Like the sensitivity of a mouse."));

	auto return_deadzone_is_active = new JSMSetting<Switch>(SettingID::RETURN_DEADZONE_IS_ACTIVE, Switch::ON);
	return_deadzone_is_active->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	SettingsManager::add(SettingID::RETURN_DEADZONE_IS_ACTIVE, return_deadzone_is_active);
	commandRegistry->add((new JSMAssignment<Switch>(*return_deadzone_is_active))
		->setHelp("In HYBRID_AIM stick mode, select the mode's behaviour in the deadzone.\n"\
			"This deadzone is determined by the angle of the output from the stick position to the center.\n"
			"It is fully active up to RETURN_DEADZONE_ANGLE and tapers off until RETURN_DEADZONE_CUTOFF_ANGLE.\n"
			"When in DEADZONE_INNER it transitions to an output deadzone based on the distance to the center so the relative part of the input smoothly fades back in."));
	
	auto edge_push_is_active = new JSMSetting<Switch>(SettingID::EDGE_PUSH_IS_ACTIVE, Switch::ON);
	edge_push_is_active->setFilter(&filterInvalidValue<Switch, Switch::INVALID>);
	SettingsManager::add(SettingID::EDGE_PUSH_IS_ACTIVE, edge_push_is_active);
	commandRegistry->add((new JSMAssignment<Switch>(*edge_push_is_active))
	        ->setHelp("In HYBRID_AIM stick mode, enables continuous travelling when the stick is at the edge."));
		

	auto return_deadzone_angle = new JSMSetting<float>(SettingID::RETURN_DEADZONE_ANGLE, 45.f);
	return_deadzone_angle->setFilter([](float c, float n)
	  { return clamp(n, 0.f, 90.f); });
	SettingsManager::add(SettingID::RETURN_DEADZONE_ANGLE, return_deadzone_angle);
	commandRegistry->add((new JSMAssignment<float>(*return_deadzone_angle))
		->setHelp("In HYBRID_AIM stick mode, angle to the center in which the return deadzone is still partially active.\n"\
				  "Valid values range from 0 to 90"));

	auto return_deadzone_cutoff_angle = new JSMSetting<float>(SettingID::RETURN_DEADZONE_ANGLE_CUTOFF, 90.f);
	return_deadzone_cutoff_angle->setFilter(&filterFloat);
	SettingsManager::add(SettingID::RETURN_DEADZONE_ANGLE_CUTOFF, return_deadzone_cutoff_angle);
	commandRegistry->add((new JSMAssignment<float>(*return_deadzone_cutoff_angle))
	    ->setHelp("In HYBRID_AIM stick mode, angle to the center in which the return deadzone is fully active.\n"\
			      "Valid values range from 0 to 90"));

	// ===== FAAL =====
	// Created here like every other setting: heap-allocated, registered with
	// SettingsManager (which owns it), command registered next to it. Nothing is
	// registered during static initialisation, so there are no global setting
	// objects for the manager to delete at exit.
	auto faalHystRiseTime = new JSMSetting<float>(SettingID::FAAL_HYST_RISE_TIME, 0.0029f);
	SettingsManager::add(faalHystRiseTime);
	commandRegistry->add((new JSMAssignment<float>("FAAL_HYST_RISE_TIME", *faalHystRiseTime))
	    ->setHelp("抑制快进时间（秒）。抑制从 0 到满的基准时长。"));

	auto faalHystFallTime = new JSMSetting<float>(SettingID::FAAL_HYST_FALL_TIME, 0.065f);
	SettingsManager::add(faalHystFallTime);
	commandRegistry->add((new JSMAssignment<float>("FAAL_HYST_FALL_TIME", *faalHystFallTime))
	    ->setHelp("抑制慢出时间（秒）。满抑制时的解除基准时长。"));

	auto faalPeakDecayTime = new JSMSetting<float>(SettingID::FAAL_PEAK_DECAY_TIME, 0.065f);
	SettingsManager::add(faalPeakDecayTime);
	commandRegistry->add((new JSMAssignment<float>("FAAL_PEAK_DECAY_TIME", *faalPeakDecayTime))
	    ->setHelp("峰值跟踪衰减时间（秒）。控制峰值跟踪器跟随信号下降的速度。"));

	auto faalFreezeDurationSec = new JSMSetting<float>(SettingID::FAAL_FREEZE_DURATION_SEC, 0.0f);
	SettingsManager::add(faalFreezeDurationSec);
	commandRegistry->add(new JSMAssignment<float>("FAAL_FREEZE_DURATION_SEC", *faalFreezeDurationSec));

	auto faalDriftHoldTimeSec = new JSMSetting<float>(SettingID::FAAL_DRIFT_HOLD_TIME_SEC, 0.2f);
	SettingsManager::add(faalDriftHoldTimeSec);
	commandRegistry->add(new JSMAssignment<float>("FAAL_DRIFT_HOLD_TIME_SEC", *faalDriftHoldTimeSec));

	auto faalSignChangeThr = new JSMSetting<float>(SettingID::FAAL_SIGN_CHANGE_THR, 1.5f);
	SettingsManager::add(faalSignChangeThr);
	commandRegistry->add(new JSMAssignment<float>("FAAL_SIGN_CHANGE_THR", *faalSignChangeThr));

	auto faalOneEuroFcMin = new JSMSetting<float>(SettingID::FAAL_ONE_EURO_FC_MIN, 2.0f);
	SettingsManager::add(faalOneEuroFcMin);
	commandRegistry->add(new JSMAssignment<float>("FAAL_ONE_EURO_FC_MIN", *faalOneEuroFcMin));

	auto faalOneEuroBeta = new JSMSetting<float>(SettingID::FAAL_ONE_EURO_BETA, 0.5f);
	SettingsManager::add(faalOneEuroBeta);
	commandRegistry->add(new JSMAssignment<float>("FAAL_ONE_EURO_BETA", *faalOneEuroBeta));

	// Soft-tiered smoothing: above this speed (deg/s) nothing is smoothed at all.
	// 0 = One Euro bypassed entirely (suppression only).
	auto faalSmoothThreshold = new JSMSetting<float>(SettingID::FAAL_SMOOTH_THRESHOLD, 0.f);
	faalSmoothThreshold->setFilter([](float c, float n) { return std::clamp(n, 0.f, 2000.f); });
	SettingsManager::add(faalSmoothThreshold);
	commandRegistry->add((new JSMAssignment<float>("FAAL_SMOOTH_THRESHOLD", *faalSmoothThreshold))
	    ->setHelp("分层平滑阈值（deg/s）：超过这个速度完全不平滑。0 = 完全关闭一欧元（只保留抑制），设一个很大的值 = 全程平滑。"));

	auto faalDirChangeMagRatio = new JSMSetting<float>(SettingID::FAAL_DIR_CHANGE_MAG_RATIO, 0.3f);
	SettingsManager::add(faalDirChangeMagRatio);
	commandRegistry->add(new JSMAssignment<float>("FAAL_DIR_CHANGE_MAG_RATIO", *faalDirChangeMagRatio));

	auto faalDirChangeAngleRad = new JSMSetting<float>(SettingID::FAAL_DIR_CHANGE_ANGLE_RAD, 1.570796f);
	SettingsManager::add(faalDirChangeAngleRad);
	commandRegistry->add(new JSMAssignment<float>("FAAL_DIR_CHANGE_ANGLE_RAD", *faalDirChangeAngleRad));

	auto faalEnableVectorReversal = new JSMSetting<float>(SettingID::FAAL_ENABLE_VECTOR_REVERSAL, 0.0f);
	SettingsManager::add(faalEnableVectorReversal);
	commandRegistry->add(new JSMAssignment<float>("FAAL_ENABLE_VECTOR_REVERSAL", *faalEnableVectorReversal));

	auto faalSmoothTimeSec = new JSMSetting<float>(SettingID::FAAL_SMOOTH_TIME_SEC, 0.1f);
	SettingsManager::add(faalSmoothTimeSec);
	commandRegistry->add(new JSMAssignment<float>("FAAL_SMOOTH_TIME_SEC", *faalSmoothTimeSec));

	// PS_MOTION preprocessing mode: 0 = OFF, 1 = PLAYER (the game transforms), 2 = LOCAL (we do)
	auto faalPsMode = new JSMSetting<float>(SettingID::FAAL_PSMOTION_MODE, 1.f);
	faalPsMode->setFilter([](float c, float n) { return std::clamp(n, 0.f, 2.f); });
	SettingsManager::add(faalPsMode);
	commandRegistry->add((new JSMAssignment<float>("FAAL_PSMOTION_MODE", *faalPsMode))
	    ->setHelp("PS_MOTION 预处理模式：0=直通 1=PLAYER（游戏自己做空间转换，我们只缩放）2=LOCAL（我们做转换+滤波，游戏读本地轴）。"));

	// Which local axis the game uses as its turn axis in LOCAL mode: 0 = Y (yaw), 1 = Z (roll)
	auto faalTurnAxis = new JSMSetting<float>(SettingID::FAAL_LOCAL_TURN_AXIS, 0.f);
	faalTurnAxis->setFilter([](float c, float n) { return std::clamp(n, 0.f, 1.f); });
	SettingsManager::add(faalTurnAxis);
	commandRegistry->add((new JSMAssignment<float>("FAAL_LOCAL_TURN_AXIS", *faalTurnAxis))
	    ->setHelp("LOCAL 模式下游戏当作转向轴的本地轴：0=Y（偏航）1=Z（翻滚）。"));
		

}

#ifdef _WIN32
int __stdcall wWinMain(HINSTANCE hInstance, HINSTANCE prevInstance, LPWSTR cmdLine, int cmdShow)
{
	auto trayIconData = hInstance;
	int argc = 0;
	wchar_t **argv = CommandLineToArgvW(cmdLine, &argc);
	unsigned long length = 256;
	wstring wmodule(length, '\0');
	auto handle = GetCurrentProcess();
	QueryFullProcessImageNameW(handle, 0, &wmodule[0], &length);
	string module(wmodule.begin(), wmodule.begin() + length);

#else
int main(int argc, char *argv[])
{
#if !defined(_WIN32)
	if (pipe(input_pipe_fd) == -1)
	{
		perror("pipe");
		exit(EXIT_FAILURE);
	}
	if (dup2(input_pipe_fd[0], STDIN_FILENO) == -1)
	{
		perror("dup2");
		exit(EXIT_FAILURE);
	}
#endif
	static_cast<void>(argc);
	static_cast<void>(argv);
	void *trayIconData = nullptr;
	string module(argv[0]);
#endif // _WIN32
	for (int i = 0; i < argc; ++i)
	{
#if _WIN32
		string arg(&argv[i][0], &argv[i][wcslen(argv[i])]);
#else
		string arg = string(argv[i]);
#endif
		if (arg == "--manual-connect")
		{
			g_manualConnectMode = true;
		}
	}

	jsl.reset(JslWrapper::getNew());
	whitelister.reset(Whitelister::getNew(false));

	grid_mappings.reserve(int(ButtonID::T25) - FIRST_TOUCH_BUTTON); // This makes sure the items will never get copied and cause crashes
	mappings.reserve(MAPPING_SIZE);
	for (int id = 0; id < MAPPING_SIZE; ++id)
	{
		JSMButton newButton(ButtonID(id), Mapping::NO_MAPPING);
		newButton.setFilter(&filterMapping);
		mappings.push_back(newButton);
	}
	// console
	initConsole();
	#ifndef _WIN32
	// Set up the console to receive commands from the pipe
	// This is only needed on non-Windows platforms
	// The pipe is created in the main function
	// and the console is set up in initConsole()
	// The pipe is used to receive commands from the console
	// to the main thread
	initFifoCommandListener();
	#endif
	COUT_BOLD << "Welcome to JoyShockMapper version " << version << "!\n";
	// if (whitelister) COUT << "JoyShockMapper was successfully whitelisted!\n";
	//  Threads need to be created before listeners
	CmdRegistry commandRegistry;
	initJsmSettings(&commandRegistry);

	for (int i = argc - 1; i >= 0; --i)
	{
#if _WIN32
		string arg(&argv[i][0], &argv[i][wcslen(argv[i])]);
#else
		string arg = string(argv[0]);
#endif
		if (filesystem::is_directory(filesystem::status(arg)) &&
		  SettingsManager::getV<PathString>(SettingID::JSM_DIRECTORY)->set(arg).compare(arg) == 0)
		{
			break;
		}
	}

	if (autoLoadThread && autoLoadThread->isRunning())
	{
		COUT << "AUTOLOAD is available. Files in ";
		COUT_INFO << AUTOLOAD_FOLDER();
		COUT << " folder will get loaded automatically when a matching application is in focus.\n";
	}
	else
	{
		CERR << "AutoLoad is unavailable\n";
	}

	// Add all button mappings as commands
	assert(MAPPING_SIZE == buttonHelpMap.size() && "Please update the button help map in ButtonHelp.cpp");
	for (auto &mapping : mappings)
	{
		commandRegistry.add((new JSMAssignment<Mapping>(mapping.getName(), mapping))->setHelp(buttonHelpMap.at(mapping._id)));
	}
	// SL and SR are shorthand for two different mappings
	commandRegistry.add(new JSMAssignment<Mapping>("SL", "LSL", mappings[(int)ButtonID::LSL], true));
	commandRegistry.add(new JSMAssignment<Mapping>("SL", "RSL", mappings[(int)ButtonID::RSL], true));
	commandRegistry.add(new JSMAssignment<Mapping>("SR", "LSR", mappings[(int)ButtonID::LSR], true));
	commandRegistry.add(new JSMAssignment<Mapping>("SR", "RSR", mappings[(int)ButtonID::RSR], true));

	// ===== FAAL — 逐帧记录（用于离线回放）=====
	commandRegistry.add((new JSMMacro("FAAL_TRACE_START"))->SetMacro(bind(&do_FAAL_TRACE_START))
	    ->setHelp("开始记录 FAAL 每帧输入（容量约 20 万帧，1000Hz 下约 200 秒）。"));
	commandRegistry.add((new JSMMacro("FAAL_TRACE_STOP"))->SetMacro(bind(&do_FAAL_TRACE_STOP))
	    ->setHelp("停止记录，并把 faal_trace.csv 写入 JSM 配置目录。"));
	commandRegistry.add((new JSMMacro("FAAL_STICKSMOOTH"))->SetMacro(bind(&do_FAAL_STICKSMOOTH))
	    ->setHelp("原生 flick stick 平滑开关：在把物理右摇杆转发给虚拟手柄之前，按 Jibb 的自适应窗口平滑转角变化。"));
	commandRegistry.add((new JSMMacro("FAAL_LOCALAXIS"))->SetMacro(bind(&do_FAAL_LOCALAXIS))
	    ->setHelp("切换 LOCAL 模式下被游戏当作转向轴的本地轴：Y(偏航) 或 Z(翻滚)。"));
	commandRegistry.add((new JSMMacro("FAAL_PSMOTION"))->SetMacro(bind(&do_FAAL_PSMOTION))
	    ->setHelp("切换 PS_MOTION 的预处理：ON 时在玩家空间分轴抑制后再转发给虚拟手柄，OFF 时直接转发标定后的陀螺仪（用于 A/B 对比手感）。"));

	// Add Macro commands
	commandRegistry.add((new JSMMacro("RESET_MAPPINGS"))->SetMacro(bind(&do_RESET_MAPPINGS, &commandRegistry))->setHelp("Delete all custom bindings and reset to default,\nand run script OnReset.txt in JSM_DIRECTORY."));
	commandRegistry.add((new JSMMacro("NO_GYRO_BUTTON"))->SetMacro(bind(&do_NO_GYRO_BUTTON))->setHelp("Enable gyro at all times, without any GYRO_OFF binding."));
	commandRegistry.add((new JSMMacro("LIST_CONTROLLERS"))->SetMacro(bind(&do_LIST_CONTROLLERS))->setHelp("List currently available SDL controllers without connecting them."));
	commandRegistry.add((new JSMMacro("RECONNECT_CONTROLLERS"))->SetMacro(bind(&do_RECONNECT_CONTROLLERS, placeholders::_2, [&commandRegistry]()
		{
			if (!commandRegistry.loadConfigFile("OnReconnect.txt"))
			{
				COUT << "There is no ";
				COUT_INFO << "OnReconnect.txt";
				COUT << " file to load.\n";
			}
		}))->setHelp("Look for newly connected controllers. Specify MERGE (default) or SPLIT whether you want to consider joycons as a single or separate controllers."));
	commandRegistry.add((new JSMMacro("COUNTER_OS_MOUSE_SPEED"))->SetMacro(bind(do_COUNTER_OS_MOUSE_SPEED))->setHelp("JoyShockMapper will load the user's OS mouse sensitivity value to consider it in its calculations."));
	commandRegistry.add((new JSMMacro("IGNORE_OS_MOUSE_SPEED"))->SetMacro(bind(do_IGNORE_OS_MOUSE_SPEED))->setHelp("Disable JoyShockMapper's consideration of the the user's OS mouse sensitivity value."));
	commandRegistry.add((new JSMMacro("ONE_EURO_FILTER"))->SetMacro(bind(do_ONE_EURO_FILTER))->setHelp("Enable the One Euro adaptive filter on gyro input. Reduces jitter at low speeds without adding latency at high speeds."));
	commandRegistry.add((new JSMMacro("CALCULATE_REAL_WORLD_CALIBRATION"))->SetMacro(bind(&do_CALCULATE_REAL_WORLD_CALIBRATION, placeholders::_2))->setHelp("Get JoyShockMapper to recommend you a REAL_WORLD_CALIBRATION value after performing the calibration sequence. Visit GyroWiki for details:\nhttp://gyrowiki.jibbsmart.com/blog:joyshockmapper-guide#calibrating"));
	commandRegistry.add((new JSMMacro("SLEEP"))->SetMacro(bind(&do_SLEEP, placeholders::_2))->setHelp("Sleep for the given number of seconds, or one second if no number is given. Can't sleep more than 10 seconds per command."));
	commandRegistry.add((new JSMMacro("FINISH_GYRO_CALIBRATION"))->SetMacro(bind(&do_FINISH_GYRO_CALIBRATION))->setHelp("Finish calibrating the gyro in all controllers."));
	commandRegistry.add((new JSMMacro("RESTART_GYRO_CALIBRATION"))->SetMacro(bind(&do_RESTART_GYRO_CALIBRATION))->setHelp("Start calibrating the gyro in all controllers."));
	commandRegistry.add((new JSMMacro("SET_MOTION_STICK_NEUTRAL"))->SetMacro(bind(&do_SET_MOTION_STICK_NEUTRAL))->setHelp("Set the neutral orientation for motion stick to whatever the orientation of the controller is."));
	commandRegistry.add((new JSMMacro("README"))->SetMacro(bind(&do_README))->setHelp("Open the latest JoyShockMapper README in your browser."));
	commandRegistry.add((new JSMMacro("WHITELIST_SHOW"))->SetMacro(bind(&do_WHITELIST_SHOW))->setHelp("Open the whitelister application"));
	commandRegistry.add((new JSMMacro("WHITELIST_ADD"))->SetMacro(bind(&do_WHITELIST_ADD))->setHelp("Add JoyShockMapper to the whitelisted applications."));
	commandRegistry.add((new JSMMacro("WHITELIST_REMOVE"))->SetMacro(bind(&do_WHITELIST_REMOVE))->setHelp("Remove JoyShockMapper from whitelisted applications."));
	commandRegistry.add(new HelpCmd(commandRegistry));
	commandRegistry.add((new JSMMacro("CLEAR"))->SetMacro(bind(&ClearConsole))->setHelp("Removes all text in the console screen"));
	commandRegistry.add((new JSMMacro("CALIBRATE_TRIGGERS"))->SetMacro([](JSMMacro *, string_view)
	                                                          {
		                                                        triggerCalibrationStep = 1;
		                                                        return true; })
	                      ->setHelp("Starts the trigger calibration procedure for the dualsense triggers."));
	bool quit = false;
	commandRegistry.add((new JSMMacro("QUIT"))
	                      ->SetMacro([&quit](JSMMacro *, string_view)
	                        {
		                      quit = true;
		                      WriteToConsole(""); // If ran from autoload thread, you need to send RETURN to resume the main loop and check the quit flag.
		                      return true; })
	                      ->setHelp("Close the application."));

	Mapping::_isCommandValid = bind(&CmdRegistry::isCommandValid, &commandRegistry, placeholders::_1);

	if (g_manualConnectMode)
	{
		COUT << "Manual controller connection mode enabled. Use LIST_CONTROLLERS and RECONNECT_CONTROLLERS SELECT <id...> to connect devices.\n";
	}
	else
	{
		connectDevices();
	}
	jsl->SetCallback(&joyShockPollCallback);
	jsl->SetTouchCallback(&touchCallback);
	tray.reset(TrayIcon::getNew(trayIconData, &beforeShowTrayMenu));
	if (tray)
	{
		tray->Show();
	}

	do_RESET_MAPPINGS(&commandRegistry); // OnReset.txt
	if (commandRegistry.loadConfigFile("OnStartup.txt"))
	{
		COUT << "Finished executing startup file.\n";
	}
	else
	{
		COUT << "There is no ";
		COUT_INFO << "OnStartup.txt";
		COUT << " file to load.\n";
	}

	for (int i = 0; i < argc; ++i)
	{
#if _WIN32
		string arg(&argv[i][0], &argv[i][wcslen(argv[i])]);
#else
		string arg = string(argv[0]);
#endif
		if (filesystem::is_regular_file(filesystem::status(arg)) && arg != module)
		{
			commandRegistry.loadConfigFile(arg);
			SettingsManager::getV<Switch>(SettingID::AUTOLOAD)->set(Switch::OFF);
		}
	}
	// The main loop is simple and reads like pseudocode
	string enteredCommand;
	while (!quit)
	{
		#if _WIN32
			getline(cin, enteredCommand);
        #else
			std::unique_lock<std::mutex> lock(commandQueueMutex);
			commandQueueCV.wait(lock, []{ return !commandQueue.empty(); });

			Command cmd = commandQueue.front();
			commandQueue.pop();
			lock.unlock();
			enteredCommand = cmd.text;
        #endif
		

		commandRegistry.processLine(enteredCommand);
	}
#ifdef _WIN32
	LocalFree(argv);
#endif
	cleanUp();
	return 0;
}
